import 'dotenv/config';
import express, { type NextFunction, type Request, type Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  aggregateDepartmentAssignments,
  buildDispatchPacket,
  buildSessionCookie,
  canCreateAssignments,
  canSubmitReport,
  canSubmitReview,
  canViewDocument,
  createSessionToken,
  extractBearerToken,
  generateId,
  hashPassword,
  isDirector,
  isDirectorOnlyTaskStatus,
  parseCookies,
  searchCouncilEntities,
  sha256Hex,
  timingSafeEqualHex,
  verifyPassword,
  type AuthUser,
  type SearchableDepartment,
  type SearchableDocument,
  type SearchableProject,
} from './server/governance.ts';
import { getDb, logActivity, nextSequenceRef, seedSampleRecords } from './server/db.ts';
import { getEnvConfiguredFlag, runProviderConnectionTest } from './server/providers.ts';
import {
  runCouncilChatTurn,
  runGeminiReportAnalysis,
  type CouncilGeminiModel,
  type CouncilThinkingMode,
} from './server/gemini.ts';

interface AuthedRequest extends Request {
  authUser?: AuthUser;
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.set('trust proxy', 1);
const db = getDb();

app.use(express.json({ limit: '4mb' }));

function isHttpsRequest(req: Request): boolean {
  const forwardedProto = String(req.headers['x-forwarded-proto'] || '').toLowerCase();
  return req.secure || forwardedProto.split(',').some((p) => p.trim() === 'https');
}

function getRequestSessionToken(req: Request): string | null {
  const bearer = extractBearerToken(req.headers.authorization);
  if (bearer) return bearer;
  const cookies = parseCookies(req.headers.cookie);
  return cookies.pn_session || null;
}

function authenticateFromRequest(req: Request): AuthUser | null {
  const rawToken = getRequestSessionToken(req);
  if (!rawToken) return null;

  const tokenHash = sha256Hex(rawToken);
  const row = db
    .prepare(
      `SELECT u.id, u.username, u.display_name, u.role, u.department_id,
              u.can_submit, u.can_review, u.can_approve, u.is_active
       FROM sessions s
       JOIN users u ON u.id = s.user_id
       WHERE s.token_hash = ?
         AND u.is_active = 1
         AND s.expires_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
       LIMIT 1`
    )
    .get(tokenHash) as AuthUser | undefined;

  return row || null;
}

function requireAuth(req: AuthedRequest, res: Response, next: NextFunction): void {
  const user = authenticateFromRequest(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required.' });
    return;
  }
  req.authUser = user;
  next();
}

function createUserSession(userId: string, req: Request, res: Response): string {
  const rawToken = createSessionToken();
  const tokenHash = sha256Hex(rawToken);
  const expiresAt = new Date(Date.now() + 12 * 3600 * 1000).toISOString().replace(/\.\d{3}Z$/, 'Z');
  db.prepare(
    `INSERT INTO sessions (id, user_id, token_hash, expires_at, ip_hint) VALUES (?, ?, ?, ?, ?)`
  ).run(generateId('sess'), userId, tokenHash, expiresAt, req.ip || 'local');

  res.setHeader('Set-Cookie', buildSessionCookie(rawToken, isHttpsRequest(req), false));
  return rawToken;
}

// Public health & auth endpoints (no private project data exposed)
app.get('/api/health', (_req, res) => {
  db.prepare('SELECT 1').get();
  res.json({ ok: true, service: 'PATRIOT-NEXUS', timestamp: new Date().toISOString() });
});

app.get('/api/auth/status', (req, res) => {
  const countRow = db.prepare('SELECT COUNT(*) AS c FROM users').get() as { c: number };
  const user = authenticateFromRequest(req);
  res.json({
    needs_bootstrap: (countRow?.c || 0) === 0,
    requires_bootstrap_token: Boolean(process.env.BOOTSTRAP_TOKEN),
    authenticated: Boolean(user),
    user,
  });
});

app.post('/api/auth/bootstrap', (req, res) => {
  const countRow = db.prepare('SELECT COUNT(*) AS c FROM users').get() as { c: number };
  if ((countRow?.c || 0) > 0) {
    res.status(403).json({ error: 'Bootstrap already completed. Sign in with existing credentials.' });
    return;
  }

  const body = req.body || {};
  if (process.env.BOOTSTRAP_TOKEN) {
    if (!body.bootstrap_token || !timingSafeEqualHex(String(body.bootstrap_token), String(process.env.BOOTSTRAP_TOKEN))) {
      res.status(403).json({ error: 'Invalid bootstrap token.' });
      return;
    }
  }

  const username = String(body.username || '').trim().toLowerCase();
  const displayName = String(body.display_name || '').trim();
  const password = String(body.password || '');

  if (username.length < 2 || displayName.length < 2 || password.length < 12) {
    res.status(400).json({ error: 'Username (>=2 chars), display name, and password (>=12 chars) are required.' });
    return;
  }

  const { hash, salt } = hashPassword(password);
  const userId = 'u-g0-director';
  db.prepare(
    `INSERT INTO users (id, username, display_name, role, department_id, can_submit, can_review, can_approve, password_hash, password_salt)
     VALUES (?, ?, ?, 'G0_DIRECTOR', NULL, 1, 1, 1, ?, ?)`
  ).run(userId, username, displayName, hash, salt);

  if (body.load_sample_data !== false) {
    seedSampleRecords(db, userId);
  }

  const token = createUserSession(userId, req, res);
  const authUser = db
    .prepare(
      `SELECT id, username, display_name, role, department_id, can_submit, can_review, can_approve, is_active
       FROM users WHERE id = ?`
    )
    .get(userId) as unknown as AuthUser;
  logActivity(db, { id: userId, display_name: displayName, role: 'G0_DIRECTOR' }, 'BOOTSTRAP', 'SYSTEM', userId, 'Initialized Director G-0 account.');
  res.status(201).json({ ok: true, token, user: authUser });
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) {
    res.status(400).json({ error: 'Username and password are required.' });
    return;
  }
  const normalized = String(username).trim().toLowerCase();
  const userRow = db
    .prepare(`SELECT * FROM users WHERE username = ? AND is_active = 1 LIMIT 1`)
    .get(normalized) as (AuthUser & { password_hash: string; password_salt: string }) | undefined;

  if (!userRow || !verifyPassword(String(password), userRow.password_hash, userRow.password_salt)) {
    res.status(401).json({ error: 'Invalid credentials.' });
    return;
  }

  const token = createUserSession(userRow.id, req, res);
  db.prepare(`UPDATE users SET last_login_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now') WHERE id = ?`).run(userRow.id);
  logActivity(db, userRow, 'LOGIN', 'SESSION', userRow.id, `Authenticated session started for ${userRow.username}.`);
  const safeUser: AuthUser = {
    id: userRow.id,
    username: userRow.username,
    display_name: userRow.display_name,
    role: userRow.role,
    department_id: userRow.department_id,
    can_submit: userRow.can_submit,
    can_review: userRow.can_review,
    can_approve: userRow.can_approve,
    is_active: userRow.is_active,
  };
  res.json({ ok: true, token, user: safeUser });
});

app.post('/api/auth/logout', (req, res) => {
  const bearer = extractBearerToken(req.headers.authorization);
  const cookies = parseCookies(req.headers.cookie);
  if (bearer) {
    db.prepare(`DELETE FROM sessions WHERE token_hash = ?`).run(sha256Hex(bearer));
  }
  if (cookies.pn_session) {
    db.prepare(`DELETE FROM sessions WHERE token_hash = ?`).run(sha256Hex(cookies.pn_session));
  }
  res.setHeader('Set-Cookie', buildSessionCookie('', isHttpsRequest(req), true));
  res.json({ ok: true });
});

// Protected routes below
app.get('/api/auth/me', requireAuth, (req: AuthedRequest, res) => {
  res.json({ user: req.authUser });
});

function getDepartmentsWithWorkload(): Array<Record<string, unknown>> {
  const deptRows = db.prepare(`SELECT * FROM departments ORDER BY sort_order ASC`).all() as Array<Record<string, unknown>>;
  const assignmentStatuses = db
    .prepare(`SELECT assigned_department_id, status FROM assignments`)
    .all() as Array<{ assigned_department_id: string; status: string }>;
  const countsByDept = aggregateDepartmentAssignments(assignmentStatuses);
  return deptRows.map((dept) => {
    const deptId = String(dept.id);
    const agg = countsByDept[deptId];
    return {
      ...dept,
      active_assignment_count: agg ? agg.active_assignment_count : 0,
      in_progress_count: agg ? agg.in_progress_count : 0,
      revision_required_count: agg ? agg.revision_required_count : 0,
    };
  });
}

// 1. Dashboard Summary
app.get('/api/dashboard', requireAuth, (_req, res) => {
  const departments = getDepartmentsWithWorkload();
  const active_projects = db.prepare(`SELECT * FROM projects WHERE status = 'ACTIVE' ORDER BY updated_at DESC LIMIT 12`).all();
  const pending_assignments = db
    .prepare(
      `SELECT a.*, d.name AS department_name, d.assigned_model, p.name AS project_name
       FROM assignments a
       JOIN departments d ON d.id = a.assigned_department_id
       JOIN projects p ON p.id = a.project_id
       WHERE a.status IN ('Pending', 'Assigned', 'In Progress', 'Revision Required')
       ORDER BY a.created_at DESC LIMIT 15`
    )
    .all();
  const submitted_reports = db
    .prepare(
      `SELECT r.*, d.name AS department_name, a.task_ref
       FROM reports r
       JOIN departments d ON d.id = r.department_id
       JOIN assignments a ON a.id = r.task_id
       ORDER BY r.created_at DESC LIMIT 10`
    )
    .all();
  const awaiting_verification = db
    .prepare(
      `SELECT r.*, d.name AS department_name, a.task_ref
       FROM reports r
       JOIN departments d ON d.id = r.department_id
       JOIN assignments a ON a.id = r.task_id
       WHERE r.director_status = 'PENDING'
       ORDER BY r.created_at DESC LIMIT 12`
    )
    .all();
  const unresolved_disagreements = db
    .prepare(
      `SELECT rv.*, rp.report_ref, d.assigned_model AS reviewer_dept_model
       FROM reviews rv
       JOIN reports rp ON rp.id = rv.report_id
       JOIN departments d ON d.id = rv.reviewer_department_id
       WHERE rv.is_dispute = 1 AND rv.resolution_status = 'OPEN'
       ORDER BY rv.created_at DESC`
    )
    .all();
  const recent_decisions = db.prepare(`SELECT * FROM decisions ORDER BY created_at DESC LIMIT 8`).all();
  const recent_activity = db.prepare(`SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 15`).all();
  const providers = db.prepare(`SELECT id, provider_name, model_name, department_id, connection_status, auth_status FROM ai_providers`).all();

  res.json({
    departments,
    active_projects,
    pending_assignments,
    submitted_reports,
    awaiting_verification,
    unresolved_disagreements,
    recent_decisions,
    recent_activity,
    providers,
    server_time: new Date().toISOString(),
  });
});

// Global Keyword Search (Departments, Projects, Authorized Documents)
app.get('/api/search', requireAuth, (req: AuthedRequest, res) => {
  const q = String(req.query.q || '').trim();
  if (!q) {
    res.json({ query: '', departments: [], projects: [], documents: [], total: 0 });
    return;
  }

  const departments = db
    .prepare(
      `SELECT id, code, name, assigned_model, application_name, responsibilities, limitations, status
       FROM departments ORDER BY sort_order ASC`
    )
    .all() as unknown as SearchableDepartment[];

  const projects = db
    .prepare(
      `SELECT id, name, objective, description, status, priority, required_deliverables, dependencies, risks
       FROM projects ORDER BY updated_at DESC`
    )
    .all() as unknown as SearchableProject[];

  const documents = db
    .prepare(
      `SELECT id, title, doc_type, description, project_id, department_id, filename, version_number, access_level
       FROM documents ORDER BY created_at DESC`
    )
    .all() as unknown as SearchableDocument[];

  const results = searchCouncilEntities({
    query: q,
    user: req.authUser,
    departments,
    projects,
    documents,
  });

  res.json(results);
});

// 2. Departments
app.get('/api/departments', requireAuth, (_req, res) => {
  const departments = getDepartmentsWithWorkload();
  res.json({ departments });
});

app.get('/api/departments/:deptId', requireAuth, (req, res) => {
  const { deptId } = req.params;
  const department = db.prepare(`SELECT * FROM departments WHERE id = ?`).get(deptId);
  if (!department) {
    res.status(404).json({ error: 'Department not found.' });
    return;
  }
  const assignments = db
    .prepare(`SELECT a.*, p.name AS project_name FROM assignments a JOIN projects p ON p.id = a.project_id WHERE a.assigned_department_id = ? ORDER BY a.created_at DESC`)
    .all(deptId);
  const reports = db
    .prepare(`SELECT r.*, a.task_ref FROM reports r JOIN assignments a ON a.id = r.task_id WHERE r.department_id = ? ORDER BY r.created_at DESC`)
    .all(deptId);
  const documents = db
    .prepare(`SELECT id, title, doc_type, description, project_id, department_id, filename, mime_type, size_bytes, version_number, access_level, created_at FROM documents WHERE department_id = ? ORDER BY created_at DESC`)
    .all(deptId);
  const reviews = db
    .prepare(`SELECT rv.*, rp.report_ref FROM reviews rv JOIN reports rp ON rp.id = rv.report_id WHERE rv.reviewer_department_id = ? OR rp.department_id = ? ORDER BY rv.created_at DESC`)
    .all(deptId, deptId);

  res.json({ department, assignments, reports, documents, reviews });
});

app.patch('/api/departments/:deptId', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may modify department status or scope.' });
    return;
  }
  const { deptId } = req.params;
  const { status, responsibilities, limitations, testing_requirements } = req.body || {};
  db.prepare(
    `UPDATE departments
     SET status = COALESCE(?, status),
         responsibilities = COALESCE(?, responsibilities),
         limitations = COALESCE(?, limitations),
         testing_requirements = COALESCE(?, testing_requirements),
         updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
     WHERE id = ?`
  ).run(status || null, responsibilities || null, limitations || null, testing_requirements || null, deptId);

  logActivity(db, req.authUser!, 'UPDATE_DEPT', 'DEPARTMENT', deptId, `G-0 updated department ${deptId}.`);
  res.json({ ok: true });
});

// 3. Projects
app.get('/api/projects', requireAuth, (_req, res) => {
  const projects = db.prepare(`SELECT * FROM projects ORDER BY updated_at DESC`).all();
  res.json({ projects });
});

app.get('/api/projects/:projectId', requireAuth, (req, res) => {
  const project = db.prepare(`SELECT * FROM projects WHERE id = ?`).get(req.params.projectId);
  if (!project) {
    res.status(404).json({ error: 'Project not found.' });
    return;
  }
  const history = db
    .prepare(`SELECT h.*, u.display_name FROM project_history h JOIN users u ON u.id = h.actor_id WHERE h.project_id = ? ORDER BY h.created_at DESC`)
    .all(req.params.projectId);
  res.json({ project, history });
});

app.post('/api/projects', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may create official projects.' });
    return;
  }
  const body = req.body || {};
  if (!body.name || !body.objective || !body.description) {
    res.status(400).json({ error: 'Project name, objective, and description are required.' });
    return;
  }
  const id = body.id ? String(body.id).trim().toUpperCase() : `PN-PROJ-${Date.now().toString(36).toUpperCase()}`;
  db.prepare(
    `INSERT INTO projects (
      id, name, objective, description, status, priority, assigned_departments,
      required_deliverables, dependencies, risks, director_approval_status, created_by
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    String(body.name).trim(),
    String(body.objective).trim(),
    String(body.description).trim(),
    body.status || 'ACTIVE',
    body.priority || 'HIGH',
    JSON.stringify(Array.isArray(body.assigned_departments) ? body.assigned_departments : []),
    String(body.required_deliverables || ''),
    String(body.dependencies || ''),
    String(body.risks || ''),
    body.director_approval_status || 'APPROVED_BY_G0',
    req.authUser!.id
  );
  db.prepare(`INSERT INTO project_history (id, project_id, actor_id, action, details) VALUES (?, ?, ?, 'CREATED', ?)`).run(
    generateId('ph'),
    id,
    req.authUser!.id,
    `Created by Director G-0 (${req.authUser!.username}).`
  );
  logActivity(db, req.authUser!, 'CREATE_PROJECT', 'PROJECT', id, `Created project ${id}: ${body.name}`);
  res.status(201).json({ ok: true, id });
});

app.patch('/api/projects/:projectId', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may modify approved project objectives or status.' });
    return;
  }
  const body = req.body || {};
  const { projectId } = req.params;
  db.prepare(
    `UPDATE projects
     SET name = COALESCE(?, name),
         objective = COALESCE(?, objective),
         description = COALESCE(?, description),
         status = COALESCE(?, status),
         priority = COALESCE(?, priority),
         assigned_departments = COALESCE(?, assigned_departments),
         required_deliverables = COALESCE(?, required_deliverables),
         dependencies = COALESCE(?, dependencies),
         risks = COALESCE(?, risks),
         director_approval_status = COALESCE(?, director_approval_status),
         updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
     WHERE id = ?`
  ).run(
    body.name || null,
    body.objective || null,
    body.description || null,
    body.status || null,
    body.priority || null,
    body.assigned_departments ? JSON.stringify(body.assigned_departments) : null,
    body.required_deliverables ?? null,
    body.dependencies ?? null,
    body.risks ?? null,
    body.director_approval_status || null,
    projectId
  );
  db.prepare(`INSERT INTO project_history (id, project_id, actor_id, action, details) VALUES (?, ?, ?, 'UPDATED', ?)`).run(
    generateId('ph'),
    projectId,
    req.authUser!.id,
    body.history_note || 'Updated by Director G-0.'
  );
  logActivity(db, req.authUser!, 'UPDATE_PROJECT', 'PROJECT', projectId, `Updated project ${projectId}.`);
  res.json({ ok: true });
});

// 4. Assignments (PN-TASK)
app.get('/api/assignments', requireAuth, (req, res) => {
  const projFilter = req.query.project_id ? String(req.query.project_id) : null;
  const deptFilter = req.query.department_id ? String(req.query.department_id) : null;
  let sql = `SELECT a.*, d.name AS department_name, d.assigned_model, p.name AS project_name
             FROM assignments a
             JOIN departments d ON d.id = a.assigned_department_id
             JOIN projects p ON p.id = a.project_id WHERE 1=1`;
  const binds: string[] = [];
  if (projFilter) {
    sql += ' AND a.project_id = ?';
    binds.push(projFilter);
  }
  if (deptFilter) {
    sql += ' AND a.assigned_department_id = ?';
    binds.push(deptFilter);
  }
  sql += ' ORDER BY a.created_at DESC';
  const assignments = binds.length ? db.prepare(sql).all(...binds) : db.prepare(sql).all();
  res.json({ assignments });
});

app.post('/api/assignments', requireAuth, (req: AuthedRequest, res) => {
  if (!canCreateAssignments(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 or GPT-6 Chief Architect may create assignments.' });
    return;
  }
  const body = req.body || {};
  if (!body.project_id || !body.objective || !body.instructions || !body.required_output) {
    res.status(400).json({ error: 'project_id, objective, instructions, and required_output are required.' });
    return;
  }
  const deptIds: string[] =
    Array.isArray(body.department_ids) && body.department_ids.length
      ? body.department_ids
      : body.assigned_department_id
      ? [body.assigned_department_id]
      : [];
  if (!deptIds.length) {
    res.status(400).json({ error: 'At least one assigned department is required.' });
    return;
  }

  const isG0 = isDirector(req.authUser);
  const initialStatus = isG0 ? body.status || 'Assigned' : 'Pending';
  const batchGroupId = deptIds.length > 1 ? generateId('batch') : null;
  const created: Array<{ id: string; task_ref: string; department_id: string }> = [];

  for (const deptId of deptIds) {
    const taskRef = nextSequenceRef(db, 'PN-TASK', 'PN-TASK');
    const id = generateId('task');
    db.prepare(
      `INSERT INTO assignments (
        id, task_ref, project_id, objective, instructions, assigned_department_id,
        batch_group_id, required_output, supporting_files, due_date, status, created_by
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      taskRef,
      body.project_id,
      String(body.objective).trim(),
      String(body.instructions).trim(),
      deptId,
      batchGroupId,
      String(body.required_output).trim(),
      JSON.stringify(Array.isArray(body.supporting_files) ? body.supporting_files : []),
      body.due_date || null,
      initialStatus,
      req.authUser!.id
    );
    created.push({ id, task_ref: taskRef, department_id: deptId });
  }

  logActivity(
    db,
    req.authUser!,
    'CREATE_TASK',
    'ASSIGNMENT',
    created.map((c) => c.task_ref).join(','),
    `Created ${created.length} assignment(s) under ${body.project_id}.`
  );
  res.status(201).json({ ok: true, created });
});

app.patch('/api/assignments/:taskId', requireAuth, (req: AuthedRequest, res) => {
  const existing = db.prepare(`SELECT * FROM assignments WHERE id = ?`).get(req.params.taskId) as
    | { id: string; task_ref: string; assigned_department_id: string }
    | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Assignment not found.' });
    return;
  }
  const { status } = req.body || {};
  if (!status) {
    res.status(400).json({ error: 'Status is required.' });
    return;
  }
  if (isDirectorOnlyTaskStatus(status) && !isDirector(req.authUser)) {
    res.status(403).json({ error: `Status "${status}" requires Director G-0 authority.` });
    return;
  }
  if (!isDirector(req.authUser) && !(req.authUser!.role === 'DEPT_MODEL' && req.authUser!.department_id === existing.assigned_department_id)) {
    res.status(403).json({ error: 'Not authorized to update this assignment.' });
    return;
  }
  db.prepare(`UPDATE assignments SET status = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now') WHERE id = ?`).run(status, req.params.taskId);
  logActivity(db, req.authUser!, 'UPDATE_TASK_STATUS', 'ASSIGNMENT', existing.task_ref, `Task ${existing.task_ref} moved to ${status}.`);
  res.json({ ok: true });
});

app.get('/api/assignments/:taskId/dispatch', requireAuth, (req, res) => {
  const task = db.prepare(`SELECT * FROM assignments WHERE id = ?`).get(req.params.taskId) as
    | { task_ref: string; project_id: string; assigned_department_id: string; objective: string; instructions: string; required_output: string; supporting_files: string }
    | undefined;
  if (!task) {
    res.status(404).json({ error: 'Assignment not found.' });
    return;
  }
  const project = db.prepare(`SELECT * FROM projects WHERE id = ?`).get(task.project_id) as {
    id: string;
    name: string;
    priority: string;
    director_approval_status: string;
    objective: string;
  };
  const department = db.prepare(`SELECT * FROM departments WHERE id = ?`).get(task.assigned_department_id) as {
    name: string;
    assigned_model: string;
  };
  const docIds = JSON.parse(task.supporting_files || '[]') as string[];
  let documents: Array<{ id: string; title: string; filename: string }> = [];
  if (docIds.length) {
    const placeholders = docIds.map(() => '?').join(',');
    documents = db.prepare(`SELECT id, title, filename FROM documents WHERE id IN (${placeholders})`).all(...docIds) as Array<{
      id: string;
      title: string;
      filename: string;
    }>;
  }
  res.json({ dispatch_brief: buildDispatchPacket({ task, project, department, documents }) });
});

// 5. Reports (PN-REPORT) - Immutable originals
app.get('/api/reports', requireAuth, (_req, res) => {
  const reports = db
    .prepare(
      `SELECT r.*, d.name AS department_name, d.code AS department_code, a.task_ref, p.name AS project_name
       FROM reports r
       JOIN departments d ON d.id = r.department_id
       JOIN assignments a ON a.id = r.task_id
       JOIN projects p ON p.id = r.project_id
       ORDER BY r.created_at DESC`
    )
    .all();
  res.json({ reports });
});

app.post('/api/reports', requireAuth, (req: AuthedRequest, res) => {
  const body = req.body || {};
  if (!body.task_id) {
    res.status(400).json({ error: 'task_id is required.' });
    return;
  }
  const task = db.prepare(`SELECT * FROM assignments WHERE id = ?`).get(body.task_id) as
    | { id: string; task_ref: string; project_id: string; assigned_department_id: string }
    | undefined;
  if (!task) {
    res.status(404).json({ error: 'Referenced assignment not found.' });
    return;
  }
  const deptId = String(body.department_id || task.assigned_department_id);
  if (!canSubmitReport(req.authUser, deptId)) {
    res.status(403).json({ error: 'You do not have submission permission for this department.' });
    return;
  }

  const requiredFields = [
    'model_application',
    'objective',
    'findings',
    'evidence',
    'assumptions',
    'limitations',
    'risks',
    'recommendations',
    'unresolved_questions',
  ];
  for (const field of requiredFields) {
    if (!body[field] || !String(body[field]).trim()) {
      res.status(400).json({ error: `Required report field missing: ${field}` });
      return;
    }
  }

  const dept = db.prepare(`SELECT code FROM departments WHERE id = ?`).get(deptId) as { code: string } | undefined;
  const reportRef = nextSequenceRef(db, 'PN-REPORT', 'PN-REPORT', dept ? dept.code : 'MODEL');
  const id = generateId('rep');

  let versionNum = 1;
  if (body.parent_report_id) {
    const parent = db.prepare(`SELECT version_number FROM reports WHERE id = ?`).get(body.parent_report_id) as { version_number: number } | undefined;
    if (parent) versionNum = parent.version_number + 1;
  }

  db.prepare(
    `INSERT INTO reports (
      id, report_ref, project_id, task_id, department_id, submitted_by_user_id,
      model_application, objective, findings, evidence, assumptions, limitations,
      risks, recommendations, unresolved_questions, parent_report_id, version_number
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    reportRef,
    task.project_id,
    task.id,
    deptId,
    req.authUser!.id,
    String(body.model_application).trim(),
    String(body.objective).trim(),
    String(body.findings).trim(),
    String(body.evidence).trim(),
    String(body.assumptions).trim(),
    String(body.limitations).trim(),
    String(body.risks).trim(),
    String(body.recommendations).trim(),
    String(body.unresolved_questions).trim(),
    body.parent_report_id || null,
    versionNum
  );

  db.prepare(`UPDATE assignments SET status = 'Submitted', updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now') WHERE id = ?`).run(task.id);
  logActivity(db, req.authUser!, 'SUBMIT_REPORT', 'REPORT', reportRef, `Submitted ${reportRef} for ${task.task_ref}.`);
  res.status(201).json({ ok: true, id, report_ref: reportRef });
});

app.patch('/api/reports/:reportId/director-status', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may approve or reject reports.' });
    return;
  }
  const { director_status } = req.body || {};
  if (!['PENDING', 'ACKNOWLEDGED', 'APPROVED_BY_G0', 'REJECTED_BY_G0'].includes(director_status)) {
    res.status(400).json({ error: 'Invalid director_status.' });
    return;
  }
  const rep = db.prepare(`SELECT report_ref FROM reports WHERE id = ?`).get(req.params.reportId) as { report_ref: string } | undefined;
  if (!rep) {
    res.status(404).json({ error: 'Report not found.' });
    return;
  }
  db.prepare(`UPDATE reports SET director_status = ? WHERE id = ?`).run(director_status, req.params.reportId);
  logActivity(db, req.authUser!, 'DIRECTOR_REPORT_STATUS', 'REPORT', rep.report_ref, `G-0 set ${rep.report_ref} to ${director_status}.`);
  res.json({ ok: true });
});

// 6. Independent Reviews (PN-REVIEW)
app.get('/api/reviews', requireAuth, (_req, res) => {
  const reviews = db
    .prepare(
      `SELECT rv.*, rp.report_ref, rp.department_id AS author_department_id,
              d.name AS reviewer_department_name, ad.assigned_model AS author_model
       FROM reviews rv
       JOIN reports rp ON rp.id = rv.report_id
       JOIN departments d ON d.id = rv.reviewer_department_id
       JOIN departments ad ON ad.id = rp.department_id
       ORDER BY rv.created_at DESC`
    )
    .all();
  res.json({ reviews });
});

app.post('/api/reviews', requireAuth, (req: AuthedRequest, res) => {
  const body = req.body || {};
  if (!body.report_id || !body.verdict || !body.summary || !body.technical_notes) {
    res.status(400).json({ error: 'report_id, verdict, summary, and technical_notes are required.' });
    return;
  }
  const report = db.prepare(`SELECT * FROM reports WHERE id = ?`).get(body.report_id) as
    | { id: string; report_ref: string; project_id: string; task_id: string; department_id: string; submitted_by_user_id: string }
    | undefined;
  if (!report) {
    res.status(404).json({ error: 'Target report not found.' });
    return;
  }
  if (!canSubmitReview(req.authUser, report)) {
    res.status(403).json({ error: 'FORBIDDEN: Models and authors cannot review or approve their own work.' });
    return;
  }
  const reviewerDeptId = req.authUser!.department_id || body.reviewer_department_id || 'dept-muse';
  if (reviewerDeptId === report.department_id) {
    res.status(403).json({ error: 'FORBIDDEN: Reviewing department must be independent from submitting department.' });
    return;
  }

  const reviewRef = nextSequenceRef(db, 'PN-REVIEW', 'PN-REVIEW');
  const isDispute = ['REJECT', 'DISPUTE_FINDINGS', 'MISSING_EVIDENCE', 'TECHNICAL_ERROR', 'UNSUPPORTED_CLAIMS'].includes(body.verdict) ? 1 : 0;

  db.prepare(
    `INSERT INTO reviews (
      id, review_ref, report_id, project_id, task_id, reviewer_department_id,
      reviewer_user_id, reviewer_model, verdict, summary, technical_notes,
      disagreements, evidence_gaps, recommended_tests, is_dispute
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    generateId('rev'),
    reviewRef,
    report.id,
    report.project_id,
    report.task_id,
    reviewerDeptId,
    req.authUser!.id,
    String(body.reviewer_model || req.authUser!.display_name).trim(),
    body.verdict,
    String(body.summary).trim(),
    String(body.technical_notes).trim(),
    String(body.disagreements || ''),
    String(body.evidence_gaps || ''),
    String(body.recommended_tests || ''),
    isDispute
  );

  db.prepare(`UPDATE assignments SET status = 'Under Review', updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now') WHERE id = ?`).run(report.task_id);
  logActivity(db, req.authUser!, 'SUBMIT_REVIEW', 'REVIEW', reviewRef, `Independent review ${reviewRef} (${body.verdict}) on ${report.report_ref}.`);
  res.status(201).json({ ok: true, review_ref: reviewRef });
});

app.patch('/api/reviews/:reviewId', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may resolve recorded disputes.' });
    return;
  }
  const { resolution_status } = req.body || {};
  if (!['OPEN', 'ADDRESSED', 'OVERRULED_BY_G0', 'UPHELD_BY_G0'].includes(resolution_status)) {
    res.status(400).json({ error: 'Invalid resolution_status.' });
    return;
  }
  db.prepare(`UPDATE reviews SET resolution_status = ? WHERE id = ?`).run(resolution_status, req.params.reviewId);
  logActivity(db, req.authUser!, 'RESOLVE_DISPUTE', 'REVIEW', req.params.reviewId, `G-0 set review resolution to ${resolution_status}.`);
  res.json({ ok: true });
});

// 7. Append-Only Decision & Charter Ledger
app.get('/api/decisions', requireAuth, (_req, res) => {
  const decisions = db.prepare(`SELECT * FROM decisions ORDER BY created_at DESC`).all();
  res.json({ decisions });
});

app.post('/api/decisions', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may issue official PN-DECISION or PN-CHARTER records.' });
    return;
  }
  const body = req.body || {};
  if (!body.category || !body.subject || !body.content) {
    res.status(400).json({ error: 'category, subject, and content are required.' });
    return;
  }
  if (!['PN-CHARTER', 'PN-DECISION'].includes(body.category)) {
    res.status(400).json({ error: 'Category must be PN-CHARTER or PN-DECISION.' });
    return;
  }

  const recordRef = nextSequenceRef(db, body.category, body.category);
  const id = generateId('dec');

  if (body.supersedes_decision_id) {
    db.prepare(`UPDATE decisions SET approval_status = 'SUPERSEDED' WHERE id = ?`).run(body.supersedes_decision_id);
  }

  db.prepare(
    `INSERT INTO decisions (
      id, record_ref, category, subject, author_identity, author_user_id,
      project_id, task_id, report_id, content, supersedes_decision_id
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    recordRef,
    body.category,
    String(body.subject).trim(),
    `${req.authUser!.display_name} (G-0)`,
    req.authUser!.id,
    body.project_id || null,
    body.task_id || null,
    body.report_id || null,
    String(body.content).trim(),
    body.supersedes_decision_id || null
  );

  logActivity(db, req.authUser!, 'ISSUE_DECISION', 'DECISION', recordRef, `G-0 logged official ${recordRef}: ${body.subject}`);
  res.status(201).json({ ok: true, id, record_ref: recordRef });
});

// 8. Shared Knowledge Library (Documents)
app.get('/api/documents', requireAuth, (req: AuthedRequest, res) => {
  const q = String(req.query.q || '').trim();
  const proj = req.query.project_id ? String(req.query.project_id) : null;
  const dept = req.query.department_id ? String(req.query.department_id) : null;

  let sql = `SELECT d.id, d.title, d.doc_type, d.description, d.project_id, d.department_id,
                    d.filename, d.mime_type, d.size_bytes, d.version_number, d.parent_document_id,
                    d.access_level, d.is_sample, d.created_at, u.display_name AS uploaded_by_name
             FROM documents d JOIN users u ON u.id = d.uploaded_by WHERE 1=1`;
  const binds: string[] = [];

  if (!isDirector(req.authUser)) {
    sql += ` AND (d.access_level = 'COUNCIL_INTERNAL' OR (d.access_level = 'DEPARTMENT_RESTRICTED' AND d.department_id = ?))`;
    binds.push(req.authUser!.department_id || '');
  }
  if (proj) {
    sql += ' AND d.project_id = ?';
    binds.push(proj);
  }
  if (dept) {
    sql += ' AND d.department_id = ?';
    binds.push(dept);
  }
  if (q) {
    sql += ' AND (d.title LIKE ? OR d.description LIKE ? OR d.filename LIKE ?)';
    binds.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }
  sql += ' ORDER BY d.created_at DESC';

  const documents = binds.length ? db.prepare(sql).all(...binds) : db.prepare(sql).all();
  res.json({ documents });
});

app.post('/api/documents', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser) && req.authUser!.can_submit !== 1) {
    res.status(403).json({ error: 'Upload permission required.' });
    return;
  }
  const body = req.body || {};
  if (!body.title || !body.filename || !body.content_base64) {
    res.status(400).json({ error: 'title, filename, and content_base64 are required.' });
    return;
  }
  const sizeBytes = Number(body.size_bytes || 0);
  if (sizeBytes > 2_000_000 || String(body.content_base64).length > 2_800_000) {
    res.status(413).json({ error: 'File exceeds 2 MB document upload limit.' });
    return;
  }
  let version = 1;
  if (body.parent_document_id) {
    const parent = db.prepare(`SELECT version_number FROM documents WHERE id = ?`).get(body.parent_document_id) as { version_number: number } | undefined;
    if (parent) version = parent.version_number + 1;
  }
  const id = generateId('doc');
  db.prepare(
    `INSERT INTO documents (
      id, title, doc_type, description, project_id, department_id, filename, mime_type,
      size_bytes, content_base64, version_number, parent_document_id, access_level, uploaded_by
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    String(body.title).trim(),
    body.doc_type || 'REFERENCE',
    String(body.description || ''),
    body.project_id || null,
    body.department_id || req.authUser!.department_id || null,
    String(body.filename).trim(),
    body.mime_type || 'application/octet-stream',
    sizeBytes,
    String(body.content_base64),
    version,
    body.parent_document_id || null,
    isDirector(req.authUser) ? body.access_level || 'COUNCIL_INTERNAL' : 'COUNCIL_INTERNAL',
    req.authUser!.id
  );
  logActivity(db, req.authUser!, 'UPLOAD_DOC', 'DOCUMENT', id, `Uploaded document "${body.title}" (${body.filename}).`);
  res.status(201).json({ ok: true, id });
});

app.get('/api/documents/:docId/download', requireAuth, (req: AuthedRequest, res) => {
  const doc = db.prepare(`SELECT * FROM documents WHERE id = ?`).get(req.params.docId) as
    | { access_level: 'COUNCIL_INTERNAL' | 'DIRECTOR_ONLY' | 'DEPARTMENT_RESTRICTED'; department_id: string | null; content_base64: string; filename: string; mime_type: string }
    | undefined;
  if (!doc) {
    res.status(404).json({ error: 'Document not found.' });
    return;
  }
  if (!canViewDocument(req.authUser, doc)) {
    res.status(403).json({ error: 'Access denied for this document classification.' });
    return;
  }
  const buffer = Buffer.from(doc.content_base64, 'base64');
  const safeName = doc.filename.replace(/[^a-zA-Z0-9._-]/g, '_');
  res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.send(buffer);
});

// 9. AI Provider Integrations
app.get('/api/providers', requireAuth, (_req, res) => {
  const rows = db
    .prepare(
      `SELECT p.*, d.name AS department_name
       FROM ai_providers p JOIN departments d ON d.id = p.department_id
       ORDER BY d.sort_order ASC`
    )
    .all() as Array<Record<string, unknown>>;

  const providers = rows.map((p) => ({
    ...p,
    supported_operations: JSON.parse(String(p.supported_operations || '[]')),
    server_secret_configured: getEnvConfiguredFlag(String(p.id)),
  }));
  res.json({ providers });
});

app.post('/api/providers/:provId/test', requireAuth, async (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may run provider connection tests.' });
    return;
  }
  const { provId } = req.params;
  const existing = db.prepare(`SELECT * FROM ai_providers WHERE id = ?`).get(provId) as { provider_name: string } | undefined;
  if (!existing) {
    res.status(404).json({ error: 'Provider not found.' });
    return;
  }

  const outcome = await runProviderConnectionTest(provId);
  db.prepare(
    `UPDATE ai_providers
     SET connection_status = ?, auth_status = ?, last_tested_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now'),
         last_error = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
     WHERE id = ?`
  ).run(outcome.connection_status, outcome.auth_status, outcome.error, provId);

  logActivity(db, req.authUser!, 'TEST_PROVIDER', 'PROVIDER', provId, `Tested ${existing.provider_name}: ${outcome.connection_status} (${outcome.auth_status}).`);
  res.json({ ok: true, outcome });
});

// 10. User & Permission Management (G-0 Only)
app.get('/api/users', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may view and manage Council users.' });
    return;
  }
  const users = db
    .prepare(
      `SELECT u.id, u.username, u.display_name, u.role, u.department_id, u.can_submit,
              u.can_review, u.can_approve, u.is_active, u.created_at, u.last_login_at,
              d.name AS department_name
       FROM users u LEFT JOIN departments d ON d.id = u.department_id
       ORDER BY u.created_at ASC`
    )
    .all();
  res.json({ users });
});

app.post('/api/users', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may create Council accounts.' });
    return;
  }
  const body = req.body || {};
  if (!body.username || !body.display_name || !body.password || !body.role) {
    res.status(400).json({ error: 'username, display_name, password, and role are required.' });
    return;
  }
  if (String(body.password).length < 10) {
    res.status(400).json({ error: 'Password must be at least 10 characters.' });
    return;
  }
  if (!['G0_DIRECTOR', 'DEPT_MODEL', 'REVIEWER', 'READ_ONLY'].includes(body.role)) {
    res.status(400).json({ error: 'Invalid role.' });
    return;
  }
  const { hash, salt } = hashPassword(String(body.password));
  const id = generateId('usr');
  db.prepare(
    `INSERT INTO users (id, username, display_name, role, department_id, can_submit, can_review, can_approve, password_hash, password_salt)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    String(body.username).trim().toLowerCase(),
    String(body.display_name).trim(),
    body.role,
    body.department_id || null,
    body.can_submit ? 1 : 0,
    body.can_review ? 1 : 0,
    body.role === 'G0_DIRECTOR' ? 1 : 0,
    hash,
    salt
  );
  logActivity(db, req.authUser!, 'CREATE_USER', 'USER', id, `Created user ${body.username} (${body.role}).`);
  res.status(201).json({ ok: true, id });
});

app.patch('/api/users/:userId', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may modify user permissions.' });
    return;
  }
  const { userId } = req.params;
  const body = req.body || {};
  if (userId === req.authUser!.id && body.is_active === 0) {
    res.status(400).json({ error: 'Director G-0 cannot deactivate own active session account.' });
    return;
  }
  db.prepare(
    `UPDATE users
     SET is_active = COALESCE(?, is_active),
         can_submit = COALESCE(?, can_submit),
         can_review = COALESCE(?, can_review),
         department_id = COALESCE(?, department_id)
     WHERE id = ?`
  ).run(
    body.is_active !== undefined ? (body.is_active ? 1 : 0) : null,
    body.can_submit !== undefined ? (body.can_submit ? 1 : 0) : null,
    body.can_review !== undefined ? (body.can_review ? 1 : 0) : null,
    body.department_id !== undefined ? body.department_id || null : null,
    userId
  );
  logActivity(db, req.authUser!, 'UPDATE_USER', 'USER', userId, `Updated permissions for ${userId}.`);
  res.json({ ok: true });
});

// 11. Activity & Settings
app.get('/api/activity', requireAuth, (_req, res) => {
  const activity = db.prepare(`SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 100`).all();
  res.json({ activity });
});

app.get('/api/settings', requireAuth, (_req, res) => {
  const settings = db.prepare(`SELECT * FROM system_settings ORDER BY setting_key ASC`).all();
  res.json({ settings });
});

app.patch('/api/settings', requireAuth, (req: AuthedRequest, res) => {
  if (!isDirector(req.authUser)) {
    res.status(403).json({ error: 'Only Director G-0 may modify system settings.' });
    return;
  }
  const { setting_key, setting_value } = req.body || {};
  if (!setting_key || setting_value === undefined) {
    res.status(400).json({ error: 'setting_key and setting_value are required.' });
    return;
  }
  db.prepare(
    `INSERT INTO system_settings (setting_key, setting_value, updated_by, updated_at)
     VALUES (?, ?, ?, strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
     ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value, updated_by = excluded.updated_by, updated_at = excluded.updated_at`
  ).run(String(setting_key), String(setting_value), req.authUser!.username);
  logActivity(db, req.authUser!, 'UPDATE_SETTING', 'SETTINGS', String(setting_key), `Updated setting ${setting_key}.`);
  res.json({ ok: true });
});

// 12. Gemini Council Chatbot & Report Pre-Screen (Server-Side @google/genai)
app.get('/api/gemini/chat', requireAuth, (req: AuthedRequest, res) => {
  const threadId = String(req.query.thread_id || 'default');
  const messages = db
    .prepare(`SELECT id, role, department_scope, model_used, thinking_level, content, created_at FROM chat_messages WHERE user_id = ? AND thread_id = ? ORDER BY created_at ASC, rowid ASC`)
    .all(req.authUser!.id, threadId);
  res.json({ messages });
});

app.delete('/api/gemini/chat', requireAuth, (req: AuthedRequest, res) => {
  const threadId = String(req.query.thread_id || 'default');
  db.prepare(`DELETE FROM chat_messages WHERE user_id = ? AND thread_id = ?`).run(req.authUser!.id, threadId);
  res.json({ ok: true });
});

app.post('/api/gemini/chat', requireAuth, async (req: AuthedRequest, res) => {
  const body = req.body || {};
  const message = String(body.message || '').trim();
  const threadId = String(body.thread_id || 'default');
  const departmentScope = String(body.department_scope || 'council');
  const model: CouncilGeminiModel = body.model === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';
  const thinkingMode: CouncilThinkingMode = body.thinking_mode === 'LOW' ? 'LOW' : 'HIGH';

  if (!message) {
    res.status(400).json({ error: 'Message text is required.' });
    return;
  }

  const history = db
    .prepare(`SELECT role, content FROM chat_messages WHERE user_id = ? AND thread_id = ? ORDER BY created_at ASC, rowid ASC LIMIT 24`)
    .all(req.authUser!.id, threadId) as Array<{ role: 'user' | 'model'; content: string }>;

  const activeProjects = db.prepare(`SELECT id, name, priority, objective FROM projects WHERE status = 'ACTIVE' LIMIT 5`).all() as Array<{
    id: string;
    name: string;
    priority: string;
    objective: string;
  }>;
  const openTasks = db.prepare(`SELECT task_ref, objective, status FROM assignments WHERE status NOT IN ('Approved by G-0', 'Archived') LIMIT 8`).all() as Array<{
    task_ref: string;
    objective: string;
    status: string;
  }>;

  const workspaceContext = [
    `Active Projects: ${activeProjects.map((p) => `${p.id} (${p.priority}): ${p.name} — ${p.objective}`).join(' | ') || 'None'}`,
    `Open Assignments: ${openTasks.map((t) => `${t.task_ref} [${t.status}]: ${t.objective}`).join(' | ') || 'None'}`,
  ].join('\n');

  try {
    const result = await runCouncilChatTurn({
      history,
      message,
      departmentScope,
      model,
      thinkingMode,
      workspaceContext,
    });

    db.prepare(
      `INSERT INTO chat_messages (id, user_id, thread_id, role, department_scope, model_used, thinking_level, content)
       VALUES (?, ?, ?, 'user', ?, ?, ?, ?)`
    ).run(generateId('msg'), req.authUser!.id, threadId, departmentScope, result.modelUsed, result.thinkingUsed, message);

    const replyId = generateId('msg');
    db.prepare(
      `INSERT INTO chat_messages (id, user_id, thread_id, role, department_scope, model_used, thinking_level, content)
       VALUES (?, ?, ?, 'model', ?, ?, ?, ?)`
    ).run(replyId, req.authUser!.id, threadId, departmentScope, result.modelUsed, result.thinkingUsed, result.reply);

    logActivity(db, req.authUser!, 'GEMINI_CHAT', 'GEMINI', threadId, `Council chat turn (${result.modelUsed}, thinking=${result.thinkingUsed}).`);
    res.json({ ok: true, reply: result.reply, modelUsed: result.modelUsed, thinkingUsed: result.thinkingUsed });
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : 'Gemini request failed.';
    res.status(502).json({ error: errorMsg });
  }
});

app.post('/api/gemini/analyze-report', requireAuth, async (req: AuthedRequest, res) => {
  const { report_id } = req.body || {};
  if (!report_id) {
    res.status(400).json({ error: 'report_id is required.' });
    return;
  }
  const rep = db.prepare(`SELECT * FROM reports WHERE id = ?`).get(report_id) as
    | { report_ref: string; objective: string; findings: string; evidence: string; assumptions: string; limitations: string; risks: string }
    | undefined;
  if (!rep) {
    res.status(404).json({ error: 'Report not found.' });
    return;
  }

  try {
    const analysis = await runGeminiReportAnalysis({
      reportRef: rep.report_ref,
      objective: rep.objective,
      findings: rep.findings,
      evidence: rep.evidence,
      assumptions: rep.assumptions,
      limitations: rep.limitations,
      risks: rep.risks,
    });
    logActivity(db, req.authUser!, 'GEMINI_ANALYZE_REPORT', 'REPORT', rep.report_ref, `Ran Gemini verification pre-screen on ${rep.report_ref}.`);
    res.json({ ok: true, analysis });
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : 'Gemini report analysis failed.';
    res.status(502).json({ error: errorMsg });
  }
});

async function startServer(): Promise<void> {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  const port = Number(process.env.PORT || 3000);
  app.listen(port, '0.0.0.0', () => {
    console.log(`PATRIOT-NEXUS server listening on http://0.0.0.0:${port}`);
  });
}

startServer();
