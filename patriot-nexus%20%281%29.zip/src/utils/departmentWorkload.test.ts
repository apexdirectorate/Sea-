import test from 'node:test';
import assert from 'node:assert/strict';
import { getDepartmentWorkloadIndicator } from './departmentWorkload';

test('getDepartmentWorkloadIndicator maps active counts to dynamic states', () => {
  const idle = getDepartmentWorkloadIndicator({ activeCount: 0, inProgressCount: 0, revisionRequiredCount: 0 });
  assert.equal(idle.state, 'IDLE');
  assert.equal(idle.label, 'Standby');
  assert.equal(idle.countLabel, '0 Active');

  const queued = getDepartmentWorkloadIndicator({ activeCount: 2, inProgressCount: 0, revisionRequiredCount: 0 });
  assert.equal(queued.state, 'QUEUED');
  assert.equal(queued.label, 'Active Queue');
  assert.equal(queued.countLabel, '2 Active');

  const executing = getDepartmentWorkloadIndicator({ activeCount: 3, inProgressCount: 1, revisionRequiredCount: 0 });
  assert.equal(executing.state, 'EXECUTING');
  assert.equal(executing.label, 'Executing');
  assert.equal(executing.countLabel, '3 Active');

  // Revision required takes highest visual priority when active
  const revision = getDepartmentWorkloadIndicator({ activeCount: 3, inProgressCount: 1, revisionRequiredCount: 1 });
  assert.equal(revision.state, 'REVISION_REQUIRED');
  assert.equal(revision.label, 'Revision Req.');
  assert.equal(revision.countLabel, '3 Active');
});
