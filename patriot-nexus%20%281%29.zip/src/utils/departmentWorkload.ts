export type DepartmentWorkloadState = 'IDLE' | 'QUEUED' | 'EXECUTING' | 'REVISION_REQUIRED';

export interface DepartmentWorkloadIndicator {
  state: DepartmentWorkloadState;
  label: string;
  countLabel: string;
  secondaryDetail: string | null;
  containerClass: string;
  dotClass: string;
  countClass: string;
}

export function getDepartmentWorkloadIndicator(params: {
  activeCount?: number | null;
  inProgressCount?: number | null;
  revisionRequiredCount?: number | null;
}): DepartmentWorkloadIndicator {
  const activeCount = Math.max(0, Number(params.activeCount ?? 0) || 0);
  const inProgressCount = Math.max(0, Number(params.inProgressCount ?? 0) || 0);
  const revisionRequiredCount = Math.max(0, Number(params.revisionRequiredCount ?? 0) || 0);

  if (activeCount === 0) {
    return {
      state: 'IDLE',
      label: 'Standby',
      countLabel: '0 Active',
      secondaryDetail: null,
      containerClass: 'border-[#1f2c3d] bg-[#0e151f] text-slate-400',
      dotClass: 'bg-slate-500',
      countClass: 'text-slate-400',
    };
  }

  if (revisionRequiredCount > 0) {
    return {
      state: 'REVISION_REQUIRED',
      label: 'Revision Req.',
      countLabel: `${activeCount} Active`,
      secondaryDetail: `${revisionRequiredCount} revision`,
      containerClass: 'border-amber-800/70 bg-amber-950/35 text-amber-200',
      dotClass: 'bg-amber-400 animate-pulse',
      countClass: 'text-amber-300',
    };
  }

  if (inProgressCount > 0) {
    return {
      state: 'EXECUTING',
      label: 'Executing',
      countLabel: `${activeCount} Active`,
      secondaryDetail: `${inProgressCount} in progress`,
      containerClass: 'border-emerald-800/70 bg-emerald-950/35 text-emerald-200',
      dotClass: 'bg-emerald-400 animate-pulse',
      countClass: 'text-emerald-300',
    };
  }

  return {
    state: 'QUEUED',
    label: 'Active Queue',
    countLabel: `${activeCount} Active`,
    secondaryDetail: null,
    containerClass: 'border-sky-800/70 bg-sky-950/35 text-sky-200',
    dotClass: 'bg-sky-400 animate-pulse',
    countClass: 'text-sky-300',
  };
}
