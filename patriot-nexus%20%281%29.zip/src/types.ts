export type PageId =
  | 'dashboard'
  | 'director'
  | 'departments'
  | 'projects'
  | 'assignments'
  | 'reports'
  | 'reviews'
  | 'decisions'
  | 'library'
  | 'providers'
  | 'users'
  | 'settings';

export type UserRole = 'G0_DIRECTOR' | 'DEPT_MODEL' | 'REVIEWER' | 'READ_ONLY';

export interface User {
  id: string;
  username: string;
  display_name: string;
  role: UserRole;
  department_id: string | null;
  department_name?: string | null;
  can_submit: number;
  can_review: number;
  can_approve: number;
  is_active: number;
  created_at?: string;
  last_login_at?: string | null;
}

export interface AuthStatus {
  needs_bootstrap: boolean;
  requires_bootstrap_token: boolean;
  authenticated: boolean;
  user: User | null;
}

export interface Department {
  id: string;
  code: string;
  sort_order: number;
  name: string;
  assigned_model: string;
  application_name: string;
  responsibilities: string;
  limitations: string;
  testing_requirements: string;
  status: 'PROVISIONAL' | 'ACTIVE' | 'TESTING' | 'SUSPENDED';
  updated_at: string;
  active_assignment_count?: number;
  in_progress_count?: number;
  revision_required_count?: number;
}

export interface Project {
  id: string;
  name: string;
  objective: string;
  description: string;
  status: 'PROPOSED' | 'ACTIVE' | 'PAUSED' | 'CLOSED';
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  assigned_departments: string;
  required_deliverables: string;
  dependencies: string;
  risks: string;
  director_approval_status: 'PENDING_G0' | 'APPROVED_BY_G0' | 'REJECTED_BY_G0';
  is_sample: number;
  created_at: string;
  updated_at: string;
}

export interface Assignment {
  id: string;
  task_ref: string;
  project_id: string;
  project_name?: string;
  objective: string;
  instructions: string;
  assigned_department_id: string;
  department_name?: string;
  assigned_model?: string;
  batch_group_id: string | null;
  required_output: string;
  supporting_files: string;
  due_date: string | null;
  status: string;
  is_sample: number;
  created_at: string;
}

export interface CouncilReport {
  id: string;
  report_ref: string;
  project_id: string;
  project_name?: string;
  task_id: string;
  task_ref?: string;
  department_id: string;
  department_name?: string;
  department_code?: string;
  submitted_by_user_id: string;
  model_application: string;
  objective: string;
  findings: string;
  evidence: string;
  assumptions: string;
  limitations: string;
  risks: string;
  recommendations: string;
  unresolved_questions: string;
  parent_report_id: string | null;
  version_number: number;
  director_status: 'PENDING' | 'ACKNOWLEDGED' | 'APPROVED_BY_G0' | 'REJECTED_BY_G0';
  is_sample: number;
  created_at: string;
}

export interface CouncilReview {
  id: string;
  review_ref: string;
  report_id: string;
  report_ref?: string;
  project_id: string;
  task_id: string;
  reviewer_department_id: string;
  reviewer_department_name?: string;
  reviewer_dept_model?: string;
  reviewer_user_id: string;
  reviewer_model: string;
  author_model?: string;
  verdict: string;
  summary: string;
  technical_notes: string;
  disagreements: string;
  evidence_gaps: string;
  recommended_tests: string;
  is_dispute: number;
  resolution_status: 'OPEN' | 'ADDRESSED' | 'OVERRULED_BY_G0' | 'UPHELD_BY_G0';
  created_at: string;
}

export interface DecisionRecord {
  id: string;
  record_ref: string;
  category: 'PN-CHARTER' | 'PN-DECISION';
  subject: string;
  author_identity: string;
  project_id: string | null;
  task_id: string | null;
  report_id: string | null;
  content: string;
  supersedes_decision_id: string | null;
  approval_status: 'APPROVED_BY_G0' | 'SUPERSEDED';
  is_sample: number;
  created_at: string;
}

export interface DocumentItem {
  id: string;
  title: string;
  doc_type: string;
  description: string;
  project_id: string | null;
  department_id: string | null;
  filename: string;
  mime_type: string;
  size_bytes: number;
  version_number: number;
  parent_document_id: string | null;
  access_level: 'COUNCIL_INTERNAL' | 'DIRECTOR_ONLY' | 'DEPARTMENT_RESTRICTED';
  uploaded_by_name?: string;
  is_sample: number;
  created_at: string;
}

export interface AIProvider {
  id: string;
  provider_name: string;
  model_name: string;
  department_id: string;
  department_name: string;
  adapter_type: 'API_SUPPORTED' | 'MANUAL_WORKFLOW' | 'CUSTOM_ENDPOINT';
  env_secret_name: string | null;
  connection_status: 'NOT CONNECTED' | 'CONNECTED' | 'ERROR';
  auth_status: 'UNCONFIGURED' | 'CONFIGURED_UNVERIFIED' | 'VERIFIED' | 'FAILED';
  available_permissions: string;
  supported_operations: string[];
  server_secret_configured: boolean;
  last_tested_at: string | null;
  last_error: string | null;
}

export interface ActivityLog {
  id: string;
  actor_label: string;
  action_type: string;
  target_type: string;
  target_id: string;
  summary: string;
  created_at: string;
}

export interface SystemSetting {
  setting_key: string;
  setting_value: string;
  updated_by: string | null;
  updated_at: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  department_scope: string;
  model_used: string;
  thinking_level: string;
  content: string;
  created_at: string;
}

export interface DashboardPayload {
  departments: Department[];
  active_projects: Project[];
  pending_assignments: Assignment[];
  submitted_reports: CouncilReport[];
  awaiting_verification: CouncilReport[];
  unresolved_disagreements: CouncilReview[];
  recent_decisions: DecisionRecord[];
  recent_activity: ActivityLog[];
  providers: Array<Pick<AIProvider, 'id' | 'provider_name' | 'model_name' | 'department_id' | 'connection_status' | 'auth_status'>>;
  server_time?: string;
}

export interface GlobalSearchResponse {
  query: string;
  departments: Array<Pick<Department, 'id' | 'code' | 'name' | 'assigned_model' | 'application_name' | 'status'>>;
  projects: Array<Pick<Project, 'id' | 'name' | 'objective' | 'status' | 'priority'>>;
  documents: Array<Pick<DocumentItem, 'id' | 'title' | 'doc_type' | 'description' | 'filename' | 'version_number' | 'access_level' | 'department_id' | 'project_id'>>;
  total: number;
}
