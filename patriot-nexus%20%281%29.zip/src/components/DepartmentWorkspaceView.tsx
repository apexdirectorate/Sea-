import React, { useEffect, useState } from 'react';
import { apiRequest, downloadAuthorizedFile } from '../api/client';
import type { Assignment, CouncilReport, CouncilReview, Department, DocumentItem, User } from '../types';
import { StatusTag } from './StatusTag';

interface DepartmentWorkspaceViewProps {
  departments: Department[];
  selectedDeptId: string;
  onSelectDept: (id: string) => void;
  user: User;
  onRefreshDashboard: () => Promise<void>;
}

interface DeptDetailResponse {
  department: Department;
  assignments: Assignment[];
  reports: CouncilReport[];
  documents: DocumentItem[];
  reviews: CouncilReview[];
}

export const DepartmentWorkspaceView: React.FC<DepartmentWorkspaceViewProps> = ({
  departments,
  selectedDeptId,
  onSelectDept,
  user,
  onRefreshDashboard,
}) => {
  const [detail, setDetail] = useState<DeptDetailResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [statusEdit, setStatusEdit] = useState('PROVISIONAL');
  const [saving, setSaving] = useState(false);

  const isG0 = user.role === 'G0_DIRECTOR';

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError('');
    apiRequest<DeptDetailResponse>(`departments/${selectedDeptId}`)
      .then((res) => {
        if (!active) return;
        setDetail(res);
        setStatusEdit(res.department.status);
      })
      .catch((err) => {
        if (!active) return;
        setError(err instanceof Error ? err.message : 'Failed to load department workspace.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [selectedDeptId]);

  async function handleStatusUpdate(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setError('');
    try {
      await apiRequest(`departments/${selectedDeptId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status: statusEdit }),
      });
      const updated = await apiRequest<DeptDetailResponse>(`departments/${selectedDeptId}`);
      setDetail(updated);
      await onRefreshDashboard();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update department status.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white mb-3">Eight Department Workspaces</h1>
        <div className="flex flex-wrap gap-2">
          {departments.map((d) => (
            <button
              key={d.id}
              type="button"
              onClick={() => onSelectDept(d.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md border transition-colors whitespace-nowrap ${
                d.id === selectedDeptId
                  ? 'bg-sky-600 border-sky-500 text-white'
                  : 'bg-[#182230] border-[#243247] text-slate-300 hover:text-white'
              }`}
            >
              {d.assigned_model}
            </button>
          ))}
        </div>
      </div>

      {loading && <div className="bg-[#121923] border border-[#243247] rounded-lg p-5 text-sm text-slate-400">Loading department workspace...</div>}
      {error && <div role="alert" className="bg-rose-950/40 border border-rose-800/70 rounded-lg p-4 text-sm text-rose-300">{error}</div>}

      {detail && !loading && (
        <>
          <section className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-white">{detail.department.name}</h2>
                <p className="text-xs text-slate-400 mt-1">
                  Assigned Model: <strong className="text-slate-200">{detail.department.assigned_model}</strong>
                  <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
                  Application: <strong className="text-slate-200">{detail.department.application_name}</strong>
                </p>
              </div>
              <StatusTag value={detail.department.status} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-[#1e2a3b] text-sm">
              <div>
                <div className="text-xs font-semibold text-slate-400 mb-1">Responsibilities</div>
                <p className="text-slate-200 leading-relaxed">{detail.department.responsibilities}</p>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-400 mb-1">Known Limitations</div>
                <p className="text-slate-200 leading-relaxed">{detail.department.limitations}</p>
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-400 mb-1">Testing Requirements</div>
                <p className="text-slate-200 leading-relaxed">{detail.department.testing_requirements}</p>
              </div>
            </div>

            {isG0 && (
              <form onSubmit={handleStatusUpdate} className="pt-3 border-t border-[#1e2a3b] flex flex-wrap items-center gap-3">
                <label htmlFor="dept-status-select" className="text-xs text-slate-400">
                  Department Status (G-0):
                </label>
                <select
                  id="dept-status-select"
                  value={statusEdit}
                  onChange={(e) => setStatusEdit(e.target.value)}
                  className="px-3 py-1.5 text-xs bg-[#0b1017] border border-[#243247] rounded-md text-white"
                >
                  <option value="PROVISIONAL">PROVISIONAL</option>
                  <option value="TESTING">TESTING</option>
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="SUSPENDED">SUSPENDED</option>
                </select>
                <button
                  type="submit"
                  disabled={saving}
                  className="px-3.5 py-1.5 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
                >
                  {saving ? 'Saving...' : 'Update Status'}
                </button>
              </form>
            )}
          </section>

          <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
              <h3 className="text-base font-semibold text-white mb-3">
                Current Assignments ({detail.assignments.length})
              </h3>
              {detail.assignments.length === 0 ? (
                <p className="text-sm text-slate-400">No assignments currently assigned to this department.</p>
              ) : (
                <div className="divide-y divide-[#1e2a3b]">
                  {detail.assignments.map((a) => (
                    <div key={a.id} className="py-3 first:pt-0 last:pb-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-mono-tabular text-sky-300">{a.task_ref}</span>
                        <StatusTag value={a.status} />
                      </div>
                      <div className="text-sm text-white mt-1">{a.objective}</div>
                      <div className="text-xs text-slate-400 mt-0.5">{a.project_name}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
              <h3 className="text-base font-semibold text-white mb-3">
                Submitted Reports ({detail.reports.length})
              </h3>
              {detail.reports.length === 0 ? (
                <p className="text-sm text-slate-400">No reports submitted by this department.</p>
              ) : (
                <div className="divide-y divide-[#1e2a3b]">
                  {detail.reports.map((r) => (
                    <div key={r.id} className="py-3 first:pt-0 last:pb-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-mono-tabular text-sky-300">{r.report_ref}</span>
                        <StatusTag value={r.director_status} />
                      </div>
                      <div className="text-sm text-white mt-1">{r.objective}</div>
                      <div className="text-xs text-slate-400 mt-0.5 font-mono-tabular">{r.created_at}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
              <h3 className="text-base font-semibold text-white mb-3">
                Research Documents ({detail.documents.length})
              </h3>
              {detail.documents.length === 0 ? (
                <p className="text-sm text-slate-400">No documents attached to this department.</p>
              ) : (
                <div className="divide-y divide-[#1e2a3b]">
                  {detail.documents.map((doc) => (
                    <div key={doc.id} className="py-2.5 first:pt-0 last:pb-0 flex items-center justify-between gap-2">
                      <div>
                        <div className="text-sm text-white">{doc.title}</div>
                        <div className="text-xs text-slate-400 font-mono-tabular">{doc.filename}</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setError('');
                          downloadAuthorizedFile(doc.id, doc.filename).catch((err) => {
                            setError(err instanceof Error ? err.message : 'Download failed.');
                          });
                        }}
                        className="text-xs text-sky-400 hover:underline whitespace-nowrap"
                      >
                        Download
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
              <h3 className="text-base font-semibold text-white mb-3">
                Review History ({detail.reviews.length})
              </h3>
              {detail.reviews.length === 0 ? (
                <p className="text-sm text-slate-400">No review activity recorded for this department.</p>
              ) : (
                <div className="divide-y divide-[#1e2a3b]">
                  {detail.reviews.map((rv) => (
                    <div key={rv.id} className="py-3 first:pt-0 last:pb-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-mono-tabular text-sky-300">
                          {rv.review_ref} · {rv.report_ref}
                        </span>
                        <StatusTag value={rv.verdict} />
                      </div>
                      <div className="text-sm text-slate-200 mt-1">{rv.summary}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        </>
      )}
    </div>
  );
};
