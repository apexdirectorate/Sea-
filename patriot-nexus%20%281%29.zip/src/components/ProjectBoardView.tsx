import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { Department, Project, User } from '../types';
import { StatusTag } from './StatusTag';

interface ProjectBoardViewProps {
  projects: Project[];
  departments: Department[];
  user: User;
  onRefresh: () => Promise<void>;
}

export const ProjectBoardView: React.FC<ProjectBoardViewProps> = ({
  projects,
  departments,
  user,
  onRefresh,
}) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const [customId, setCustomId] = useState('');
  const [name, setName] = useState('');
  const [objective, setObjective] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'>('HIGH');
  const [status, setStatus] = useState<'ACTIVE' | 'PROPOSED' | 'PAUSED'>('ACTIVE');
  const [deliverables, setDeliverables] = useState('');
  const [dependencies, setDependencies] = useState('');
  const [risks, setRisks] = useState('');
  const [selectedDepts, setSelectedDepts] = useState<string[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [editObjective, setEditObjective] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editPriority, setEditPriority] = useState<'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW'>('HIGH');
  const [editStatus, setEditStatus] = useState<'PROPOSED' | 'ACTIVE' | 'PAUSED' | 'CLOSED'>('ACTIVE');
  const [editDeliverables, setEditDeliverables] = useState('');
  const [editDependencies, setEditDependencies] = useState('');
  const [editRisks, setEditRisks] = useState('');
  const [editDepts, setEditDepts] = useState<string[]>([]);
  const [savingEdit, setSavingEdit] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  function toggleDept(deptId: string) {
    setSelectedDepts((prev) =>
      prev.includes(deptId) ? prev.filter((id) => id !== deptId) : [...prev, deptId]
    );
  }

  function startEdit(p: Project) {
    setError('');
    setEditingId(p.id);
    setEditName(p.name);
    setEditObjective(p.objective);
    setEditDescription(p.description);
    setEditPriority(p.priority);
    setEditStatus(p.status);
    setEditDeliverables(p.required_deliverables || '');
    setEditDependencies(p.dependencies || '');
    setEditRisks(p.risks || '');
    try {
      setEditDepts(JSON.parse(p.assigned_departments || '[]'));
    } catch {
      setEditDepts([]);
    }
  }

  function toggleEditDept(deptId: string) {
    setEditDepts((prev) =>
      prev.includes(deptId) ? prev.filter((id) => id !== deptId) : [...prev, deptId]
    );
  }

  async function handleSaveEdit(e: React.FormEvent, projectId: string) {
    e.preventDefault();
    setError('');
    setSavingEdit(true);
    try {
      await apiRequest(`projects/${projectId}`, {
        method: 'PATCH',
        body: JSON.stringify({
          name: editName,
          objective: editObjective,
          description: editDescription,
          priority: editPriority,
          status: editStatus,
          required_deliverables: editDeliverables,
          dependencies: editDependencies,
          risks: editRisks,
          assigned_departments: editDepts,
          history_note: `Project details edited by Director G-0.`,
        }),
      });
      setEditingId(null);
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save project edits.');
    } finally {
      setSavingEdit(false);
    }
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await apiRequest('projects', {
        method: 'POST',
        body: JSON.stringify({
          id: customId.trim() || undefined,
          name,
          objective,
          description,
          priority,
          status,
          required_deliverables: deliverables,
          dependencies,
          risks,
          assigned_departments: selectedDepts,
        }),
      });
      setCustomId('');
      setName('');
      setObjective('');
      setDescription('');
      setDeliverables('');
      setDependencies('');
      setRisks('');
      setSelectedDepts([]);
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create project.');
    } finally {
      setSubmitting(false);
    }
  }

  async function changeProjectStatus(id: string, nextStatus: string) {
    setError('');
    try {
      await apiRequest(`projects/${id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          status: nextStatus,
          history_note: `Project status updated to ${nextStatus} by Director G-0.`,
        }),
      });
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update project.');
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">Central Project Board</h1>
        <p className="text-sm text-slate-400 mt-1">
          Shared authorized project records for 420 Robotics. Only Director G-0 may create, edit, pause, close, or alter approved project objectives.
        </p>
      </div>

      {isG0 && (
        <form onSubmit={handleCreate} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
          <h2 className="text-base font-semibold text-white">Create Official Project (G-0)</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="proj-id" className="block text-xs font-medium text-slate-300 mb-1">
                Project ID (optional)
              </label>
              <input
                id="proj-id"
                type="text"
                value={customId}
                onChange={(e) => setCustomId(e.target.value)}
                placeholder="PN-PROJ-420-ARM"
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
            <div>
              <label htmlFor="proj-name" className="block text-xs font-medium text-slate-300 mb-1">
                Project Name
              </label>
              <input
                id="proj-name"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="420 Robotics Manipulator Actuator Rig"
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
          </div>

          <div>
            <label htmlFor="proj-objective" className="block text-xs font-medium text-slate-300 mb-1">
              Objective
            </label>
            <input
              id="proj-objective"
              type="text"
              required
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>

          <div>
            <label htmlFor="proj-desc" className="block text-xs font-medium text-slate-300 mb-1">
              Description
            </label>
            <textarea
              id="proj-desc"
              required
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="proj-priority" className="block text-xs font-medium text-slate-300 mb-1">
                Priority
              </label>
              <select
                id="proj-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value as 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW')}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="CRITICAL">CRITICAL</option>
                <option value="HIGH">HIGH</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="LOW">LOW</option>
              </select>
            </div>
            <div>
              <label htmlFor="proj-status" className="block text-xs font-medium text-slate-300 mb-1">
                Initial Status
              </label>
              <select
                id="proj-status"
                value={status}
                onChange={(e) => setStatus(e.target.value as 'ACTIVE' | 'PROPOSED' | 'PAUSED')}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="ACTIVE">ACTIVE</option>
                <option value="PROPOSED">PROPOSED</option>
                <option value="PAUSED">PAUSED</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="proj-deliv" className="block text-xs font-medium text-slate-300 mb-1">
                Required Deliverables
              </label>
              <input
                id="proj-deliv"
                type="text"
                value={deliverables}
                onChange={(e) => setDeliverables(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
            <div>
              <label htmlFor="proj-deps" className="block text-xs font-medium text-slate-300 mb-1">
                Dependencies
              </label>
              <input
                id="proj-deps"
                type="text"
                value={dependencies}
                onChange={(e) => setDependencies(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
            <div>
              <label htmlFor="proj-risks" className="block text-xs font-medium text-slate-300 mb-1">
                Risks
              </label>
              <input
                id="proj-risks"
                type="text"
                value={risks}
                onChange={(e) => setRisks(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
          </div>

          <div>
            <div className="text-xs font-medium text-slate-300 mb-2">Assigned Departments</div>
            <div className="flex flex-wrap gap-3">
              {departments.map((d) => (
                <label key={d.id} className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedDepts.includes(d.id)}
                    onChange={() => toggleDept(d.id)}
                    className="rounded border-[#243247] bg-[#0b1017]"
                  />
                  <span>{d.assigned_model}</span>
                </label>
              ))}
            </div>
          </div>

          {error && (
            <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="px-4 py-2 text-sm font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
          >
            {submitting ? 'Creating Project...' : 'Create Official Project'}
          </button>
        </form>
      )}

      <div className="space-y-4">
        {projects.length === 0 ? (
          <div className="bg-[#121923] border border-[#243247] rounded-lg p-6 text-sm text-slate-400">
            No projects exist yet.
          </div>
        ) : (
          projects.map((p) => {
            const deptIds: string[] = (() => {
              try {
                return JSON.parse(p.assigned_departments || '[]');
              } catch {
                return [];
              }
            })();
            return (
              <div key={p.id} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="text-xs font-mono-tabular text-sky-300 mr-2">{p.id}</span>
                    <span className="text-base font-bold text-white">{p.name}</span>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    {p.is_sample === 1 && <StatusTag value="SAMPLE DATA" />}
                    <StatusTag value={p.priority} />
                    <StatusTag value={p.status} />
                    <StatusTag value={p.director_approval_status} />
                  </div>
                </div>
                <p className="text-sm text-slate-200">
                  <strong>Objective:</strong> {p.objective}
                </p>
                <p className="text-sm text-slate-400">{p.description}</p>
                <div className="text-xs text-slate-400 space-y-1 pt-1">
                  <div>
                    <strong>Assigned Departments:</strong>{' '}
                    {deptIds.length
                      ? deptIds
                          .map((id) => departments.find((d) => d.id === id)?.assigned_model || id)
                          .join(', ')
                      : 'Unassigned'}
                  </div>
                  <div>
                    <strong>Deliverables:</strong> {p.required_deliverables || 'None specified'}
                    <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
                    <strong>Dependencies:</strong> {p.dependencies || 'None'}
                    <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
                    <strong>Risks:</strong> {p.risks || 'None'}
                  </div>
                </div>
                {isG0 && editingId === p.id && (
                  <form onSubmit={(e) => handleSaveEdit(e, p.id)} className="pt-3 border-t border-sky-800/60 space-y-3">
                    <div className="text-xs font-semibold text-sky-300">Editing {p.id}</div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div className="md:col-span-2">
                        <label htmlFor={`edit-name-${p.id}`} className="block text-xs text-slate-300 mb-1">
                          Project Name
                        </label>
                        <input
                          id={`edit-name-${p.id}`}
                          type="text"
                          required
                          value={editName}
                          onChange={(e) => setEditName(e.target.value)}
                          className="w-full px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
                        />
                      </div>
                      <div>
                        <label htmlFor={`edit-priority-${p.id}`} className="block text-xs text-slate-300 mb-1">
                          Priority
                        </label>
                        <select
                          id={`edit-priority-${p.id}`}
                          value={editPriority}
                          onChange={(e) => setEditPriority(e.target.value as 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW')}
                          className="w-full px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
                        >
                          <option value="CRITICAL">CRITICAL</option>
                          <option value="HIGH">HIGH</option>
                          <option value="MEDIUM">MEDIUM</option>
                          <option value="LOW">LOW</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label htmlFor={`edit-obj-${p.id}`} className="block text-xs text-slate-300 mb-1">
                        Objective
                      </label>
                      <input
                        id={`edit-obj-${p.id}`}
                        type="text"
                        required
                        value={editObjective}
                        onChange={(e) => setEditObjective(e.target.value)}
                        className="w-full px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
                      />
                    </div>
                    <div>
                      <label htmlFor={`edit-desc-${p.id}`} className="block text-xs text-slate-300 mb-1">
                        Description
                      </label>
                      <textarea
                        id={`edit-desc-${p.id}`}
                        required
                        rows={2}
                        value={editDescription}
                        onChange={(e) => setEditDescription(e.target.value)}
                        className="w-full px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <input
                        aria-label="Edit required deliverables"
                        type="text"
                        value={editDeliverables}
                        onChange={(e) => setEditDeliverables(e.target.value)}
                        placeholder="Required deliverables"
                        className="px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-xs text-white"
                      />
                      <input
                        aria-label="Edit dependencies"
                        type="text"
                        value={editDependencies}
                        onChange={(e) => setEditDependencies(e.target.value)}
                        placeholder="Dependencies"
                        className="px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-xs text-white"
                      />
                      <input
                        aria-label="Edit risks"
                        type="text"
                        value={editRisks}
                        onChange={(e) => setEditRisks(e.target.value)}
                        placeholder="Risks"
                        className="px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-xs text-white"
                      />
                    </div>
                    <div className="flex flex-wrap gap-3">
                      {departments.map((d) => (
                        <label key={d.id} className="inline-flex items-center gap-1.5 text-xs text-slate-200 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editDepts.includes(d.id)}
                            onChange={() => toggleEditDept(d.id)}
                            className="rounded border-[#243247] bg-[#0b1017]"
                          />
                          <span>{d.assigned_model}</span>
                        </label>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="submit"
                        disabled={savingEdit}
                        className="px-3.5 py-1.5 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
                      >
                        {savingEdit ? 'Saving...' : 'Save Changes'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        className="px-3.5 py-1.5 text-xs font-medium bg-[#182230] border border-[#243247] text-slate-300 rounded-md"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                )}

                {isG0 && (
                  <div className="flex flex-wrap gap-2 pt-2 border-t border-[#1e2a3b]">
                    <button
                      type="button"
                      onClick={() => startEdit(p)}
                      className="px-3 py-1.5 text-xs font-semibold bg-sky-950/60 hover:bg-sky-900/70 border border-sky-800/70 text-sky-200 rounded-md"
                    >
                      Edit Project
                    </button>
                    <button
                      type="button"
                      onClick={() => changeProjectStatus(p.id, 'ACTIVE')}
                      className="px-3 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md"
                    >
                      Set Active
                    </button>
                    <button
                      type="button"
                      onClick={() => changeProjectStatus(p.id, 'PAUSED')}
                      className="px-3 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md"
                    >
                      Pause
                    </button>
                    <button
                      type="button"
                      onClick={() => changeProjectStatus(p.id, 'CLOSED')}
                      className="px-3 py-1.5 text-xs font-medium bg-rose-950/60 hover:bg-rose-900/70 border border-rose-800/70 text-rose-200 rounded-md"
                    >
                      Close Project
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
