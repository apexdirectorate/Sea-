import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { SystemSetting, User } from '../types';

interface SystemSettingsViewProps {
  settings: SystemSetting[];
  user: User;
  onRefresh: () => Promise<void>;
}

export const SystemSettingsView: React.FC<SystemSettingsViewProps> = ({
  settings,
  user,
  onRefresh,
}) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const [editingKey, setEditingKey] = useState('');
  const [editingValue, setEditingValue] = useState('');
  const [error, setError] = useState('');

  async function saveSetting(e: React.FormEvent) {
    e.preventDefault();
    if (!editingKey) return;
    setError('');
    try {
      await apiRequest('settings', {
        method: 'PATCH',
        body: JSON.stringify({ setting_key: editingKey, setting_value: editingValue }),
      });
      setEditingKey('');
      setEditingValue('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update setting.');
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">System Settings &amp; Governance Policies</h1>
        <p className="text-sm text-slate-400 mt-1">
          Core Council parameters stored persistently in SQLite. Only Director G-0 may update governance policies.
        </p>
      </div>

      {isG0 && editingKey && (
        <form onSubmit={saveSetting} className="bg-[#121923] border border-sky-700/70 rounded-lg p-5 flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[200px]">
            <label htmlFor="set-val" className="block text-xs font-medium text-slate-300 mb-1">
              Update Value for <span className="font-mono-tabular text-sky-300">{editingKey}</span>
            </label>
            <input
              id="set-val"
              type="text"
              required
              value={editingValue}
              onChange={(e) => setEditingValue(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <button type="submit" className="px-4 py-2 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md">
            Save Setting
          </button>
          <button
            type="button"
            onClick={() => setEditingKey('')}
            className="px-4 py-2 text-xs font-medium bg-[#182230] border border-[#243247] text-slate-300 rounded-md"
          >
            Cancel
          </button>
        </form>
      )}

      {error && (
        <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-3">
          {error}
        </div>
      )}

      <div className="bg-[#121923] border border-[#243247] rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-[#243247] text-xs text-slate-400 bg-[#0e141d]">
                <th className="py-3 px-4 font-semibold">Setting Key</th>
                <th className="py-3 px-4 font-semibold">Value</th>
                <th className="py-3 px-4 font-semibold">Updated By</th>
                <th className="py-3 px-4 font-semibold">Updated At</th>
                {isG0 && <th className="py-3 px-4 font-semibold">Edit</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e2a3b]">
              {settings.map((s) => (
                <tr key={s.setting_key}>
                  <td className="py-3 px-4 font-mono-tabular text-xs text-sky-300">{s.setting_key}</td>
                  <td className="py-3 px-4 text-sm text-white">{s.setting_value}</td>
                  <td className="py-3 px-4 text-xs text-slate-400">{s.updated_by || 'SYSTEM'}</td>
                  <td className="py-3 px-4 text-xs font-mono-tabular text-slate-400">{s.updated_at}</td>
                  {isG0 && (
                    <td className="py-3 px-4">
                      <button
                        type="button"
                        onClick={() => {
                          setEditingKey(s.setting_key);
                          setEditingValue(s.setting_value);
                        }}
                        className="px-2.5 py-1 text-xs bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded"
                      >
                        Edit
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
