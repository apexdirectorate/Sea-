import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { Assignment, Department, Project, User } from '../types';
import { StatusTag } from './StatusTag';

interface AssignmentManagerViewProps {
  assignments: Assignment[];
  projects: Project[];
  departments: Department[];
  user: User;
  onRefresh: () => Promise<void>;
}

const TASK_STATUSES = [
  'Pending',
  'Assigned',
  'In Progress',
  'Submitted',
  'Under Review',
  'Revision Required',
  'Approved by G-0',
  'Rejected',
  'Archived',
];

export const AssignmentManagerView: React.FC<AssignmentManagerViewProps> = ({
  assignments,
  projects,
  departments,
  user,
  onRefresh,
}) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const canCreate = isG0 || (user.role === 'DEPT_MODEL' && user.department_id === 'dept-gpt6');

  const [projectId, setProjectId] = useState(projects[0]?.id || '');
  const [dueDate, setDueDate] = useState('');
  const [objective, setObjective] = useState('');
  const [instructions, setInstructions] = useState('');
  const [requiredOutput, setRequiredOutput] = useState(
    'Structured PN-REPORT separating empirical evidence from assumptions.'
  );
  const [selectedDepts, setSelectedDepts] = useState<string[]>([]);
  const [dispatchBrief, setDispatchBrief] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  function toggleDept(id: string) {
    setSelectedDepts((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    if (!selectedDepts.length) {
      setError('Select at least one department to assign.');
      return;
    }
    setSubmitting(true);
    try {
      await apiRequest('assignments', {
        method: 'POST',
        body: JSON.stringify({
          project_id: projectId || projects[0]?.id,
          due_date: dueDate || null,
          objective,
          instructions,
          required_output: requiredOutput,
          department_ids: selectedDepts,
        }),
      });
      setObjective('');
      setInstructions('');
      setDueDate('');
      setSelectedDepts([]);
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create assignment.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleStatusChange(taskId: string, status: string) {
    if (!status) return;
    setError('');
    try {
      await apiRequest(`assignments/${taskId}`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      });
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update task status.');
    }
  }

  async function openDispatchBrief(taskId: string) {
    setError('');
    setCopied(false);
    try {
      const res = await apiRequest<{ dispatch_brief: string }>(`assignments/${taskId}/dispatch`);
      setDispatchBrief(res.dispatch_brief);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate dispatch brief.');
    }
  }

  async function copyBrief() {
    if (!dispatchBrief) return;
    await navigator.clipboard.writeText(dispatchBrief);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">Assignment Manager (PN-TASK)</h1>
        <p className="text-sm text-slate-400 mt-1">
          Issue centralized instructions to single or multiple departments simultaneously for independent engineering analysis.
        </p>
      </div>

      {canCreate && (
        <form onSubmit={handleCreate} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
          <h2 className="text-base font-semibold text-white">Issue New Assignment</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="task-proj" className="block text-xs font-medium text-slate-300 mb-1">
                Project
              </label>
              <select
                id="task-proj"
                required
                value={projectId || projects[0]?.id || ''}
                onChange={(e) => setProjectId(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.id} — {p.name}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="task-due" className="block text-xs font-medium text-slate-300 mb-1">
                Due Date (optional)
              </label>
              <input
                id="task-due"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
          </div>

          <div>
            <label htmlFor="task-obj" className="block text-xs font-medium text-slate-300 mb-1">
              Task Objective
            </label>
            <input
              id="task-obj"
              type="text"
              required
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              placeholder="Independent thermal and torque margin verification"
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>

          <div>
            <label htmlFor="task-inst" className="block text-xs font-medium text-slate-300 mb-1">
              Instructions
            </label>
            <textarea
              id="task-inst"
              required
              rows={3}
              value={instructions}
              onChange={(e) => setInstructions(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>

          <div>
            <label htmlFor="task-out" className="block text-xs font-medium text-slate-300 mb-1">
              Required Output
            </label>
            <input
              id="task-out"
              type="text"
              required
              value={requiredOutput}
              onChange={(e) => setRequiredOutput(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>

          <div>
            <div className="text-xs font-medium text-slate-300 mb-2">
              Assign to Department(s) — select multiple for parallel independent analysis
            </div>
            <div className="flex flex-wrap gap-3">
              {departments.map((d) => (
                <label key={d.id} className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedDepts.includes(d.id)}
                    onChange={() => toggleDept(d.id)}
                    className="rounded border-[#243247] bg-[#0b1017]"
                  />
                  <span>{d.assigned_model}</span>
                </label>
              ))}
            </div>
          </div>

          {error && (
            <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting || projects.length === 0}
            className="px-4 py-2 text-sm font-semibold bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-md"
          >
            {submitting ? 'Creating Assignment(s)...' : 'Create PN-TASK Assignment(s)'}
          </button>
        </form>
      )}

      {dispatchBrief && (
        <section className="bg-[#121923] border border-sky-700/70 rounded-lg p-5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-base font-semibold text-white">
              Authorized Council Dispatch Brief
            </h2>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={copyBrief}
                className="px-3 py-1.5 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
              >
                {copied ? 'Copied' : 'Copy Brief'}
              </button>
              <button
                type="button"
                onClick={() => setDispatchBrief('')}
                className="px-3 py-1.5 text-xs font-medium bg-[#182230] border border-[#243247] text-slate-300 rounded-md"
              >
                Close
              </button>
            </div>
          </div>
          <pre className="whitespace-pre-wrap text-xs font-mono-tabular bg-[#0b1017] border border-[#243247] rounded-md p-4 text-slate-200 overflow-x-auto">
            {dispatchBrief}
          </pre>
        </section>
      )}

      <div className="bg-[#121923] border border-[#243247] rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-[#243247] text-xs text-slate-400 bg-[#0e141d]">
                <th className="py-3 px-4 font-semibold">Task Ref</th>
                <th className="py-3 px-4 font-semibold">Project</th>
                <th className="py-3 px-4 font-semibold">Department</th>
                <th className="py-3 px-4 font-semibold">Objective</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e2a3b]">
              {assignments.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-6 px-4 text-slate-400">
                    No assignments recorded yet.
                  </td>
                </tr>
              ) : (
                assignments.map((a) => (
                  <tr key={a.id} className="hover:bg-[#161f2c]/60">
                    <td className="py-3 px-4 font-mono-tabular text-xs text-sky-300 whitespace-nowrap">
                      {a.task_ref}
                      {a.batch_group_id && (
                        <div className="text-[11px] text-slate-400 mt-0.5">PARALLEL</div>
                      )}
                    </td>
                    <td className="py-3 px-4 text-xs font-mono-tabular text-slate-300 whitespace-nowrap">
                      {a.project_id}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-200 whitespace-nowrap">
                      {a.assigned_model}
                    </td>
                    <td className="py-3 px-4 text-sm text-white min-w-[220px]">
                      {a.objective}
                      {a.due_date && (
                        <div className="text-xs text-slate-400 font-mono-tabular mt-0.5">
                          Due: {a.due_date}
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <StatusTag value={a.status} />
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => openDispatchBrief(a.id)}
                          className="px-2.5 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md"
                        >
                          Dispatch Brief
                        </button>
                        {isG0 && (
                          <select
                            aria-label={`Set status for ${a.task_ref}`}
                            value=""
                            onChange={(e) => handleStatusChange(a.id, e.target.value)}
                            className="px-2 py-1.5 text-xs bg-[#0b1017] border border-[#243247] rounded-md text-slate-200"
                          >
                            <option value="">Set status...</option>
                            {TASK_STATUSES.map((s) => (
                              <option key={s} value={s}>
                                {s}
                              </option>
                            ))}
                          </select>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
