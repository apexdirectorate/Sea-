import React, { useEffect, useRef, useState } from 'react';
import { Download, FileText, FolderKanban, Layers, Search, X } from 'lucide-react';
import { apiRequest, downloadAuthorizedFile } from '../api/client';
import type { GlobalSearchResponse } from '../types';
import { StatusTag } from './StatusTag';

interface HeaderSearchBarProps {
  onSelectDepartment: (deptId: string) => void;
  onOpenProjectBoard: () => void;
  onOpenLibraryWithQuery: (query: string) => void;
}

export const HeaderSearchBar: React.FC<HeaderSearchBarProps> = ({
  onSelectDepartment,
  onOpenProjectBoard,
  onOpenLibraryWithQuery,
}) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<GlobalSearchResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const trimmed = query.trim();
    if (!trimmed) {
      setResults(null);
      setLoading(false);
      setError('');
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError('');
    const timer = window.setTimeout(async () => {
      try {
        const res = await apiRequest<GlobalSearchResponse>(
          `search?q=${encodeURIComponent(trimmed)}`
        );
        if (!cancelled) {
          setResults(res);
          setOpen(true);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Search failed.');
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }, 150);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [query]);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleKey);
    };
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = query.trim();
    if (!trimmed) return;
    setLoading(true);
    setError('');
    try {
      const res = await apiRequest<GlobalSearchResponse>(
        `search?q=${encodeURIComponent(trimmed)}`
      );
      setResults(res);
      setOpen(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Search failed.');
    } finally {
      setLoading(false);
    }
  }

  function handleClear() {
    setQuery('');
    setResults(null);
    setError('');
    setOpen(false);
  }

  return (
    <div ref={containerRef} className="relative w-full max-w-md">
      <form role="search" onSubmit={handleSubmit} className="relative flex items-center">
        <Search
          aria-hidden="true"
          className="w-3.5 h-3.5 text-slate-400 absolute left-3 pointer-events-none"
        />
        <input
          type="search"
          aria-label="Search departments, projects, and documents"
          value={query}
          onFocus={() => {
            if (query.trim() && (results || error)) {
              setOpen(true);
            }
          }}
          onChange={(e) => {
            setQuery(e.target.value);
            if (e.target.value.trim()) setOpen(true);
          }}
          placeholder="Search departments, projects, documents..."
          className="w-full pl-8 pr-8 py-1.5 bg-[#0b1017] border border-[#243247] focus:border-sky-500 rounded-md text-xs text-white placeholder:text-slate-500 focus:outline-none min-h-[36px]"
        />
        {query && (
          <button
            type="button"
            onClick={handleClear}
            aria-label="Clear search"
            className="absolute right-2 p-1 text-slate-400 hover:text-white rounded"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </form>

      {open && query.trim() && (
        <div
          role="region"
          aria-label="Global Search Results"
          className="absolute left-0 right-0 mt-1.5 z-50 bg-[#121923] border border-[#243247] rounded-lg shadow-2xl max-h-[70vh] overflow-y-auto divide-y divide-[#1e2a3b]"
        >
          <div className="px-3 py-2 flex items-center justify-between text-[11px] text-slate-400 bg-[#0e141d]">
            <span>
              {loading
                ? `Searching "${query.trim()}"...`
                : results
                ? `${results.total} result${results.total === 1 ? '' : 's'} across departments, projects & documents`
                : 'Search Council records'}
            </span>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="text-slate-400 hover:text-white"
            >
              Close
            </button>
          </div>

          {error && (
            <div role="alert" className="p-3 text-xs text-rose-300 bg-rose-950/30">
              {error}
            </div>
          )}

          {!loading && !error && results && results.total === 0 && (
            <div className="p-4 text-xs text-slate-400">
              No departments, projects, or documents matched &ldquo;{results.query}&rdquo;.
            </div>
          )}

          {results && results.departments.length > 0 && (
            <div className="p-2">
              <div className="px-2 py-1 text-[11px] font-semibold text-sky-300 flex items-center gap-1.5">
                <Layers className="w-3 h-3" />
                <span>Departments ({results.departments.length})</span>
              </div>
              <div className="space-y-1">
                {results.departments.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => {
                      onSelectDepartment(d.id);
                      setOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-md hover:bg-[#182230] transition-colors flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">
                        {d.assigned_model} · {d.name}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">
                        {d.application_name}
                      </div>
                    </div>
                    <StatusTag value={d.status} />
                  </button>
                ))}
              </div>
            </div>
          )}

          {results && results.projects.length > 0 && (
            <div className="p-2">
              <div className="px-2 py-1 text-[11px] font-semibold text-sky-300 flex items-center gap-1.5">
                <FolderKanban className="w-3 h-3" />
                <span>Projects ({results.projects.length})</span>
              </div>
              <div className="space-y-1">
                {results.projects.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      onOpenProjectBoard();
                      setOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-md hover:bg-[#182230] transition-colors flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">
                        <span className="font-mono-tabular text-sky-300 mr-1.5">{p.id}</span>
                        {p.name}
                      </div>
                      <div className="text-[11px] text-slate-400 truncate">{p.objective}</div>
                    </div>
                    <StatusTag value={p.status} />
                  </button>
                ))}
              </div>
            </div>
          )}

          {results && results.documents.length > 0 && (
            <div className="p-2">
              <div className="px-2 py-1 text-[11px] font-semibold text-sky-300 flex items-center gap-1.5">
                <FileText className="w-3 h-3" />
                <span>Documents ({results.documents.length})</span>
              </div>
              <div className="space-y-1">
                {results.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="px-2.5 py-2 rounded-md hover:bg-[#182230] transition-colors flex items-center justify-between gap-2"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        onOpenLibraryWithQuery(doc.title);
                        setOpen(false);
                      }}
                      className="text-left min-w-0 flex-1"
                    >
                      <div className="text-xs font-semibold text-white truncate">
                        {doc.title}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono-tabular truncate">
                        {doc.filename} · {doc.doc_type} · v{doc.version_number}
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        downloadAuthorizedFile(doc.id, doc.filename).catch((err) => {
                          setError(err instanceof Error ? err.message : 'Download failed.');
                        });
                      }}
                      aria-label={`Download ${doc.title}`}
                      className="p-1.5 text-sky-300 hover:bg-[#1f2c3d] rounded border border-[#243247] shrink-0"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
