import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { DashboardPayload, User } from '../types';
import { StatusTag } from './StatusTag';

interface DirectorControlViewProps {
  data: DashboardPayload;
  user: User;
  docCount: number;
  onRefresh: () => Promise<void>;
}

export const DirectorControlView: React.FC<DirectorControlViewProps> = ({
  data,
  user,
  docCount,
  onRefresh,
}) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const [error, setError] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);

  async function updateReportStatus(reportId: string, director_status: string) {
    setError('');
    setBusyId(reportId);
    try {
      await apiRequest(`reports/${reportId}/director-status`, {
        method: 'PATCH',
        body: JSON.stringify({ director_status }),
      });
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update report status.');
    } finally {
      setBusyId(null);
    }
  }

  async function resolveDispute(reviewId: string, resolution_status: string) {
    setError('');
    setBusyId(reviewId);
    try {
      await apiRequest(`reviews/${reviewId}`, {
        method: 'PATCH',
        body: JSON.stringify({ resolution_status }),
      });
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to resolve dispute.');
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">Director G-0 Control Center</h1>
        <p className="text-sm text-slate-400 mt-1">
          G-0 retains final authority over objectives, assignments, department changes, approvals, architecture, resources, and deployment.
        </p>
        <div className="mt-3 text-xs text-slate-300 font-mono-tabular">
          Pending Reports: {data.awaiting_verification.length} · Open Disputes: {data.unresolved_disagreements.length} · Library Assets: {docCount}
        </div>
        {!isG0 && (
          <div className="mt-3 p-3 rounded-md bg-amber-950/30 border border-amber-800/60 text-xs text-amber-200">
            Read-only governance view. Only Director G-0 may execute final approvals or resolve Council disputes.
          </div>
        )}
        {error && (
          <div role="alert" className="mt-3 p-3 rounded-md bg-rose-950/40 border border-rose-800/70 text-xs text-rose-300">
            {error}
          </div>
        )}
      </div>

      <section className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
        <h2 className="text-base font-semibold text-white">
          Reports Awaiting Director Decision ({data.awaiting_verification.length})
        </h2>
        {data.awaiting_verification.length === 0 ? (
          <p className="text-sm text-slate-400">No reports are currently pending G-0 decision.</p>
        ) : (
          <div className="divide-y divide-[#1e2a3b]">
            {data.awaiting_verification.map((r) => (
              <div key={r.id} className="py-4 first:pt-0 last:pb-0 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm font-semibold text-white">
                    <span className="font-mono-tabular text-sky-300 mr-2">{r.report_ref}</span>
                    {r.department_name}
                  </div>
                  <StatusTag value={r.director_status} />
                </div>
                <p className="text-sm text-slate-300">{r.findings}</p>
                <p className="text-xs text-slate-400">
                  Recommendations: {r.recommendations}
                </p>
                {isG0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      disabled={busyId === r.id}
                      onClick={() => updateReportStatus(r.id, 'APPROVED_BY_G0')}
                      className="px-3.5 py-1.5 text-xs font-semibold bg-emerald-700 hover:bg-emerald-600 text-white rounded-md"
                    >
                      Approve Report
                    </button>
                    <button
                      type="button"
                      disabled={busyId === r.id}
                      onClick={() => updateReportStatus(r.id, 'REJECTED_BY_G0')}
                      className="px-3.5 py-1.5 text-xs font-semibold bg-rose-800 hover:bg-rose-700 text-white rounded-md"
                    >
                      Reject Report
                    </button>
                    <button
                      type="button"
                      disabled={busyId === r.id}
                      onClick={() => updateReportStatus(r.id, 'ACKNOWLEDGED')}
                      className="px-3.5 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md"
                    >
                      Acknowledge
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>

      <section className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
        <h2 className="text-base font-semibold text-white">
          Open Disagreements &amp; Competing Conclusions ({data.unresolved_disagreements.length})
        </h2>
        {data.unresolved_disagreements.length === 0 ? (
          <p className="text-sm text-slate-400">No open disagreements require resolution.</p>
        ) : (
          <div className="divide-y divide-[#1e2a3b]">
            {data.unresolved_disagreements.map((d) => (
              <div key={d.id} className="py-4 first:pt-0 last:pb-0 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="text-sm font-semibold text-white">
                    <span className="font-mono-tabular text-amber-300 mr-2">{d.review_ref}</span>
                    on {d.report_ref} ({d.reviewer_dept_model})
                  </div>
                  <StatusTag value={d.verdict} />
                </div>
                <p className="text-sm text-slate-300">{d.summary}</p>
                {d.disagreements && (
                  <p className="text-xs text-slate-400">Disagreements: {d.disagreements}</p>
                )}
                {isG0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    <button
                      type="button"
                      disabled={busyId === d.id}
                      onClick={() => resolveDispute(d.id, 'UPHELD_BY_G0')}
                      className="px-3.5 py-1.5 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
                    >
                      Uphold Dispute
                    </button>
                    <button
                      type="button"
                      disabled={busyId === d.id}
                      onClick={() => resolveDispute(d.id, 'OVERRULED_BY_G0')}
                      className="px-3.5 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md"
                    >
                      Overrule Dispute
                    </button>
                    <button
                      type="button"
                      disabled={busyId === d.id}
                      onClick={() => resolveDispute(d.id, 'ADDRESSED')}
                      className="px-3.5 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md"
                    >
                      Mark Addressed
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
