import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { AIProvider, User } from '../types';
import { StatusTag } from './StatusTag';

interface ProvidersViewProps {
  providers: AIProvider[];
  user: User;
  onRefresh: () => Promise<void>;
}

export const ProvidersView: React.FC<ProvidersViewProps> = ({ providers, user, onRefresh }) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const [testingId, setTestingId] = useState<string | null>(null);
  const [error, setError] = useState('');

  async function handleTest(provId: string) {
    setError('');
    setTestingId(provId);
    try {
      await apiRequest(`providers/${provId}/test`, { method: 'POST' });
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Connection test failed.');
    } finally {
      setTestingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">AI Provider Integrations</h1>
        <p className="text-sm text-slate-400 mt-1">
          Modular provider adapters. Credentials are read strictly from server-side environment secrets and are never stored or exposed in browser code. Unconfigured integrations remain marked <code className="text-amber-300">NOT CONNECTED</code>.
        </p>
        {error && (
          <div role="alert" className="mt-3 text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
            {error}
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {providers.map((p) => (
          <div key={p.id} className="bg-[#121923] border border-[#243247] rounded-lg p-5 flex flex-col justify-between gap-4">
            <div className="space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h2 className="text-base font-bold text-white">{p.provider_name}</h2>
                  <div className="text-xs text-slate-400">
                    Model: <strong className="text-slate-200">{p.model_name}</strong> · {p.department_name}
                  </div>
                </div>
                <StatusTag value={p.connection_status} />
              </div>

              <div className="text-xs text-slate-300 space-y-1 pt-2 border-t border-[#1e2a3b]">
                <div className="flex items-center justify-between gap-2">
                  <span>Adapter Mode:</span>
                  <span className="font-mono-tabular text-sky-300">{p.adapter_type}</span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span>Authentication Status:</span>
                  <StatusTag value={p.auth_status} />
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span>Server Secret Var:</span>
                  <span className="font-mono-tabular text-slate-200">
                    {p.env_secret_name || 'N/A'} ({p.server_secret_configured ? 'Present on server' : 'Not set'})
                  </span>
                </div>
                <div className="flex items-center justify-between gap-2">
                  <span>Permissions:</span>
                  <span className="font-mono-tabular text-slate-300">{p.available_permissions}</span>
                </div>
                <div>
                  <span className="text-slate-400">Supported Operations: </span>
                  <span className="text-slate-200">{p.supported_operations.join(', ')}</span>
                </div>
                <div className="font-mono-tabular text-slate-400">
                  Last Tested: {p.last_tested_at || 'Never'}
                </div>
                {p.last_error && (
                  <div className="text-xs text-amber-200 bg-amber-950/30 border border-amber-800/50 rounded p-2 mt-1">
                    {p.last_error}
                  </div>
                )}
              </div>
            </div>

            {isG0 && (
              <button
                type="button"
                disabled={testingId === p.id}
                onClick={() => handleTest(p.id)}
                className="w-full py-2 px-3 text-xs font-semibold bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-white rounded-md transition-colors"
              >
                {testingId === p.id ? 'Testing Server Adapter...' : 'Run Real Connection Test'}
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
