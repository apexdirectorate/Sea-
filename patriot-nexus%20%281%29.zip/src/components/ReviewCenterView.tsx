import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { CouncilReport, CouncilReview, Department, User } from '../types';
import { StatusTag } from './StatusTag';

interface ReviewCenterViewProps {
  reviews: CouncilReview[];
  reports: CouncilReport[];
  departments: Department[];
  user: User;
  onRefresh: () => Promise<void>;
}

const VERDICTS = [
  { value: 'ACCEPT', label: 'Accept' },
  { value: 'REQUEST_REVISION', label: 'Request Revision' },
  { value: 'DISPUTE_FINDINGS', label: 'Dispute Findings' },
  { value: 'MISSING_EVIDENCE', label: 'Identify Missing Evidence' },
  { value: 'TECHNICAL_ERROR', label: 'Identify Mathematical or Technical Error' },
  { value: 'UNSUPPORTED_CLAIMS', label: 'Identify Unsupported Claims' },
  { value: 'RECOMMEND_TESTING', label: 'Recommend Additional Testing' },
  { value: 'REJECT', label: 'Reject' },
];

export const ReviewCenterView: React.FC<ReviewCenterViewProps> = ({
  reviews,
  reports,
  departments,
  user,
  onRefresh,
}) => {
  const [reportId, setReportId] = useState(reports[0]?.id || '');
  const [reviewerDeptId, setReviewerDeptId] = useState(user.department_id || 'dept-muse');
  const [reviewerModel, setReviewerModel] = useState(user.display_name);
  const [verdict, setVerdict] = useState('REQUEST_REVISION');
  const [summary, setSummary] = useState('');
  const [technicalNotes, setTechnicalNotes] = useState('');
  const [disagreements, setDisagreements] = useState('');
  const [evidenceGaps, setEvidenceGaps] = useState('');
  const [recommendedTests, setRecommendedTests] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await apiRequest('reviews', {
        method: 'POST',
        body: JSON.stringify({
          report_id: reportId || reports[0]?.id,
          reviewer_department_id: reviewerDeptId,
          reviewer_model: reviewerModel,
          verdict,
          summary,
          technical_notes: technicalNotes,
          disagreements,
          evidence_gaps: evidenceGaps,
          recommended_tests: recommendedTests,
        }),
      });
      setSummary('');
      setTechnicalNotes('');
      setDisagreements('');
      setEvidenceGaps('');
      setRecommendedTests('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to record review.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">Independent Review &amp; Verification Center (PN-REVIEW)</h1>
        <p className="text-sm text-slate-400 mt-1">
          No model may review or approve its own work. Muse AI performs independent QA, but its conclusions are not automatically authoritative. All disagreements are preserved.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
        <h2 className="text-base font-semibold text-white">Submit Independent Review / Dispute</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="rev-report" className="block text-xs font-medium text-slate-300 mb-1">
              Target Report
            </label>
            <select
              id="rev-report"
              required
              value={reportId || reports[0]?.id || ''}
              onChange={(e) => setReportId(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              {reports.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.report_ref} ({r.department_name})
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="rev-dept" className="block text-xs font-medium text-slate-300 mb-1">
              Reviewing Department
            </label>
            <select
              id="rev-dept"
              value={reviewerDeptId}
              onChange={(e) => setReviewerDeptId(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.assigned_model} — {d.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="rev-model" className="block text-xs font-medium text-slate-300 mb-1">
              Reviewer Model Identity
            </label>
            <input
              id="rev-model"
              type="text"
              required
              value={reviewerModel}
              onChange={(e) => setReviewerModel(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rev-verdict" className="block text-xs font-medium text-slate-300 mb-1">
              Review Verdict
            </label>
            <select
              id="rev-verdict"
              required
              value={verdict}
              onChange={(e) => setVerdict(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              {VERDICTS.map((v) => (
                <option key={v.value} value={v.value}>
                  {v.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="rev-summary" className="block text-xs font-medium text-slate-300 mb-1">
            Review Summary
          </label>
          <input
            id="rev-summary"
            type="text"
            required
            value={summary}
            onChange={(e) => setSummary(e.target.value)}
            className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="rev-notes" className="block text-xs font-medium text-slate-300 mb-1">
              Technical Notes
            </label>
            <textarea
              id="rev-notes"
              required
              rows={3}
              value={technicalNotes}
              onChange={(e) => setTechnicalNotes(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rev-disagree" className="block text-xs font-medium text-slate-300 mb-1">
              Recorded Disagreements / Competing Conclusions
            </label>
            <textarea
              id="rev-disagree"
              rows={3}
              value={disagreements}
              onChange={(e) => setDisagreements(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rev-gaps" className="block text-xs font-medium text-slate-300 mb-1">
              Evidence Gaps
            </label>
            <input
              id="rev-gaps"
              type="text"
              value={evidenceGaps}
              onChange={(e) => setEvidenceGaps(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rev-tests" className="block text-xs font-medium text-slate-300 mb-1">
              Recommended Additional Testing
            </label>
            <input
              id="rev-tests"
              type="text"
              value={recommendedTests}
              onChange={(e) => setRecommendedTests(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
        </div>

        {error && (
          <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting || reports.length === 0}
          className="px-4 py-2 text-sm font-semibold bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-md"
        >
          {submitting ? 'Recording Review...' : 'Record PN-REVIEW'}
        </button>
      </form>

      <div className="space-y-4">
        {reviews.length === 0 ? (
          <div className="bg-[#121923] border border-[#243247] rounded-lg p-6 text-sm text-slate-400">
            No independent reviews recorded yet.
          </div>
        ) : (
          reviews.map((rv) => (
            <article key={rv.id} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-sm font-semibold text-white">
                  <span className="font-mono-tabular text-sky-300 mr-2">{rv.review_ref}</span>
                  on <span className="font-mono-tabular">{rv.report_ref}</span>
                </div>
                <div className="flex gap-2">
                  <StatusTag value={rv.verdict} />
                  <StatusTag value={rv.resolution_status} />
                </div>
              </div>
              <div className="text-xs text-slate-400">
                Reviewer: <strong className="text-slate-200">{rv.reviewer_model}</strong> ({rv.reviewer_department_name})
                <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
                <span className="font-mono-tabular">{rv.created_at}</span>
              </div>
              <p className="text-sm text-white">{rv.summary}</p>
              <p className="text-sm text-slate-300">{rv.technical_notes}</p>
              {rv.disagreements && (
                <p className="text-xs text-amber-200">
                  <strong>Disagreements:</strong> {rv.disagreements}
                </p>
              )}
              {(rv.evidence_gaps || rv.recommended_tests) && (
                <p className="text-xs text-slate-400">
                  {rv.evidence_gaps && <><strong>Evidence Gaps:</strong> {rv.evidence_gaps} · </>}
                  {rv.recommended_tests && <><strong>Recommended Tests:</strong> {rv.recommended_tests}</>}
                </p>
              )}
            </article>
          ))
        )}
      </div>
    </div>
  );
};
