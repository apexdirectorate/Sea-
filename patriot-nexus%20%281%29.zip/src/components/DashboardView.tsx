import React from 'react';
import { ArrowRight } from 'lucide-react';
import type { DashboardPayload, PageId, User } from '../types';
import { getDepartmentWorkloadIndicator } from '../utils/departmentWorkload';
import { StatusTag } from './StatusTag';

interface DashboardViewProps {
  data: DashboardPayload;
  user: User;
  onNavigate: (page: PageId) => void;
  onOpenDepartment: (deptId: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  user,
  onNavigate,
  onOpenDepartment,
}) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const connectedCount = data.providers.filter((p) => p.connection_status === 'CONNECTED').length;

  return (
    <div className="space-y-6">
      <section className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              PATRIOT-NEXUS Headquarters
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Command Authority: <strong className="text-slate-200">G-0 (Human Director)</strong>
              <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
              Chief Architect: <strong className="text-slate-200">GPT-6</strong>
              <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
              Program: <strong className="text-slate-200">420 Robotics</strong>
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <StatusTag value={connectedCount > 0 ? 'API_PARTIAL' : 'MANUAL_COUNCIL_ACTIVE'} />
            <span className="text-xs text-slate-300 font-mono-tabular">
              Connected Providers: {connectedCount}/8
            </span>
          </div>
        </div>

        {isG0 && (
          <div className="mt-5 pt-4 border-t border-[#243247] flex flex-wrap gap-2.5">
            <button
              type="button"
              onClick={() => onNavigate('director')}
              className="px-4 py-2 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md transition-colors whitespace-nowrap"
            >
              Open Director Control Panel
            </button>
            <button
              type="button"
              onClick={() => onNavigate('projects')}
              className="px-4 py-2 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md transition-colors whitespace-nowrap"
            >
              Manage Projects
            </button>
            <button
              type="button"
              onClick={() => onNavigate('assignments')}
              className="px-4 py-2 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md transition-colors whitespace-nowrap"
            >
              Issue PN-TASK
            </button>
            <button
              type="button"
              onClick={() => onNavigate('decisions')}
              className="px-4 py-2 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md transition-colors whitespace-nowrap"
            >
              Append PN-DECISION
            </button>
          </div>
        )}
      </section>

      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#121923] border border-[#243247] rounded-lg p-4">
          <div className="text-xs text-slate-400">Active Projects</div>
          <div className="text-2xl font-bold text-white font-mono-tabular mt-1">
            {data.active_projects.length}
          </div>
        </div>
        <div className="bg-[#121923] border border-[#243247] rounded-lg p-4">
          <div className="text-xs text-slate-400">Pending Assignments</div>
          <div className="text-2xl font-bold text-white font-mono-tabular mt-1">
            {data.pending_assignments.length}
          </div>
        </div>
        <div className="bg-[#121923] border border-[#243247] rounded-lg p-4">
          <div className="text-xs text-slate-400">Awaiting Verification</div>
          <div className="text-2xl font-bold text-white font-mono-tabular mt-1">
            {data.awaiting_verification.length}
          </div>
        </div>
        <div className="bg-[#121923] border border-[#243247] rounded-lg p-4">
          <div className="text-xs text-slate-400">Unresolved Disagreements</div>
          <div className="text-2xl font-bold text-white font-mono-tabular mt-1">
            {data.unresolved_disagreements.length}
          </div>
        </div>
      </section>

      <section>
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <h2 className="text-base font-semibold text-white">Eight Council Departments</h2>
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1.5 text-slate-300 font-mono-tabular">
              <span aria-hidden="true" className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>
                Live Assignment Sync ·{' '}
                {data.departments.reduce((sum, d) => sum + (d.active_assignment_count ?? 0), 0)} Active Total
              </span>
            </span>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5">
          {data.departments.map((dept) => {
            const workload = getDepartmentWorkloadIndicator({
              activeCount: dept.active_assignment_count,
              inProgressCount: dept.in_progress_count,
              revisionRequiredCount: dept.revision_required_count,
            });
            const activeCount = dept.active_assignment_count ?? 0;

            return (
              <button
                key={dept.id}
                type="button"
                onClick={() => onOpenDepartment(dept.id)}
                className="text-left bg-[#121923] hover:bg-[#161f2c] border border-[#243247] hover:border-sky-600/70 rounded-lg p-4 transition-colors flex flex-col justify-between gap-3"
              >
                <div className="w-full">
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-sm font-bold text-white">{dept.assigned_model}</span>
                    <StatusTag value={dept.status} />
                  </div>
                  <div className="text-sm text-slate-200 font-medium leading-snug">{dept.name}</div>
                </div>

                <div className="w-full space-y-2.5">
                  <div
                    data-testid={`dept-active-indicator-${dept.id}`}
                    data-active-count={activeCount}
                    data-workload-state={workload.state}
                    className={`w-full flex items-center justify-between gap-2 px-2.5 py-1.5 rounded border text-xs ${workload.containerClass}`}
                  >
                    <span className="inline-flex items-center gap-2 font-medium min-w-0">
                      <span
                        aria-hidden="true"
                        className={`w-2 h-2 rounded-full shrink-0 ${workload.dotClass}`}
                      />
                      <span className="truncate">{workload.label}</span>
                    </span>
                    <span className={`font-mono-tabular font-semibold whitespace-nowrap shrink-0 ${workload.countClass}`}>
                      {workload.countLabel}
                    </span>
                  </div>

                  <div className="flex items-center justify-between w-full pt-2 border-t border-[#1e2a3b] text-xs text-slate-400">
                    <span className="truncate pr-2">{dept.application_name}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-white">Active Projects</h2>
            <button type="button" onClick={() => onNavigate('projects')} className="text-xs text-sky-400 hover:underline">
              View All
            </button>
          </div>
          {data.active_projects.length === 0 ? (
            <p className="text-sm text-slate-400">No active projects found.</p>
          ) : (
            <div className="divide-y divide-[#1e2a3b]">
              {data.active_projects.map((p) => (
                <div key={p.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono-tabular text-sky-300">{p.id}</span>
                    <StatusTag value={p.priority} />
                  </div>
                  <div className="text-sm font-medium text-white mt-1">{p.name}</div>
                  <div className="text-xs text-slate-400 mt-0.5 line-clamp-2">{p.objective}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-white">Pending Assignments</h2>
            <button type="button" onClick={() => onNavigate('assignments')} className="text-xs text-sky-400 hover:underline">
              Assignment Manager
            </button>
          </div>
          {data.pending_assignments.length === 0 ? (
            <p className="text-sm text-slate-400">No pending assignments.</p>
          ) : (
            <div className="divide-y divide-[#1e2a3b]">
              {data.pending_assignments.map((a) => (
                <div key={a.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono-tabular text-sky-300">{a.task_ref}</span>
                    <StatusTag value={a.status} />
                  </div>
                  <div className="text-sm font-medium text-white mt-1">{a.objective}</div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {a.assigned_model} · {a.project_name}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-white">Submitted Reports &amp; Verification Queue</h2>
            <button type="button" onClick={() => onNavigate('reports')} className="text-xs text-sky-400 hover:underline">
              Report Center
            </button>
          </div>
          {data.submitted_reports.length === 0 ? (
            <p className="text-sm text-slate-400">No reports submitted yet.</p>
          ) : (
            <div className="divide-y divide-[#1e2a3b]">
              {data.submitted_reports.map((r) => (
                <div key={r.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono-tabular text-sky-300">{r.report_ref}</span>
                    <StatusTag value={r.director_status} />
                  </div>
                  <div className="text-sm text-white mt-1">{r.objective}</div>
                  <div className="text-xs text-slate-400 mt-0.5">
                    {r.department_name} · {r.task_ref}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-white">Unresolved Disagreements</h2>
            <button type="button" onClick={() => onNavigate('reviews')} className="text-xs text-sky-400 hover:underline">
              Review Center
            </button>
          </div>
          {data.unresolved_disagreements.length === 0 ? (
            <p className="text-sm text-slate-400">No unresolved disputes recorded.</p>
          ) : (
            <div className="divide-y divide-[#1e2a3b]">
              {data.unresolved_disagreements.map((d) => (
                <div key={d.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono-tabular text-amber-300">
                      {d.review_ref} · {d.report_ref}
                    </span>
                    <StatusTag value={d.verdict} />
                  </div>
                  <div className="text-sm text-white mt-1">{d.summary}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-base font-semibold text-white">Recently Approved Decisions &amp; Charters</h2>
            <button type="button" onClick={() => onNavigate('decisions')} className="text-xs text-sky-400 hover:underline">
              Decision Ledger
            </button>
          </div>
          {data.recent_decisions.length === 0 ? (
            <p className="text-sm text-slate-400">No ledger entries recorded yet.</p>
          ) : (
            <div className="divide-y divide-[#1e2a3b]">
              {data.recent_decisions.map((dec) => (
                <div key={dec.id} className="py-3 first:pt-0 last:pb-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono-tabular text-sky-300">{dec.record_ref}</span>
                    <StatusTag value={dec.approval_status} />
                  </div>
                  <div className="text-sm text-white mt-1">{dec.subject}</div>
                  <div className="text-xs text-slate-400 mt-0.5 font-mono-tabular">{dec.created_at}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
          <h2 className="text-base font-semibold text-white mb-3">Recent Council Activity</h2>
          {data.recent_activity.length === 0 ? (
            <p className="text-sm text-slate-400">No activity recorded yet.</p>
          ) : (
            <div className="divide-y divide-[#1e2a3b]">
              {data.recent_activity.map((act) => (
                <div key={act.id} className="py-2.5 first:pt-0 last:pb-0">
                  <div className="text-sm text-slate-200">
                    <span className="font-mono-tabular text-xs text-sky-300 mr-2">{act.action_type}</span>
                    {act.summary}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5 font-mono-tabular">
                    {act.actor_label} · {act.created_at}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
