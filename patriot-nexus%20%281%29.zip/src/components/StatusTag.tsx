import React from 'react';

interface StatusTagProps {
  value: string;
}

export const StatusTag: React.FC<StatusTagProps> = ({ value }) => {
  const s = String(value || '');
  let colorClass = 'text-sky-300 border-sky-800/70 bg-sky-950/40';

  if (
    [
      'ACTIVE',
      'CONNECTED',
      'VERIFIED',
      'APPROVED_BY_G0',
      'Approved by G-0',
      'ACCEPT',
      'UPHELD_BY_G0',
      'ACKNOWLEDGED',
    ].includes(s)
  ) {
    colorClass = 'text-emerald-300 border-emerald-800/70 bg-emerald-950/40';
  } else if (
    [
      'ERROR',
      'FAILED',
      'REJECT',
      'REJECTED_BY_G0',
      'Rejected',
      'TECHNICAL_ERROR',
      'SUSPENDED',
      'CRITICAL',
    ].includes(s)
  ) {
    colorClass = 'text-rose-300 border-rose-800/70 bg-rose-950/40';
  } else if (
    [
      'PROVISIONAL',
      'PENDING_G0',
      'PENDING',
      'Pending',
      'Under Review',
      'Revision Required',
      'DISPUTE_FINDINGS',
      'NOT CONNECTED',
      'OPEN',
      'PAUSED',
      'SUPERSEDED',
      'UNCONFIGURED',
    ].includes(s)
  ) {
    colorClass = 'text-amber-300 border-amber-800/70 bg-amber-950/40';
  }

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 text-xs font-medium font-mono-tabular border rounded whitespace-nowrap shrink-0 ${colorClass}`}
    >
      {s}
    </span>
  );
};
