import React, { useEffect, useState } from 'react';
import { apiRequest, downloadAuthorizedFile } from '../api/client';
import type { Department, DocumentItem, Project, User } from '../types';

interface DocumentLibraryViewProps {
  documents: DocumentItem[];
  projects: Project[];
  departments: Department[];
  user: User;
  initialQuery?: string;
  onRefresh: () => Promise<void>;
}

const DOC_TYPES = [
  { value: 'TECH_SPEC', label: 'Technical Specification' },
  { value: 'PROJECT_DOC', label: 'Project Document' },
  { value: 'RESEARCH', label: 'Research Paper / Notes' },
  { value: 'CALCULATION', label: 'Engineering Calculation' },
  { value: 'SOURCE_CODE', label: 'Source Code' },
  { value: 'DIAGRAM', label: 'Diagram / Schematic' },
  { value: 'TEST_RESULT', label: 'Test Result' },
  { value: 'AI_REPORT', label: 'AI Report Export' },
  { value: 'DECISION_REF', label: 'Decision Reference' },
  { value: 'REFERENCE', label: 'Reference Material' },
];

export const DocumentLibraryView: React.FC<DocumentLibraryViewProps> = ({
  documents,
  projects,
  departments,
  user,
  initialQuery = '',
  onRefresh,
}) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const canUpload = isG0 || user.can_submit === 1;

  const [query, setQuery] = useState(initialQuery);
  const [filterProj, setFilterProj] = useState('');
  const [filterDept, setFilterDept] = useState('');
  const [filteredDocs, setFilteredDocs] = useState<DocumentItem[] | null>(null);

  useEffect(() => {
    if (!initialQuery) return;
    setQuery(initialQuery);
    let cancelled = false;
    apiRequest<{ documents: DocumentItem[] }>(`documents?q=${encodeURIComponent(initialQuery)}`)
      .then((res) => {
        if (!cancelled) setFilteredDocs(res.documents);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [initialQuery]);

  const [title, setTitle] = useState('');
  const [docType, setDocType] = useState('TECH_SPEC');
  const [projectId, setProjectId] = useState('');
  const [departmentId, setDepartmentId] = useState(user.department_id || '');
  const [parentDocId, setParentDocId] = useState('');
  const [accessLevel, setAccessLevel] = useState<'COUNCIL_INTERNAL' | 'DIRECTOR_ONLY' | 'DEPARTMENT_RESTRICTED'>('COUNCIL_INTERNAL');
  const [description, setDescription] = useState('');
  const [fileObj, setFileObj] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [uploading, setUploading] = useState(false);

  const visibleDocs = filteredDocs ?? documents;

  async function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    const params = new URLSearchParams();
    if (query.trim()) params.set('q', query.trim());
    if (filterProj) params.set('project_id', filterProj);
    if (filterDept) params.set('department_id', filterDept);
    try {
      const res = await apiRequest<{ documents: DocumentItem[] }>(`documents?${params.toString()}`);
      setFilteredDocs(res.documents);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Search failed.');
    }
  }

  async function clearSearch() {
    setQuery('');
    setFilterProj('');
    setFilterDept('');
    setFilteredDocs(null);
    await onRefresh();
  }

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    if (!fileObj) return;
    setError('');
    if (fileObj.size > 2_000_000) {
      setError('File exceeds 2 MB document limit.');
      return;
    }
    setUploading(true);
    try {
      const content_base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = String(reader.result || '');
          const idx = result.indexOf(',');
          resolve(idx >= 0 ? result.slice(idx + 1) : result);
        };
        reader.onerror = () => reject(new Error('Failed to read selected file.'));
        reader.readAsDataURL(fileObj);
      });

      await apiRequest('documents', {
        method: 'POST',
        body: JSON.stringify({
          title,
          doc_type: docType,
          project_id: projectId || null,
          department_id: departmentId || null,
          parent_document_id: parentDocId || null,
          access_level: accessLevel,
          description,
          filename: fileObj.name,
          mime_type: fileObj.type || 'application/octet-stream',
          size_bytes: fileObj.size,
          content_base64,
        }),
      });
      setTitle('');
      setDescription('');
      setParentDocId('');
      setFileObj(null);
      setFilteredDocs(null);
      const fileInput = document.getElementById('doc-file-input') as HTMLInputElement | null;
      if (fileInput) fileInput.value = '';
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed.');
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
        <div>
          <h1 className="text-xl font-bold text-white">Research &amp; Document Library</h1>
          <p className="text-sm text-slate-400 mt-1">
            Centralized repository for technical specs, calculations, code, test results, and reference documents stored persistently in SQL.
          </p>
        </div>

        <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-4 gap-3">
          <input
            aria-label="Search documents"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search title, description, filename..."
            className="px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
          />
          <select
            aria-label="Filter by project"
            value={filterProj}
            onChange={(e) => setFilterProj(e.target.value)}
            className="px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
          >
            <option value="">All Projects</option>
            {projects.map((p) => (
              <option key={p.id} value={p.id}>
                {p.id}
              </option>
            ))}
          </select>
          <select
            aria-label="Filter by department"
            value={filterDept}
            onChange={(e) => setFilterDept(e.target.value)}
            className="px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
          >
            <option value="">All Departments</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.assigned_model}
              </option>
            ))}
          </select>
          <div className="flex gap-2">
            <button
              type="submit"
              className="flex-1 px-3 py-2 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
            >
              Filter
            </button>
            <button
              type="button"
              onClick={clearSearch}
              className="px-3 py-2 text-xs font-medium bg-[#182230] border border-[#243247] text-slate-300 rounded-md"
            >
              Reset
            </button>
          </div>
        </form>
      </div>

      {canUpload && (
        <form onSubmit={handleUpload} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
          <h2 className="text-base font-semibold text-white">Upload Authorized Document (up to 2 MB)</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="doc-title" className="block text-xs font-medium text-slate-300 mb-1">
                Document Title
              </label>
              <input
                id="doc-title"
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
            <div>
              <label htmlFor="doc-type" className="block text-xs font-medium text-slate-300 mb-1">
                Document Category
              </label>
              <select
                id="doc-type"
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                {DOC_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="doc-parent" className="block text-xs font-medium text-slate-300 mb-1">
                New Version Of (optional)
              </label>
              <select
                id="doc-parent"
                value={parentDocId}
                onChange={(e) => setParentDocId(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="">New Document (v1)</option>
                {documents.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.title} (v{d.version_number})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="doc-proj" className="block text-xs font-medium text-slate-300 mb-1">
                Project
              </label>
              <select
                id="doc-proj"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="">General Council</option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.id}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label htmlFor="doc-dept" className="block text-xs font-medium text-slate-300 mb-1">
                Department
              </label>
              <select
                id="doc-dept"
                value={departmentId}
                onChange={(e) => setDepartmentId(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="">Shared</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.assigned_model}
                  </option>
                ))}
              </select>
            </div>
            {isG0 && (
              <div>
                <label htmlFor="doc-access" className="block text-xs font-medium text-slate-300 mb-1">
                  Access Control
                </label>
                <select
                  id="doc-access"
                  value={accessLevel}
                  onChange={(e) =>
                    setAccessLevel(
                      e.target.value as 'COUNCIL_INTERNAL' | 'DIRECTOR_ONLY' | 'DEPARTMENT_RESTRICTED'
                    )
                  }
                  className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
                >
                  <option value="COUNCIL_INTERNAL">Council Internal (All Authenticated)</option>
                  <option value="DEPARTMENT_RESTRICTED">Department Restricted</option>
                  <option value="DIRECTOR_ONLY">Director G-0 Only</option>
                </select>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="doc-desc" className="block text-xs font-medium text-slate-300 mb-1">
                Description
              </label>
              <input
                id="doc-desc"
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
            <div>
              <label htmlFor="doc-file-input" className="block text-xs font-medium text-slate-300 mb-1">
                File
              </label>
              <input
                id="doc-file-input"
                type="file"
                required
                onChange={(e) => setFileObj(e.target.files?.[0] || null)}
                className="w-full px-3 py-1.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-slate-300"
              />
            </div>
          </div>

          {error && (
            <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={uploading}
            className="px-4 py-2 text-sm font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
          >
            {uploading ? 'Uploading...' : 'Upload to Library'}
          </button>
        </form>
      )}

      <div className="bg-[#121923] border border-[#243247] rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-[#243247] text-xs text-slate-400 bg-[#0e141d]">
                <th className="py-3 px-4 font-semibold">Title &amp; Description</th>
                <th className="py-3 px-4 font-semibold">Type</th>
                <th className="py-3 px-4 font-semibold">File</th>
                <th className="py-3 px-4 font-semibold">Access</th>
                <th className="py-3 px-4 font-semibold">Version</th>
                <th className="py-3 px-4 font-semibold">Download</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e2a3b]">
              {visibleDocs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-6 px-4 text-slate-400">
                    No matching documents stored in library.
                  </td>
                </tr>
              ) : (
                visibleDocs.map((d) => (
                  <tr key={d.id} className="hover:bg-[#161f2c]/60">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-white">{d.title}</div>
                      {d.description && <div className="text-xs text-slate-400 mt-0.5">{d.description}</div>}
                    </td>
                    <td className="py-3 px-4 text-xs font-mono-tabular text-slate-300 whitespace-nowrap">
                      {d.doc_type}
                    </td>
                    <td className="py-3 px-4 text-xs font-mono-tabular text-slate-300 whitespace-nowrap">
                      {d.filename} ({Math.max(1, Math.round(d.size_bytes / 1024))} KB)
                    </td>
                    <td className="py-3 px-4 text-xs font-mono-tabular text-slate-300 whitespace-nowrap">
                      {d.access_level}
                    </td>
                    <td className="py-3 px-4 text-xs font-mono-tabular text-slate-300 whitespace-nowrap">
                      v{d.version_number}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => {
                          setError('');
                          downloadAuthorizedFile(d.id, d.filename).catch((err) => {
                            setError(err instanceof Error ? err.message : 'Download failed.');
                          });
                        }}
                        className="inline-block px-3 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-sky-300 rounded-md"
                      >
                        Download
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
