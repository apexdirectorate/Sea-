import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { DecisionRecord, Project, User } from '../types';
import { StatusTag } from './StatusTag';

interface DecisionLedgerViewProps {
  decisions: DecisionRecord[];
  projects: Project[];
  user: User;
  onRefresh: () => Promise<void>;
}

export const DecisionLedgerView: React.FC<DecisionLedgerViewProps> = ({
  decisions,
  projects,
  user,
  onRefresh,
}) => {
  const isG0 = user.role === 'G0_DIRECTOR';
  const [category, setCategory] = useState<'PN-DECISION' | 'PN-CHARTER'>('PN-DECISION');
  const [projectId, setProjectId] = useState('');
  const [subject, setSubject] = useState('');
  const [supersedesId, setSupersedesId] = useState('');
  const [content, setContent] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await apiRequest('decisions', {
        method: 'POST',
        body: JSON.stringify({
          category,
          project_id: projectId || null,
          subject,
          supersedes_decision_id: supersedesId || null,
          content,
        }),
      });
      setSubject('');
      setContent('');
      setSupersedesId('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to append decision.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">Append-Only Decision &amp; Charter Ledger</h1>
        <p className="text-sm text-slate-400 mt-1">
          Enforced by SQLite immutability triggers. Approved decisions are never silently altered or deleted; corrections append a new record referencing the prior decision.
        </p>
      </div>

      {isG0 && (
        <form onSubmit={handleSubmit} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
          <h2 className="text-base font-semibold text-white">Append Official Record (G-0 Only)</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="dec-cat" className="block text-xs font-medium text-slate-300 mb-1">
                Official Record Category
              </label>
              <select
                id="dec-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value as 'PN-DECISION' | 'PN-CHARTER')}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="PN-DECISION">PN-DECISION (Final Director Decision)</option>
                <option value="PN-CHARTER">PN-CHARTER (Governance &amp; Instructions)</option>
              </select>
            </div>
            <div>
              <label htmlFor="dec-proj" className="block text-xs font-medium text-slate-300 mb-1">
                Related Project (optional)
              </label>
              <select
                id="dec-proj"
                value={projectId}
                onChange={(e) => setProjectId(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="">Council-Wide</option>
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.id} — {p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="dec-subj" className="block text-xs font-medium text-slate-300 mb-1">
                Subject
              </label>
              <input
                id="dec-subj"
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              />
            </div>
            <div>
              <label htmlFor="dec-super" className="block text-xs font-medium text-slate-300 mb-1">
                Supersedes Prior Decision (for corrections)
              </label>
              <select
                id="dec-super"
                value={supersedesId}
                onChange={(e) => setSupersedesId(e.target.value)}
                className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
              >
                <option value="">None (New Record)</option>
                {decisions.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.record_ref} — {d.subject}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label htmlFor="dec-content" className="block text-xs font-medium text-slate-300 mb-1">
              Full Decision / Charter Content
            </label>
            <textarea
              id="dec-content"
              required
              rows={3}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>

          {error && (
            <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="px-4 py-2 text-sm font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
          >
            {submitting ? 'Appending...' : 'Append to Official Ledger'}
          </button>
        </form>
      )}

      <div className="space-y-4">
        {decisions.length === 0 ? (
          <div className="bg-[#121923] border border-[#243247] rounded-lg p-6 text-sm text-slate-400">
            No decisions recorded in the ledger yet.
          </div>
        ) : (
          decisions.map((d) => (
            <article key={d.id} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-base font-semibold text-white">
                  <span className="font-mono-tabular text-xs text-sky-300 mr-2">{d.record_ref}</span>
                  {d.subject}
                </div>
                <div className="flex gap-2">
                  {d.is_sample === 1 && <StatusTag value="SAMPLE DATA" />}
                  <StatusTag value={d.approval_status} />
                </div>
              </div>
              <div className="text-xs text-slate-400 font-mono-tabular">
                Author: {d.author_identity} · {d.created_at}
                {d.project_id && <> · Project: {d.project_id}</>}
                {d.supersedes_decision_id && <> · Supersedes: {d.supersedes_decision_id}</>}
              </div>
              <p className="text-sm text-slate-200 leading-relaxed">{d.content}</p>
            </article>
          ))
        )}
      </div>
    </div>
  );
};
