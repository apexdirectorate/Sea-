import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { Assignment, CouncilReport, Department, User } from '../types';
import { StatusTag } from './StatusTag';

interface ReportCenterViewProps {
  reports: CouncilReport[];
  assignments: Assignment[];
  departments: Department[];
  user: User;
  onRefresh: () => Promise<void>;
}

export const ReportCenterView: React.FC<ReportCenterViewProps> = ({
  reports,
  assignments,
  departments,
  user,
  onRefresh,
}) => {
  const [taskId, setTaskId] = useState(assignments[0]?.id || '');
  const [deptId, setDeptId] = useState(user.department_id || departments[0]?.id || 'dept-claude');
  const [parentReportId, setParentReportId] = useState('');
  const [modelApp, setModelApp] = useState('');
  const [objective, setObjective] = useState('');
  const [findings, setFindings] = useState('');
  const [evidence, setEvidence] = useState('');
  const [assumptions, setAssumptions] = useState('');
  const [limitations, setLimitations] = useState('');
  const [risks, setRisks] = useState('');
  const [recommendations, setRecommendations] = useState('');
  const [unresolvedQuestions, setUnresolvedQuestions] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [analysisMap, setAnalysisMap] = useState<Record<string, string>>({});
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);
  const [analysisError, setAnalysisError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await apiRequest('reports', {
        method: 'POST',
        body: JSON.stringify({
          task_id: taskId || assignments[0]?.id,
          department_id: deptId,
          parent_report_id: parentReportId || null,
          model_application: modelApp,
          objective,
          findings,
          evidence,
          assumptions,
          limitations,
          risks,
          recommendations,
          unresolved_questions: unresolvedQuestions,
        }),
      });
      setModelApp('');
      setObjective('');
      setFindings('');
      setEvidence('');
      setAssumptions('');
      setLimitations('');
      setRisks('');
      setRecommendations('');
      setUnresolvedQuestions('');
      setParentReportId('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit report.');
    } finally {
      setSubmitting(false);
    }
  }

  async function runGeminiPreScreen(reportId: string) {
    setAnalysisError('');
    setAnalyzingId(reportId);
    try {
      const res = await apiRequest<{ analysis: string }>('gemini/analyze-report', {
        method: 'POST',
        body: JSON.stringify({ report_id: reportId }),
      });
      setAnalysisMap((prev) => ({ ...prev, [reportId]: res.analysis }));
    } catch (err) {
      setAnalysisError(err instanceof Error ? err.message : 'Gemini pre-screen failed.');
    } finally {
      setAnalyzingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">Report Submission Center (PN-REPORT)</h1>
        <p className="text-sm text-slate-400 mt-1">
          Original report submissions and timestamps are preserved immutably in SQL. Revisions create a new linked version.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
        <h2 className="text-base font-semibold text-white">Submit Structured Council Report</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="rep-task" className="block text-xs font-medium text-slate-300 mb-1">
              Task Reference
            </label>
            <select
              id="rep-task"
              required
              value={taskId || assignments[0]?.id || ''}
              onChange={(e) => setTaskId(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              {assignments.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.task_ref} — {a.assigned_model}: {a.objective}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="rep-dept" className="block text-xs font-medium text-slate-300 mb-1">
              Department
            </label>
            <select
              id="rep-dept"
              required
              value={deptId}
              onChange={(e) => setDeptId(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.assigned_model} — {d.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="rep-parent" className="block text-xs font-medium text-slate-300 mb-1">
              Revision Of (optional)
            </label>
            <select
              id="rep-parent"
              value={parentReportId}
              onChange={(e) => setParentReportId(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              <option value="">New Report (v1)</option>
              {reports.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.report_ref} (v{r.version_number})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="rep-model" className="block text-xs font-medium text-slate-300 mb-1">
              Model / Application
            </label>
            <input
              id="rep-model"
              type="text"
              required
              value={modelApp}
              onChange={(e) => setModelApp(e.target.value)}
              placeholder="e.g., Claude / Anthropic or GPT-6 / OpenAI"
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rep-obj" className="block text-xs font-medium text-slate-300 mb-1">
              Objective
            </label>
            <input
              id="rep-obj"
              type="text"
              required
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="rep-findings" className="block text-xs font-medium text-slate-300 mb-1">
              Findings
            </label>
            <textarea
              id="rep-findings"
              required
              rows={3}
              value={findings}
              onChange={(e) => setFindings(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rep-evidence" className="block text-xs font-medium text-slate-300 mb-1">
              Evidence (Verifiable Data, Calculations, Datasheets)
            </label>
            <textarea
              id="rep-evidence"
              required
              rows={3}
              value={evidence}
              onChange={(e) => setEvidence(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rep-assump" className="block text-xs font-medium text-slate-300 mb-1">
              Assumptions (Separated from Evidence)
            </label>
            <textarea
              id="rep-assump"
              required
              rows={2}
              value={assumptions}
              onChange={(e) => setAssumptions(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rep-limit" className="block text-xs font-medium text-slate-300 mb-1">
              Limitations
            </label>
            <textarea
              id="rep-limit"
              required
              rows={2}
              value={limitations}
              onChange={(e) => setLimitations(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rep-risks" className="block text-xs font-medium text-slate-300 mb-1">
              Risks
            </label>
            <textarea
              id="rep-risks"
              required
              rows={2}
              value={risks}
              onChange={(e) => setRisks(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="rep-rec" className="block text-xs font-medium text-slate-300 mb-1">
              Recommendations
            </label>
            <textarea
              id="rep-rec"
              required
              rows={2}
              value={recommendations}
              onChange={(e) => setRecommendations(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
        </div>

        <div>
          <label htmlFor="rep-q" className="block text-xs font-medium text-slate-300 mb-1">
            Unresolved Questions
          </label>
          <textarea
            id="rep-q"
            required
            rows={2}
            value={unresolvedQuestions}
            onChange={(e) => setUnresolvedQuestions(e.target.value)}
            className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
          />
        </div>

        {error && (
          <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting || assignments.length === 0}
          className="px-4 py-2 text-sm font-semibold bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-md"
        >
          {submitting ? 'Recording Report...' : 'Submit Immutable PN-REPORT'}
        </button>
      </form>

      {analysisError && (
        <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-lg p-3">
          {analysisError}
        </div>
      )}

      <div className="space-y-4">
        {reports.length === 0 ? (
          <div className="bg-[#121923] border border-[#243247] rounded-lg p-6 text-sm text-slate-400">
            No reports submitted yet.
          </div>
        ) : (
          reports.map((r) => (
            <article key={r.id} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="text-xs font-mono-tabular text-sky-300 mr-2">
                    {r.report_ref} (v{r.version_number})
                  </span>
                  <span className="text-xs font-mono-tabular text-slate-400">
                    Task: {r.task_ref}
                  </span>
                </div>
                <StatusTag value={r.director_status} />
              </div>

              <div className="text-xs text-slate-400">
                Model / Application: <strong className="text-slate-200">{r.model_application}</strong>
                <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
                Department: <strong className="text-slate-200">{r.department_name}</strong>
                <span className="mx-2 text-slate-600" aria-hidden="true">·</span>
                <span className="font-mono-tabular">{r.created_at}</span>
              </div>

              <div className="text-sm text-white font-semibold">{r.objective}</div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm text-slate-300 pt-2 border-t border-[#1e2a3b]">
                <div><strong className="text-slate-200">Findings:</strong> {r.findings}</div>
                <div><strong className="text-slate-200">Evidence:</strong> {r.evidence}</div>
                <div><strong className="text-slate-200">Assumptions:</strong> {r.assumptions}</div>
                <div><strong className="text-slate-200">Limitations:</strong> {r.limitations}</div>
                <div><strong className="text-slate-200">Risks:</strong> {r.risks}</div>
                <div><strong className="text-slate-200">Recommendations:</strong> {r.recommendations}</div>
              </div>
              <div className="text-sm text-slate-300">
                <strong className="text-slate-200">Unresolved Questions:</strong> {r.unresolved_questions}
              </div>

              <div className="pt-2 border-t border-[#1e2a3b] flex items-center justify-between">
                <button
                  type="button"
                  disabled={analyzingId === r.id}
                  onClick={() => runGeminiPreScreen(r.id)}
                  className="px-3 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-sky-300 rounded-md"
                >
                  {analyzingId === r.id ? 'Running Gemini Verification Check...' : 'Run Gemini Technical Pre-Screen'}
                </button>
              </div>

              {analysisMap[r.id] && (
                <div className="bg-[#0b1017] border border-[#243247] rounded-md p-3.5 text-xs text-slate-200 whitespace-pre-wrap">
                  <div className="font-semibold text-sky-300 mb-1.5">
                    Gemini Advisory Verification Notes (Non-Authoritative)
                  </div>
                  {analysisMap[r.id]}
                </div>
              )}
            </article>
          ))
        )}
      </div>
    </div>
  );
};
