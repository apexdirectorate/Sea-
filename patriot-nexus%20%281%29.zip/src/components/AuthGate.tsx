import React, { useEffect, useState } from 'react';
import { ShieldCheck, Lock } from 'lucide-react';
import { apiRequest, setSessionToken } from '../api/client';
import type { AuthStatus, User } from '../types';

interface AuthGateProps {
  status: AuthStatus;
  onAuthenticated: (authenticatedUser?: User | null) => Promise<boolean>;
}

interface AuthResponse {
  ok: boolean;
  token?: string;
  user?: User;
}

export const AuthGate: React.FC<AuthGateProps> = ({ status, onAuthenticated }) => {
  const [username, setUsername] = useState(status.needs_bootstrap ? 'g0' : '');
  const [displayName, setDisplayName] = useState('Director G-0');
  const [password, setPassword] = useState('');
  const [bootstrapToken, setBootstrapToken] = useState('');
  const [loadSampleData, setLoadSampleData] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (status.needs_bootstrap && !username) {
      setUsername('g0');
    }
  }, [status.needs_bootstrap, username]);

  async function handleBootstrap(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const res = await apiRequest<AuthResponse>('auth/bootstrap', {
        method: 'POST',
        body: JSON.stringify({
          username,
          display_name: displayName,
          password,
          bootstrap_token: bootstrapToken || undefined,
          load_sample_data: loadSampleData,
        }),
      });
      if (res.token) {
        setSessionToken(res.token);
      }
      const ok = await onAuthenticated(res.user);
      if (!ok) {
        setError('Director G-0 account created, but session verification failed. Sign in with your new credentials.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Initialization failed.');
    } finally {
      setSubmitting(false);
    }
  }

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      const res = await apiRequest<AuthResponse>('auth/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      });
      if (res.token) {
        setSessionToken(res.token);
      }
      const ok = await onAuthenticated(res.user);
      if (!ok) {
        setError('Credentials accepted, but session could not be established in this browser context.');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen bg-[#0b1017] text-[#e6edf5] flex items-center justify-center p-4 sm:p-8">
      <div className="w-full max-w-md bg-[#121923] border border-[#243247] rounded-lg p-6 sm:p-8">
        <div className="flex items-center gap-2 text-xs font-medium text-sky-400 mb-3">
          <ShieldCheck className="w-4 h-4 shrink-0" />
          <span>Private Engineering Command Workspace</span>
        </div>

        <h1 className="text-2xl font-bold tracking-tight text-white">PATRIOT-NEXUS</h1>
        <p className="text-sm text-slate-400 mt-1 mb-6">
          Eight-Model AI Engineering and Research Council · 420 Robotics
        </p>

        {status.needs_bootstrap ? (
          <form onSubmit={handleBootstrap} className="space-y-4">
            <div className="p-3 rounded-md bg-sky-950/40 border border-sky-800/60 text-xs text-slate-200 leading-relaxed">
              No Council accounts exist in the SQL database. Initialize the authoritative <strong>G-0 Director</strong> account to unlock headquarters operations.
            </div>

            <div>
              <label htmlFor="boot-username" className="block text-xs font-medium text-slate-300 mb-1.5">
                Director Username
              </label>
              <input
                id="boot-username"
                type="text"
                required
                minLength={2}
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label htmlFor="boot-display" className="block text-xs font-medium text-slate-300 mb-1.5">
                Director Callsign / Display Name
              </label>
              <input
                id="boot-display"
                type="text"
                required
                minLength={2}
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label htmlFor="boot-password" className="block text-xs font-medium text-slate-300 mb-1.5">
                Password (minimum 12 characters)
              </label>
              <input
                id="boot-password"
                type="password"
                required
                minLength={12}
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter strong G-0 passphrase"
                className="w-full px-3 py-2.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            {status.requires_bootstrap_token && (
              <div>
                <label htmlFor="boot-token" className="block text-xs font-medium text-slate-300 mb-1.5">
                  Server Bootstrap Token
                </label>
                <input
                  id="boot-token"
                  type="password"
                  required
                  value={bootstrapToken}
                  onChange={(e) => setBootstrapToken(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white focus:outline-none focus:border-sky-500"
                />
              </div>
            )}

            <label className="flex items-start gap-2.5 text-xs text-slate-300 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={loadSampleData}
                onChange={(e) => setLoadSampleData(e.target.checked)}
                className="mt-0.5 rounded border-[#243247] bg-[#0b1017]"
              />
              <span>
                Initialize clearly labeled <code className="text-sky-300">[SAMPLE DATA]</code> baseline for 420 Robotics
              </span>
            </label>

            {error && (
              <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-semibold rounded-md transition-colors min-h-[44px]"
            >
              {submitting ? 'Initializing SQL Workspace...' : 'Initialize Director G-0 & Enter'}
            </button>
          </form>
        ) : (
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="flex items-center gap-2 text-xs text-slate-400 pb-1">
              <Lock className="w-3.5 h-3.5 shrink-0" />
              <span>Authentication required before viewing project records.</span>
            </div>

            <div>
              <label htmlFor="login-username" className="block text-xs font-medium text-slate-300 mb-1.5">
                Username
              </label>
              <input
                id="login-username"
                type="text"
                required
                autoComplete="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            <div>
              <label htmlFor="login-password" className="block text-xs font-medium text-slate-300 mb-1.5">
                Password
              </label>
              <input
                id="login-password"
                type="password"
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white focus:outline-none focus:border-sky-500"
              />
            </div>

            {error && (
              <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white text-sm font-semibold rounded-md transition-colors min-h-[44px]"
            >
              {submitting ? 'Authenticating...' : 'Sign In to Headquarters'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
