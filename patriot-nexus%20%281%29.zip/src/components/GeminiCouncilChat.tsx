import React, { useEffect, useRef, useState } from 'react';
import { Send, Trash2, X } from 'lucide-react';
import { apiRequest } from '../api/client';
import type { ChatMessage } from '../types';

interface GeminiCouncilChatProps {
  open: boolean;
  onClose: () => void;
}

export const GeminiCouncilChat: React.FC<GeminiCouncilChatProps> = ({ open, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [departmentScope, setDepartmentScope] = useState('council');
  const [model, setModel] = useState<'gemini-4-hydrogen' | 'gemini-3.1-flash-lite'>('gemini-4-hydrogen');
  const [thinkingMode, setThinkingMode] = useState<'HIGH' | 'LOW'>('HIGH');
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    apiRequest<{ messages: ChatMessage[] }>('gemini/chat?thread_id=default')
      .then((res) => setMessages(res.messages))
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load chat history.'));
  }, [open]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, open]);

  if (!open) return null;

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || loading) return;
    setError('');
    setInput('');

    const optimisticUser: ChatMessage = {
      id: `temp-${Date.now()}`,
      role: 'user',
      department_scope: departmentScope,
      model_used: model,
      thinking_level: thinkingMode,
      content: text,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimisticUser]);
    setLoading(true);

    try {
      const res = await apiRequest<{ reply: string; modelUsed: string; thinkingUsed: string }>('gemini/chat', {
        method: 'POST',
        body: JSON.stringify({
          thread_id: 'default',
          message: text,
          department_scope: departmentScope,
          model,
          thinking_mode: thinkingMode,
        }),
      });
      setMessages((prev) => [
        ...prev,
        {
          id: `rep-${Date.now()}`,
          role: 'model',
          department_scope: departmentScope,
          model_used: res.modelUsed,
          thinking_level: res.thinkingUsed,
          content: res.reply,
          created_at: new Date().toISOString(),
        },
      ]);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Gemini chat request failed.');
    } finally {
      setLoading(false);
    }
  }

  async function clearThread() {
    setError('');
    await apiRequest('gemini/chat?thread_id=default', { method: 'DELETE' });
    setMessages([]);
  }

  return (
    <aside
      aria-label="Gemini Council Assistant"
      className="fixed inset-y-0 right-0 z-40 w-full sm:w-[420px] bg-[#121923] border-l border-[#243247] flex flex-col shadow-2xl"
    >
      <div className="p-4 border-b border-[#243247] flex items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-bold text-white">Gemini Council Assistant</h2>
          <p className="text-xs text-slate-400">Multi-turn engineering &amp; synthesis chat</p>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={clearThread}
            aria-label="Clear conversation history"
            className="p-2 text-slate-400 hover:text-white rounded-md hover:bg-[#182230]"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Gemini Council Assistant"
            className="p-2 text-slate-400 hover:text-white rounded-md hover:bg-[#182230]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="p-3 border-b border-[#243247] space-y-2 bg-[#0e141d]">
        <select
          aria-label="Assistant Role"
          value={departmentScope}
          onChange={(e) => setDepartmentScope(e.target.value)}
          className="w-full px-2.5 py-1.5 text-xs bg-[#0b1017] border border-[#243247] rounded text-slate-200"
        >
          <option value="council">Role: General Council Assistant</option>
          <option value="gemini-math">Role: Gemini Simulation, Math &amp; Modeling</option>
          <option value="synthesis">Role: Report Synthesis &amp; Contradiction Check</option>
        </select>
        <div className="grid grid-cols-2 gap-2">
          <select
            aria-label="Gemini Model"
            value={model}
            onChange={(e) => setModel(e.target.value as 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite')}
            className="px-2.5 py-1.5 text-xs bg-[#0b1017] border border-[#243247] rounded text-slate-200"
          >
            <option value="gemini-4-hydrogen">Gemini 4 Hydrogen</option>
            <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite</option>
          </select>
          <select
            aria-label="Thinking Level"
            value={thinkingMode}
            disabled={model !== 'gemini-4-hydrogen'}
            onChange={(e) => setThinkingMode(e.target.value as 'HIGH' | 'LOW')}
            className="px-2.5 py-1.5 text-xs bg-[#0b1017] border border-[#243247] rounded text-slate-200 disabled:opacity-50"
          >
            <option value="HIGH">Thinking: HIGH</option>
            <option value="LOW">Thinking: LOW</option>
          </select>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.length === 0 ? (
          <div className="text-xs text-slate-400 leading-relaxed bg-[#0b1017] border border-[#243247] rounded-md p-3">
            Ask Gemini to analyze 420 Robotics equations, cross-check Council assignments, or highlight missing evidence. Conversation history persists in SQLite for your session.
          </div>
        ) : (
          messages.map((m) => (
            <div
              key={m.id}
              className={`rounded-lg p-3 text-xs leading-relaxed whitespace-pre-wrap ${
                m.role === 'user'
                  ? 'bg-sky-950/50 border border-sky-800/60 text-white ml-6'
                  : 'bg-[#0b1017] border border-[#243247] text-slate-200 mr-4'
              }`}
            >
              <div className="font-mono-tabular text-[11px] text-slate-400 mb-1">
                {m.role === 'user' ? 'G-0 / Operator' : `${m.model_used} (${m.thinking_level})`}
              </div>
              {m.content}
            </div>
          ))
        )}
        {loading && (
          <div className="text-xs text-slate-400 font-mono-tabular">Thinking...</div>
        )}
      </div>

      {error && (
        <div role="alert" className="mx-3 mb-2 text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded p-2">
          {error}
        </div>
      )}

      <form onSubmit={handleSend} className="p-3 border-t border-[#243247] flex gap-2">
        <input
          aria-label="Chat message"
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask Gemini about 420 Robotics..."
          className="flex-1 px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white focus:outline-none focus:border-sky-500"
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          aria-label="Send message"
          className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white rounded-md flex items-center justify-center"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </aside>
  );
};
