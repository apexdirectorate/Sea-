import React, { useState } from 'react';
import { apiRequest } from '../api/client';
import type { Department, User, UserRole } from '../types';

interface UsersManagementViewProps {
  users: User[];
  departments: Department[];
  currentUser: User;
  onRefresh: () => Promise<void>;
}

export const UsersManagementView: React.FC<UsersManagementViewProps> = ({
  users,
  departments,
  currentUser,
  onRefresh,
}) => {
  const isG0 = currentUser.role === 'G0_DIRECTOR';
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [role, setRole] = useState<UserRole>('DEPT_MODEL');
  const [departmentId, setDepartmentId] = useState('dept-claude');
  const [password, setPassword] = useState('');
  const [canSubmit, setCanSubmit] = useState(true);
  const [canReview, setCanReview] = useState(true);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!isG0) {
    return (
      <div className="bg-rose-950/40 border border-rose-800/70 rounded-lg p-5 text-sm text-rose-200">
        Access Denied: Only Director G-0 may view or manage Council user accounts and permissions.
      </div>
    );
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setSubmitting(true);
    try {
      await apiRequest('users', {
        method: 'POST',
        body: JSON.stringify({
          username,
          display_name: displayName,
          role,
          department_id: departmentId || null,
          password,
          can_submit: canSubmit,
          can_review: canReview,
        }),
      });
      setUsername('');
      setDisplayName('');
      setPassword('');
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create user.');
    } finally {
      setSubmitting(false);
    }
  }

  async function toggleActive(userId: string, nextActive: number) {
    setError('');
    try {
      await apiRequest(`users/${userId}`, {
        method: 'PATCH',
        body: JSON.stringify({ is_active: nextActive }),
      });
      await onRefresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update user.');
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#121923] border border-[#243247] rounded-lg p-5">
        <h1 className="text-xl font-bold text-white">User &amp; Permission Management</h1>
        <p className="text-sm text-slate-400 mt-1">
          Provision department accounts, independent reviewers, or read-only observers. Only G-0 holds approval authority.
        </p>
      </div>

      <form onSubmit={handleCreate} className="bg-[#121923] border border-[#243247] rounded-lg p-5 space-y-4">
        <h2 className="text-base font-semibold text-white">Create Council Account</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="usr-name" className="block text-xs font-medium text-slate-300 mb-1">
              Username
            </label>
            <input
              id="usr-name"
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="claude-mech"
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="usr-disp" className="block text-xs font-medium text-slate-300 mb-1">
              Display Name
            </label>
            <input
              id="usr-disp"
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Claude Mechanical Operator"
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            />
          </div>
          <div>
            <label htmlFor="usr-role" className="block text-xs font-medium text-slate-300 mb-1">
              Role
            </label>
            <select
              id="usr-role"
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              <option value="DEPT_MODEL">DEPT_MODEL (Department AI / Operator)</option>
              <option value="REVIEWER">REVIEWER (Independent Verification)</option>
              <option value="READ_ONLY">READ_ONLY (Observer)</option>
              <option value="G0_DIRECTOR">G0_DIRECTOR</option>
            </select>
          </div>
          <div>
            <label htmlFor="usr-dept" className="block text-xs font-medium text-slate-300 mb-1">
              Assigned Department
            </label>
            <select
              id="usr-dept"
              value={departmentId}
              onChange={(e) => setDepartmentId(e.target.value)}
              className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
            >
              <option value="">Council-Wide</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.assigned_model} — {d.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="usr-pass" className="block text-xs font-medium text-slate-300 mb-1">
            Password (minimum 10 characters)
          </label>
          <input
            id="usr-pass"
            type="password"
            required
            minLength={10}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-3 py-2 bg-[#0b1017] border border-[#243247] rounded-md text-sm text-white"
          />
        </div>

        <div className="flex flex-wrap gap-6">
          <label className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={canSubmit}
              onChange={(e) => setCanSubmit(e.target.checked)}
              className="rounded border-[#243247] bg-[#0b1017]"
            />
            <span>Submission Permission</span>
          </label>
          <label className="inline-flex items-center gap-2 text-xs text-slate-200 cursor-pointer">
            <input
              type="checkbox"
              checked={canReview}
              onChange={(e) => setCanReview(e.target.checked)}
              className="rounded border-[#243247] bg-[#0b1017]"
            />
            <span>Review Permission</span>
          </label>
        </div>

        {error && (
          <div role="alert" className="text-xs text-rose-300 bg-rose-950/40 border border-rose-800/70 rounded-md p-2.5">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={submitting}
          className="px-4 py-2 text-sm font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md"
        >
          {submitting ? 'Creating Account...' : 'Create Council Account'}
        </button>
      </form>

      <div className="bg-[#121923] border border-[#243247] rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-[#243247] text-xs text-slate-400 bg-[#0e141d]">
                <th className="py-3 px-4 font-semibold">User</th>
                <th className="py-3 px-4 font-semibold">Role</th>
                <th className="py-3 px-4 font-semibold">Department</th>
                <th className="py-3 px-4 font-semibold">Permissions</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1e2a3b]">
              {users.map((u) => (
                <tr key={u.id}>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-white">{u.username}</div>
                    <div className="text-xs text-slate-400">{u.display_name}</div>
                  </td>
                  <td className="py-3 px-4 text-xs font-mono-tabular text-sky-300">{u.role}</td>
                  <td className="py-3 px-4 text-xs text-slate-300">{u.department_name || 'Council-Wide'}</td>
                  <td className="py-3 px-4 text-xs font-mono-tabular text-slate-300">
                    Submit:{u.can_submit} · Review:{u.can_review} · Approve:{u.can_approve}
                  </td>
                  <td className="py-3 px-4 text-xs font-mono-tabular text-slate-200">
                    {u.is_active ? 'ACTIVE' : 'DISABLED'}
                  </td>
                  <td className="py-3 px-4">
                    {u.id !== currentUser.id ? (
                      <button
                        type="button"
                        onClick={() => toggleActive(u.id, u.is_active ? 0 : 1)}
                        className="px-2.5 py-1 text-xs bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded"
                      >
                        {u.is_active ? 'Disable' : 'Enable'}
                      </button>
                    ) : (
                      <span className="text-xs text-slate-400">Active Session</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
