/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useState } from 'react';
import { Menu, MessageSquare, LogOut } from 'lucide-react';
import { apiRequest, setSessionToken } from './api/client';
import type {
  AIProvider,
  Assignment,
  AuthStatus,
  CouncilReport,
  CouncilReview,
  DashboardPayload,
  DecisionRecord,
  Department,
  DocumentItem,
  PageId,
  Project,
  SystemSetting,
  User,
} from './types';
import { AuthGate } from './components/AuthGate';
import { DashboardView } from './components/DashboardView';
import { DirectorControlView } from './components/DirectorControlView';
import { DepartmentWorkspaceView } from './components/DepartmentWorkspaceView';
import { ProjectBoardView } from './components/ProjectBoardView';
import { AssignmentManagerView } from './components/AssignmentManagerView';
import { ReportCenterView } from './components/ReportCenterView';
import { ReviewCenterView } from './components/ReviewCenterView';
import { DecisionLedgerView } from './components/DecisionLedgerView';
import { DocumentLibraryView } from './components/DocumentLibraryView';
import { ProvidersView } from './components/ProvidersView';
import { UsersManagementView } from './components/UsersManagementView';
import { SystemSettingsView } from './components/SystemSettingsView';
import { GeminiCouncilChat } from './components/GeminiCouncilChat';
import { HeaderSearchBar } from './components/HeaderSearchBar';

const NAV_ITEMS: Array<{ id: PageId; label: string; group: string }> = [
  { id: 'dashboard', label: 'Headquarters Dashboard', group: 'Command' },
  { id: 'director', label: 'Director Control Center', group: 'Command' },
  { id: 'departments', label: 'Eight Department Workspaces', group: 'Command' },
  { id: 'projects', label: 'Project Board', group: 'Operations' },
  { id: 'assignments', label: 'Assignment Manager', group: 'Operations' },
  { id: 'reports', label: 'Report Submission Center', group: 'Operations' },
  { id: 'reviews', label: 'Independent Review Center', group: 'Operations' },
  { id: 'decisions', label: 'Decision Ledger', group: 'Operations' },
  { id: 'library', label: 'Research & Document Library', group: 'Operations' },
  { id: 'providers', label: 'AI Provider Integrations', group: 'Administration' },
  { id: 'users', label: 'User & Permission Mgmt', group: 'Administration' },
  { id: 'settings', label: 'System Settings', group: 'Administration' },
];

export default function App() {
  const [authStatus, setAuthStatus] = useState<AuthStatus | null>(null);
  const [authError, setAuthError] = useState('');
  const [page, setPage] = useState<PageId>('dashboard');
  const [selectedDeptId, setSelectedDeptId] = useState('dept-gpt6');
  const [librarySearchQuery, setLibrarySearchQuery] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);

  const [dashboard, setDashboard] = useState<DashboardPayload | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [reports, setReports] = useState<CouncilReport[]>([]);
  const [reviews, setReviews] = useState<CouncilReview[]>([]);
  const [decisions, setDecisions] = useState<DecisionRecord[]>([]);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [providers, setProviders] = useState<AIProvider[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [settings, setSettings] = useState<SystemSetting[]>([]);
  const [loadingPage, setLoadingPage] = useState(false);
  const [pageError, setPageError] = useState('');

  const loadAuthStatus = useCallback(async (): Promise<boolean> => {
    try {
      const status = await apiRequest<AuthStatus>('auth/status');
      setAuthStatus(status);
      return Boolean(status.authenticated && status.user);
    } catch (err) {
      setAuthError(err instanceof Error ? err.message : 'Unable to reach PATRIOT-NEXUS server.');
      return false;
    }
  }, []);

  const handleAuthenticated = useCallback(
    async (authenticatedUser?: User | null): Promise<boolean> => {
      const verified = await loadAuthStatus();
      if (verified) {
        setPage('dashboard');
        return true;
      }
      if (authenticatedUser) {
        setAuthStatus({
          needs_bootstrap: false,
          requires_bootstrap_token: false,
          authenticated: true,
          user: authenticatedUser,
        });
        setPage('dashboard');
        return true;
      }
      return false;
    },
    [loadAuthStatus]
  );

  useEffect(() => {
    loadAuthStatus();
  }, [loadAuthStatus]);

  const loadPageData = useCallback(
    async (targetPage: PageId, currentUser: User) => {
      setLoadingPage(true);
      setPageError('');
      try {
        if (targetPage === 'dashboard') {
          const dash = await apiRequest<DashboardPayload>('dashboard');
          setDashboard(dash);
          setDepartments(dash.departments);
        } else if (targetPage === 'director') {
          const [dash, docs] = await Promise.all([
            apiRequest<DashboardPayload>('dashboard'),
            apiRequest<{ documents: DocumentItem[] }>('documents'),
          ]);
          setDashboard(dash);
          setDocuments(docs.documents);
        } else if (targetPage === 'departments') {
          const deptsRes = await apiRequest<{ departments: Department[] }>('departments');
          setDepartments(deptsRes.departments);
        } else if (targetPage === 'projects') {
          const [pRes, dRes] = await Promise.all([
            apiRequest<{ projects: Project[] }>('projects'),
            apiRequest<{ departments: Department[] }>('departments'),
          ]);
          setProjects(pRes.projects);
          setDepartments(dRes.departments);
        } else if (targetPage === 'assignments') {
          const [aRes, pRes, dRes] = await Promise.all([
            apiRequest<{ assignments: Assignment[] }>('assignments'),
            apiRequest<{ projects: Project[] }>('projects'),
            apiRequest<{ departments: Department[] }>('departments'),
          ]);
          setAssignments(aRes.assignments);
          setProjects(pRes.projects);
          setDepartments(dRes.departments);
        } else if (targetPage === 'reports') {
          const [rRes, aRes, dRes] = await Promise.all([
            apiRequest<{ reports: CouncilReport[] }>('reports'),
            apiRequest<{ assignments: Assignment[] }>('assignments'),
            apiRequest<{ departments: Department[] }>('departments'),
          ]);
          setReports(rRes.reports);
          setAssignments(aRes.assignments);
          setDepartments(dRes.departments);
        } else if (targetPage === 'reviews') {
          const [rvRes, rRes, dRes] = await Promise.all([
            apiRequest<{ reviews: CouncilReview[] }>('reviews'),
            apiRequest<{ reports: CouncilReport[] }>('reports'),
            apiRequest<{ departments: Department[] }>('departments'),
          ]);
          setReviews(rvRes.reviews);
          setReports(rRes.reports);
          setDepartments(dRes.departments);
        } else if (targetPage === 'decisions') {
          const [decRes, pRes] = await Promise.all([
            apiRequest<{ decisions: DecisionRecord[] }>('decisions'),
            apiRequest<{ projects: Project[] }>('projects'),
          ]);
          setDecisions(decRes.decisions);
          setProjects(pRes.projects);
        } else if (targetPage === 'library') {
          const [docRes, pRes, dRes] = await Promise.all([
            apiRequest<{ documents: DocumentItem[] }>('documents'),
            apiRequest<{ projects: Project[] }>('projects'),
            apiRequest<{ departments: Department[] }>('departments'),
          ]);
          setDocuments(docRes.documents);
          setProjects(pRes.projects);
          setDepartments(dRes.departments);
        } else if (targetPage === 'providers') {
          const provRes = await apiRequest<{ providers: AIProvider[] }>('providers');
          setProviders(provRes.providers);
        } else if (targetPage === 'users') {
          if (currentUser.role === 'G0_DIRECTOR') {
            const [uRes, dRes] = await Promise.all([
              apiRequest<{ users: User[] }>('users'),
              apiRequest<{ departments: Department[] }>('departments'),
            ]);
            setUsers(uRes.users);
            setDepartments(dRes.departments);
          }
        } else if (targetPage === 'settings') {
          const sRes = await apiRequest<{ settings: SystemSetting[] }>('settings');
          setSettings(sRes.settings);
        }
      } catch (err) {
        setPageError(err instanceof Error ? err.message : 'Failed to load data.');
      } finally {
        setLoadingPage(false);
      }
    },
    []
  );

  useEffect(() => {
    if (authStatus?.authenticated && authStatus.user) {
      loadPageData(page, authStatus.user);
    }
  }, [authStatus, page, loadPageData]);

  useEffect(() => {
    if (!authStatus?.authenticated || !authStatus.user || page !== 'dashboard') {
      return;
    }
    let cancelled = false;
    const silentRefresh = async () => {
      if (cancelled || document.visibilityState !== 'visible') return;
      try {
        const dash = await apiRequest<DashboardPayload>('dashboard');
        if (!cancelled) {
          setDashboard(dash);
          setDepartments(dash.departments);
        }
      } catch {
        // Silent background refresh ignores transient errors (session/network changes handled on active actions)
      }
    };

    const intervalId = window.setInterval(silentRefresh, 3000);
    const handleFocusOrVisibility = () => {
      if (document.visibilityState === 'visible') {
        void silentRefresh();
      }
    };
    window.addEventListener('focus', handleFocusOrVisibility);
    document.addEventListener('visibilitychange', handleFocusOrVisibility);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
      window.removeEventListener('focus', handleFocusOrVisibility);
      document.removeEventListener('visibilitychange', handleFocusOrVisibility);
    };
  }, [authStatus?.authenticated, authStatus?.user, page]);

  async function handleLogout() {
    setAuthStatus((prev) =>
      prev ? { ...prev, authenticated: false, user: null } : { needs_bootstrap: false, requires_bootstrap_token: false, authenticated: false, user: null }
    );
    await apiRequest('auth/logout', { method: 'POST' }).catch(() => {});
    setSessionToken(null);
    setDashboard(null);
    setUsers([]);
    setDocuments([]);
    setReports([]);
    setReviews([]);
    setDecisions([]);
    setProjects([]);
    setAssignments([]);
    setChatOpen(false);
    setPage('dashboard');
    setLibrarySearchQuery('');
    await loadAuthStatus();
  }

  function handleNavigate(nextPage: PageId) {
    if (nextPage === 'library') {
      setLibrarySearchQuery('');
    }
    setPage(nextPage);
    setSidebarOpen(false);
  }

  function handleOpenDepartment(deptId: string) {
    setSelectedDeptId(deptId);
    setPage('departments');
    setSidebarOpen(false);
  }

  function handleOpenLibraryWithQuery(q: string) {
    setLibrarySearchQuery(q);
    setPage('library');
    setSidebarOpen(false);
  }

  if (authError) {
    return (
      <div className="min-h-screen bg-[#0b1017] text-rose-300 flex items-center justify-center p-6 text-sm">
        {authError}
      </div>
    );
  }

  if (!authStatus) {
    return (
      <div className="min-h-screen bg-[#0b1017] text-slate-400 flex items-center justify-center p-6 text-sm">
        Verifying PATRIOT-NEXUS security session...
      </div>
    );
  }

  if (!authStatus.authenticated || !authStatus.user) {
    return <AuthGate status={authStatus} onAuthenticated={handleAuthenticated} />;
  }

  const currentUser = authStatus.user;
  const activeNav = NAV_ITEMS.find((n) => n.id === page);
  const groups = ['Command', 'Operations', 'Administration'];

  return (
    <div className="min-h-screen bg-[#0b1017] text-[#e6edf5] flex flex-col">
      <header className="sticky top-0 z-30 bg-[#121923] border-b border-[#243247] px-4 lg:px-6">
        <div className="h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setSidebarOpen((v) => !v)}
              aria-label="Toggle Navigation Menu"
              className="lg:hidden p-2 rounded-md bg-[#182230] border border-[#243247] text-slate-200 min-h-[40px] min-w-[40px] flex items-center justify-center"
            >
              <Menu className="w-5 h-5" />
            </button>
            <span className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
              PATRIOT-NEXUS
            </span>
          </div>

          <div className="hidden md:flex flex-1 items-center justify-center gap-4 min-w-0 px-2">
            <span className="hidden xl:inline text-xs text-slate-400 truncate shrink-0">
              {activeNav?.label}
            </span>
            <HeaderSearchBar
              onSelectDepartment={handleOpenDepartment}
              onOpenProjectBoard={() => handleNavigate('projects')}
              onOpenLibraryWithQuery={handleOpenLibraryWithQuery}
            />
          </div>

          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            <span className="hidden lg:inline text-xs text-slate-300 font-mono-tabular whitespace-nowrap">
              {currentUser.display_name} ({currentUser.role})
            </span>
            <button
              type="button"
              onClick={() => setChatOpen((v) => !v)}
              aria-label="Council AI"
              className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white rounded-md whitespace-nowrap shrink-0 min-h-[36px]"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Council AI</span>
            </button>
            <button
              type="button"
              onClick={handleLogout}
              aria-label="Logout"
              className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-medium bg-[#182230] hover:bg-[#1f2c3d] border border-[#243247] text-slate-200 rounded-md whitespace-nowrap shrink-0 min-h-[36px]"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Logout</span>
            </button>
          </div>
        </div>

        <div className="md:hidden pb-2.5">
          <HeaderSearchBar
            onSelectDepartment={handleOpenDepartment}
            onOpenProjectBoard={() => handleNavigate('projects')}
            onOpenLibraryWithQuery={handleOpenLibraryWithQuery}
          />
        </div>
      </header>

      <div className="flex flex-1 relative">
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-20 bg-black/60 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        <nav
          aria-label="Primary Navigation"
          className={`fixed lg:static inset-y-14 left-0 z-30 w-64 shrink-0 bg-[#121923] border-r border-[#243247] p-3 overflow-y-auto transition-transform duration-150 lg:translate-x-0 ${
            sidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
        >
          <div className="space-y-4">
            {groups.map((grp) => (
              <div key={grp}>
                <div className="px-2.5 pb-1.5 text-[11px] font-semibold tracking-wider text-slate-400">
                  {grp}
                </div>
                <div className="space-y-0.5">
                  {NAV_ITEMS.filter((item) => item.group === grp).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleNavigate(item.id)}
                      className={`w-full text-left px-3 py-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap truncate min-h-[38px] ${
                        page === item.id
                          ? 'bg-sky-600 text-white font-semibold'
                          : 'text-slate-300 hover:bg-[#182230] hover:text-white'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </nav>

        <main className="flex-1 min-w-0 p-4 sm:p-6 max-w-[1360px] w-full mx-auto">
          {pageError && (
            <div role="alert" className="mb-4 bg-rose-950/40 border border-rose-800/70 rounded-lg p-4 text-sm text-rose-300">
              {pageError}
            </div>
          )}

          {loadingPage && !dashboard && page === 'dashboard' ? (
            <div className="bg-[#121923] border border-[#243247] rounded-lg p-6 text-sm text-slate-400">
              Loading PATRIOT-NEXUS SQL workspace...
            </div>
          ) : (
            <>
              {page === 'dashboard' && dashboard && (
                <DashboardView
                  data={dashboard}
                  user={currentUser}
                  onNavigate={handleNavigate}
                  onOpenDepartment={handleOpenDepartment}
                />
              )}
              {page === 'director' && dashboard && (
                <DirectorControlView
                  data={dashboard}
                  user={currentUser}
                  docCount={documents.length}
                  onRefresh={() => loadPageData('director', currentUser)}
                />
              )}
              {page === 'departments' && (
                <DepartmentWorkspaceView
                  departments={departments}
                  selectedDeptId={selectedDeptId}
                  onSelectDept={setSelectedDeptId}
                  user={currentUser}
                  onRefreshDashboard={() => loadPageData('dashboard', currentUser)}
                />
              )}
              {page === 'projects' && (
                <ProjectBoardView
                  projects={projects}
                  departments={departments}
                  user={currentUser}
                  onRefresh={() => loadPageData('projects', currentUser)}
                />
              )}
              {page === 'assignments' && (
                <AssignmentManagerView
                  assignments={assignments}
                  projects={projects}
                  departments={departments}
                  user={currentUser}
                  onRefresh={() => loadPageData('assignments', currentUser)}
                />
              )}
              {page === 'reports' && (
                <ReportCenterView
                  reports={reports}
                  assignments={assignments}
                  departments={departments}
                  user={currentUser}
                  onRefresh={() => loadPageData('reports', currentUser)}
                />
              )}
              {page === 'reviews' && (
                <ReviewCenterView
                  reviews={reviews}
                  reports={reports}
                  departments={departments}
                  user={currentUser}
                  onRefresh={() => loadPageData('reviews', currentUser)}
                />
              )}
              {page === 'decisions' && (
                <DecisionLedgerView
                  decisions={decisions}
                  projects={projects}
                  user={currentUser}
                  onRefresh={() => loadPageData('decisions', currentUser)}
                />
              )}
              {page === 'library' && (
                <DocumentLibraryView
                  documents={documents}
                  projects={projects}
                  departments={departments}
                  user={currentUser}
                  initialQuery={librarySearchQuery}
                  onRefresh={() => loadPageData('library', currentUser)}
                />
              )}
              {page === 'providers' && (
                <ProvidersView
                  providers={providers}
                  user={currentUser}
                  onRefresh={() => loadPageData('providers', currentUser)}
                />
              )}
              {page === 'users' && (
                <UsersManagementView
                  users={users}
                  departments={departments}
                  currentUser={currentUser}
                  onRefresh={() => loadPageData('users', currentUser)}
                />
              )}
              {page === 'settings' && (
                <SystemSettingsView
                  settings={settings}
                  user={currentUser}
                  onRefresh={() => loadPageData('settings', currentUser)}
                />
              )}
            </>
          )}
        </main>
      </div>

      <GeminiCouncilChat open={chatOpen} onClose={() => setChatOpen(false)} />
    </div>
  );
}
