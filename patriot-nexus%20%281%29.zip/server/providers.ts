export interface ProviderTestResult {
  connection_status: 'NOT CONNECTED' | 'CONNECTED' | 'ERROR';
  auth_status: 'UNCONFIGURED' | 'CONFIGURED_UNVERIFIED' | 'VERIFIED' | 'FAILED';
  error: string | null;
}

interface ProviderAdapter {
  secretKey: string;
  test: () => Promise<ProviderTestResult>;
}

function unconfigured(secretName: string): ProviderTestResult {
  return {
    connection_status: 'NOT CONNECTED',
    auth_status: 'UNCONFIGURED',
    error: `Server secret ${secretName} is not configured in environment.`
  };
}

async function parseHttpProbe(res: Response, label: string): Promise<ProviderTestResult> {
  if (res.ok) {
    return {
      connection_status: 'CONNECTED',
      auth_status: 'VERIFIED',
      error: null
    };
  }
  return {
    connection_status: 'ERROR',
    auth_status: 'FAILED',
    error: `${label} returned HTTP ${res.status}`
  };
}

async function probeCustomEndpoint(url: string, bearerKey: string | undefined, label: string): Promise<ProviderTestResult> {
  try {
    const headers: Record<string, string> = bearerKey ? { Authorization: `Bearer ${bearerKey}` } : {};
    const res = await fetch(url, { method: 'GET', headers });
    return parseHttpProbe(res, label);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown network error';
    return {
      connection_status: 'ERROR',
      auth_status: 'FAILED',
      error: `${label} unreachable: ${message}`
    };
  }
}

const ADAPTERS: Record<string, ProviderAdapter> = {
  'prov-openai': {
    secretKey: 'OPENAI_API_KEY',
    async test() {
      const apiKey = process.env.OPENAI_API_KEY;
      if (!apiKey) return unconfigured('OPENAI_API_KEY');
      const res = await fetch('https://api.openai.com/v1/models', {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      return parseHttpProbe(res, 'OpenAI API');
    }
  },
  'prov-anthropic': {
    secretKey: 'ANTHROPIC_API_KEY',
    async test() {
      const apiKey = process.env.ANTHROPIC_API_KEY;
      if (!apiKey) return unconfigured('ANTHROPIC_API_KEY');
      const res = await fetch('https://api.anthropic.com/v1/models', {
        headers: {
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01'
        }
      });
      return parseHttpProbe(res, 'Anthropic API');
    }
  },
  'prov-copilot': {
    secretKey: 'COPILOT_API_ENDPOINT',
    async test() {
      const endpoint = process.env.COPILOT_API_ENDPOINT;
      if (!endpoint) {
        return {
          connection_status: 'NOT CONNECTED',
          auth_status: 'UNCONFIGURED',
          error: 'No COPILOT_API_ENDPOINT configured. Use Manual Dispatch & Report Submission workflow.'
        };
      }
      return probeCustomEndpoint(endpoint, process.env.COPILOT_API_KEY, 'Microsoft Copilot Custom Connector');
    }
  },
  'prov-grok': {
    secretKey: 'XAI_API_KEY',
    async test() {
      const apiKey = process.env.XAI_API_KEY;
      if (!apiKey) return unconfigured('XAI_API_KEY');
      const res = await fetch('https://api.x.ai/v1/models', {
        headers: { Authorization: `Bearer ${apiKey}` }
      });
      return parseHttpProbe(res, 'xAI Grok API');
    }
  },
  'prov-gemini': {
    secretKey: 'GEMINI_API_KEY',
    async test() {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') return unconfigured('GEMINI_API_KEY');
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`
      );
      return parseHttpProbe(res, 'Google Gemini API');
    }
  },
  'prov-meta': {
    secretKey: 'META_AI_ENDPOINT',
    async test() {
      const endpoint = process.env.META_AI_ENDPOINT;
      if (!endpoint) {
        return {
          connection_status: 'NOT CONNECTED',
          auth_status: 'UNCONFIGURED',
          error: 'Consumer Meta AI has no standard direct Council API. Configure META_AI_ENDPOINT or use Manual Workflow.'
        };
      }
      return probeCustomEndpoint(endpoint, process.env.META_AI_KEY, 'Meta AI Endpoint');
    }
  },
  'prov-perplexity': {
    secretKey: 'PERPLEXITY_API_KEY',
    async test() {
      const apiKey = process.env.PERPLEXITY_API_KEY;
      if (!apiKey) return unconfigured('PERPLEXITY_API_KEY');
      return {
        connection_status: 'NOT CONNECTED',
        auth_status: 'CONFIGURED_UNVERIFIED',
        error: 'PERPLEXITY_API_KEY is present on server. Perplexity has no metadata-only GET probe; use explicit dispatch when enabled.'
      };
    }
  },
  'prov-muse': {
    secretKey: 'MUSE_AI_ENDPOINT',
    async test() {
      const endpoint = process.env.MUSE_AI_ENDPOINT;
      if (!endpoint) {
        return {
          connection_status: 'NOT CONNECTED',
          auth_status: 'UNCONFIGURED',
          error: 'No MUSE_AI_ENDPOINT configured. Use Manual Dispatch & Independent Review Center.'
        };
      }
      return probeCustomEndpoint(endpoint, process.env.MUSE_AI_KEY, 'Muse AI Endpoint');
    }
  }
};

export function getEnvConfiguredFlag(providerId: string): boolean {
  const adapter = ADAPTERS[providerId];
  if (!adapter) return false;
  const val = process.env[adapter.secretKey];
  return Boolean(val && val !== 'MY_GEMINI_API_KEY');
}

export async function runProviderConnectionTest(providerId: string): Promise<ProviderTestResult> {
  const adapter = ADAPTERS[providerId];
  if (!adapter) {
    return {
      connection_status: 'ERROR',
      auth_status: 'FAILED',
      error: 'Unknown provider adapter ID'
    };
  }
  try {
    return await adapter.test();
  } catch (err) {
    return {
      connection_status: 'ERROR',
      auth_status: 'FAILED',
      error: err instanceof Error ? err.message : 'Connection test failed'
    };
  }
}
