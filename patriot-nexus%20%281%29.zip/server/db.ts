import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { generateId, type AuthUser } from './governance.ts';

let dbInstance: DatabaseSync | null = null;

export function getDb(customPath?: string): DatabaseSync {
  if (dbInstance && !customPath) return dbInstance;

  const dbPath = customPath || process.env.PN_DB_PATH || path.resolve(process.cwd(), 'data', 'patriot-nexus.db');
  if (dbPath !== ':memory:') {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  }

  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA journal_mode = WAL;');
  initializeSchema(db);
  seedCoreData(db);

  if (!customPath) {
    dbInstance = db;
  }
  return db;
}

export function initializeSchema(db: DatabaseSync): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS sequences (
      seq_name TEXT PRIMARY KEY,
      current_value INTEGER NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS departments (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      sort_order INTEGER NOT NULL,
      name TEXT NOT NULL,
      assigned_model TEXT NOT NULL,
      application_name TEXT NOT NULL,
      responsibilities TEXT NOT NULL,
      limitations TEXT NOT NULL,
      testing_requirements TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PROVISIONAL' CHECK (status IN ('PROVISIONAL', 'ACTIVE', 'TESTING', 'SUSPENDED')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('G0_DIRECTOR', 'DEPT_MODEL', 'REVIEWER', 'READ_ONLY')),
      department_id TEXT REFERENCES departments(id),
      can_submit INTEGER NOT NULL DEFAULT 0 CHECK (can_submit IN (0, 1)),
      can_review INTEGER NOT NULL DEFAULT 0 CHECK (can_review IN (0, 1)),
      can_approve INTEGER NOT NULL DEFAULT 0 CHECK (can_approve IN (0, 1)),
      is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
      password_hash TEXT NOT NULL,
      password_salt TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
      last_login_at TEXT
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      token_hash TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
      ip_hint TEXT
    );

    CREATE TABLE IF NOT EXISTS ai_providers (
      id TEXT PRIMARY KEY,
      provider_name TEXT NOT NULL,
      model_name TEXT NOT NULL,
      department_id TEXT NOT NULL REFERENCES departments(id),
      adapter_type TEXT NOT NULL CHECK (adapter_type IN ('API_SUPPORTED', 'MANUAL_WORKFLOW', 'CUSTOM_ENDPOINT')),
      env_secret_name TEXT,
      connection_status TEXT NOT NULL DEFAULT 'NOT CONNECTED' CHECK (connection_status IN ('NOT CONNECTED', 'CONNECTED', 'ERROR')),
      auth_status TEXT NOT NULL DEFAULT 'UNCONFIGURED' CHECK (auth_status IN ('UNCONFIGURED', 'CONFIGURED_UNVERIFIED', 'VERIFIED', 'FAILED')),
      available_permissions TEXT NOT NULL DEFAULT 'MANUAL_DISPATCH',
      supported_operations TEXT NOT NULL,
      last_tested_at TEXT,
      last_error TEXT,
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      objective TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PROPOSED' CHECK (status IN ('PROPOSED', 'ACTIVE', 'PAUSED', 'CLOSED')),
      priority TEXT NOT NULL DEFAULT 'HIGH' CHECK (priority IN ('CRITICAL', 'HIGH', 'MEDIUM', 'LOW')),
      assigned_departments TEXT NOT NULL DEFAULT '[]',
      required_deliverables TEXT NOT NULL DEFAULT '',
      dependencies TEXT NOT NULL DEFAULT '',
      risks TEXT NOT NULL DEFAULT '',
      director_approval_status TEXT NOT NULL DEFAULT 'PENDING_G0' CHECK (director_approval_status IN ('PENDING_G0', 'APPROVED_BY_G0', 'REJECTED_BY_G0')),
      is_sample INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
      created_by TEXT NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS project_history (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
      actor_id TEXT NOT NULL REFERENCES users(id),
      action TEXT NOT NULL,
      details TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS assignments (
      id TEXT PRIMARY KEY,
      task_ref TEXT NOT NULL UNIQUE,
      project_id TEXT NOT NULL REFERENCES projects(id),
      objective TEXT NOT NULL,
      instructions TEXT NOT NULL,
      assigned_department_id TEXT NOT NULL REFERENCES departments(id),
      batch_group_id TEXT,
      required_output TEXT NOT NULL,
      supporting_files TEXT NOT NULL DEFAULT '[]',
      due_date TEXT,
      status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN (
        'Pending', 'Assigned', 'In Progress', 'Submitted',
        'Under Review', 'Revision Required', 'Approved by G-0', 'Rejected', 'Archived'
      )),
      is_sample INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
      created_by TEXT NOT NULL REFERENCES users(id),
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      report_ref TEXT NOT NULL UNIQUE,
      project_id TEXT NOT NULL REFERENCES projects(id),
      task_id TEXT NOT NULL REFERENCES assignments(id),
      department_id TEXT NOT NULL REFERENCES departments(id),
      submitted_by_user_id TEXT NOT NULL REFERENCES users(id),
      model_application TEXT NOT NULL,
      objective TEXT NOT NULL,
      findings TEXT NOT NULL,
      evidence TEXT NOT NULL,
      assumptions TEXT NOT NULL,
      limitations TEXT NOT NULL,
      risks TEXT NOT NULL,
      recommendations TEXT NOT NULL,
      unresolved_questions TEXT NOT NULL,
      parent_report_id TEXT REFERENCES reports(id),
      version_number INTEGER NOT NULL DEFAULT 1,
      director_status TEXT NOT NULL DEFAULT 'PENDING' CHECK (director_status IN ('PENDING', 'ACKNOWLEDGED', 'APPROVED_BY_G0', 'REJECTED_BY_G0')),
      is_sample INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS reviews (
      id TEXT PRIMARY KEY,
      review_ref TEXT NOT NULL UNIQUE,
      report_id TEXT NOT NULL REFERENCES reports(id),
      project_id TEXT NOT NULL REFERENCES projects(id),
      task_id TEXT NOT NULL REFERENCES assignments(id),
      reviewer_department_id TEXT NOT NULL REFERENCES departments(id),
      reviewer_user_id TEXT NOT NULL REFERENCES users(id),
      reviewer_model TEXT NOT NULL,
      verdict TEXT NOT NULL CHECK (verdict IN (
        'ACCEPT', 'REJECT', 'REQUEST_REVISION', 'DISPUTE_FINDINGS',
        'MISSING_EVIDENCE', 'TECHNICAL_ERROR', 'UNSUPPORTED_CLAIMS', 'RECOMMEND_TESTING'
      )),
      summary TEXT NOT NULL,
      technical_notes TEXT NOT NULL,
      disagreements TEXT NOT NULL DEFAULT '',
      evidence_gaps TEXT NOT NULL DEFAULT '',
      recommended_tests TEXT NOT NULL DEFAULT '',
      is_dispute INTEGER NOT NULL DEFAULT 0 CHECK (is_dispute IN (0, 1)),
      resolution_status TEXT NOT NULL DEFAULT 'OPEN' CHECK (resolution_status IN ('OPEN', 'ADDRESSED', 'OVERRULED_BY_G0', 'UPHELD_BY_G0')),
      is_sample INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS decisions (
      id TEXT PRIMARY KEY,
      record_ref TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL CHECK (category IN ('PN-CHARTER', 'PN-DECISION')),
      subject TEXT NOT NULL,
      author_identity TEXT NOT NULL,
      author_user_id TEXT NOT NULL REFERENCES users(id),
      project_id TEXT REFERENCES projects(id),
      task_id TEXT REFERENCES assignments(id),
      report_id TEXT REFERENCES reports(id),
      content TEXT NOT NULL,
      supersedes_decision_id TEXT REFERENCES decisions(id),
      approval_status TEXT NOT NULL DEFAULT 'APPROVED_BY_G0' CHECK (approval_status IN ('APPROVED_BY_G0', 'SUPERSEDED')),
      is_sample INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS documents (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      doc_type TEXT NOT NULL CHECK (doc_type IN (
        'PROJECT_DOC', 'TECH_SPEC', 'RESEARCH', 'CALCULATION',
        'SOURCE_CODE', 'DIAGRAM', 'TEST_RESULT', 'AI_REPORT', 'DECISION_REF', 'REFERENCE'
      )),
      description TEXT NOT NULL DEFAULT '',
      project_id TEXT REFERENCES projects(id),
      department_id TEXT REFERENCES departments(id),
      filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      size_bytes INTEGER NOT NULL,
      content_base64 TEXT NOT NULL,
      version_number INTEGER NOT NULL DEFAULT 1,
      parent_document_id TEXT REFERENCES documents(id),
      access_level TEXT NOT NULL DEFAULT 'COUNCIL_INTERNAL' CHECK (access_level IN ('COUNCIL_INTERNAL', 'DIRECTOR_ONLY', 'DEPARTMENT_RESTRICTED')),
      uploaded_by TEXT NOT NULL REFERENCES users(id),
      is_sample INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id TEXT PRIMARY KEY,
      actor_user_id TEXT REFERENCES users(id),
      actor_label TEXT NOT NULL,
      action_type TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      summary TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS system_settings (
      setting_key TEXT PRIMARY KEY,
      setting_value TEXT NOT NULL,
      updated_by TEXT,
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TABLE IF NOT EXISTS chat_messages (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      thread_id TEXT NOT NULL,
      role TEXT NOT NULL CHECK (role IN ('user', 'model')),
      department_scope TEXT NOT NULL DEFAULT 'council',
      model_used TEXT NOT NULL,
      thinking_level TEXT NOT NULL DEFAULT 'HIGH',
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
    );

    CREATE TRIGGER IF NOT EXISTS prevent_report_content_overwrite
    BEFORE UPDATE ON reports
    FOR EACH ROW
    WHEN NEW.findings != OLD.findings
      OR NEW.evidence != OLD.evidence
      OR NEW.assumptions != OLD.assumptions
      OR NEW.limitations != OLD.limitations
      OR NEW.risks != OLD.risks
      OR NEW.recommendations != OLD.recommendations
      OR NEW.unresolved_questions != OLD.unresolved_questions
      OR NEW.created_at != OLD.created_at
    BEGIN
      SELECT RAISE(ABORT, 'IMMUTABLE_RECORD: Original report content and timestamp cannot be overwritten.');
    END;

    CREATE TRIGGER IF NOT EXISTS prevent_report_delete
    BEFORE DELETE ON reports
    BEGIN
      SELECT RAISE(ABORT, 'IMMUTABLE_RECORD: Submitted reports cannot be deleted.');
    END;

    CREATE TRIGGER IF NOT EXISTS prevent_decision_silent_edit
    BEFORE UPDATE ON decisions
    FOR EACH ROW
    WHEN NEW.subject != OLD.subject
      OR NEW.content != OLD.content
      OR NEW.author_identity != OLD.author_identity
      OR NEW.created_at != OLD.created_at
      OR NEW.record_ref != OLD.record_ref
    BEGIN
      SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER: Official decisions cannot be altered. Issue a new decision referencing this record.');
    END;

    CREATE TRIGGER IF NOT EXISTS prevent_decision_delete
    BEFORE DELETE ON decisions
    BEGIN
      SELECT RAISE(ABORT, 'IMMUTABLE_LEDGER: Official decisions cannot be deleted.');
    END;

    CREATE TRIGGER IF NOT EXISTS prevent_activity_update
    BEFORE UPDATE ON activity_logs
    BEGIN
      SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT: Activity logs cannot be modified.');
    END;

    CREATE TRIGGER IF NOT EXISTS prevent_activity_delete
    BEFORE DELETE ON activity_logs
    BEGIN
      SELECT RAISE(ABORT, 'IMMUTABLE_AUDIT: Activity logs cannot be deleted.');
    END;

    CREATE INDEX IF NOT EXISTS idx_assignments_project ON assignments(project_id);
    CREATE INDEX IF NOT EXISTS idx_assignments_dept ON assignments(assigned_department_id);
    CREATE INDEX IF NOT EXISTS idx_reports_task ON reports(task_id);
    CREATE INDEX IF NOT EXISTS idx_reports_dept ON reports(department_id);
    CREATE INDEX IF NOT EXISTS idx_reviews_report ON reviews(report_id);
    CREATE INDEX IF NOT EXISTS idx_documents_project ON documents(project_id);
    CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
    CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_chat_thread ON chat_messages(user_id, thread_id, created_at ASC);
  `);
}

export function seedCoreData(db: DatabaseSync): void {
  db.exec(`
    INSERT OR IGNORE INTO sequences (seq_name, current_value) VALUES
      ('PN-TASK', 0),
      ('PN-REPORT', 0),
      ('PN-REVIEW', 0),
      ('PN-DECISION', 0),
      ('PN-CHARTER', 0);

    INSERT OR IGNORE INTO departments (id, code, sort_order, name, assigned_model, application_name, responsibilities, limitations, testing_requirements, status) VALUES
      ('dept-gpt6', 'GPT6', 1, 'Chief Architect & Systems Coordination', 'GPT-6', 'OpenAI / ChatGPT',
       'Organize Council operations; translate G-0 instructions into assignments; coordinate dependencies; consolidate reports; identify contradictions and missing evidence; maintain architecture documentation; present recommendations to G-0. Cannot override G-0 or approve own work.',
       'Provisional pending performance testing; external API requires server-side OpenAI credentials.',
       'Architecture consistency benchmarks, dependency conflict detection accuracy, and multi-department synthesis verification.', 'PROVISIONAL'),
      ('dept-claude', 'CLAUDE', 2, 'Mechanical & Robotics Engineering', 'Claude', 'Anthropic / Claude',
       'Mechanical CAD/kinematics review, actuator sizing, structural load analysis, thermal and robotics hardware design for 420 Robotics.',
       'Provisional pending performance testing; cannot execute physical FEA without external solver verification.',
       'Torque/load calculation validation against Gemini math models and physical bench test data.', 'PROVISIONAL'),
      ('dept-copilot', 'COPILOT', 3, 'Software Engineering & Integration', 'Microsoft Copilot', 'Microsoft Copilot',
       'Embedded firmware, ROS2/control loops, API integration, CI/CD pipelines, and hardware-software interface code.',
       'Provisional pending performance testing; direct consumer Copilot integration requires enterprise connector or manual workflow.',
       'Unit test coverage, static analysis, and hardware-in-the-loop integration checks.', 'PROVISIONAL'),
      ('dept-grok', 'GROK', 4, 'Innovation & Adversarial Engineering', 'Grok', 'xAI / Grok',
       'Red-teaming designs, failure-mode exploration, edge-case stress scenarios, and unconventional engineering alternatives.',
       'Provisional pending performance testing; adversarial hypotheses require empirical evidence before acceptance.',
       'Failure-mode reproduction rate and false-positive screening via Muse AI QA.', 'PROVISIONAL'),
      ('dept-gemini', 'GEMINI', 5, 'Simulation, Mathematics & Modeling', 'Gemini', 'Google / Gemini',
       'Kinematics, control theory equations, dynamic simulation modeling, error propagation, and quantitative validation.',
       'Provisional pending performance testing; symbolic derivations must be independently verified.',
       'Numerical convergence checks and independent verification against physical telemetry.', 'PROVISIONAL'),
      ('dept-meta', 'META', 6, 'Computer Vision & Perception', 'Meta AI', 'Meta AI',
       'Visual SLAM, object detection, sensor fusion pipelines, camera calibration, and perception latency budgeting.',
       'Provisional pending performance testing; public Meta AI lacks a standard Council API.',
       'mAP/latency benchmarks on target edge compute and lighting/occlusion robustness tests.', 'PROVISIONAL'),
      ('dept-perplexity', 'PERPLEXITY', 7, 'Research & Intelligence', 'Perplexity', 'Perplexity AI',
       'Literature review, component datasheets, standards compliance research, supplier verification, and cited technical intelligence.',
       'Provisional pending performance testing; all citations must be primary-source verified.',
       'Citation accuracy audit and primary datasheet cross-check.', 'PROVISIONAL'),
      ('dept-muse', 'MUSE', 8, 'Independent Verification & Quality Assurance', 'Muse AI', 'Muse AI',
       'Independent audit of submitted reports, identifying missing evidence, math/technical errors, and unsupported claims. Conclusions are NOT automatically authoritative.',
       'Provisional pending performance testing; custom endpoint or manual verification workflow required.',
       'Audit precision, false-flag rate, and reproducibility of flagged defects.', 'PROVISIONAL');

    INSERT OR IGNORE INTO ai_providers (id, provider_name, model_name, department_id, adapter_type, env_secret_name, connection_status, auth_status, available_permissions, supported_operations) VALUES
      ('prov-openai', 'OpenAI / ChatGPT', 'GPT-6', 'dept-gpt6', 'API_SUPPORTED', 'OPENAI_API_KEY', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH,API_CONFIGURABLE', '["Server Credential Probe", "Generate Dispatch Brief", "Manual Report Submission"]'),
      ('prov-anthropic', 'Anthropic / Claude', 'Claude', 'dept-claude', 'API_SUPPORTED', 'ANTHROPIC_API_KEY', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH,API_CONFIGURABLE', '["Server Credential Probe", "Generate Dispatch Brief", "Manual Report Submission"]'),
      ('prov-copilot', 'Microsoft Copilot', 'Microsoft Copilot', 'dept-copilot', 'MANUAL_WORKFLOW', 'COPILOT_API_ENDPOINT', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH', '["Generate Dispatch Brief", "Manual Report Submission", "Optional Custom Connector"]'),
      ('prov-grok', 'xAI / Grok', 'Grok', 'dept-grok', 'API_SUPPORTED', 'XAI_API_KEY', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH,API_CONFIGURABLE', '["Server Credential Probe", "Generate Dispatch Brief", "Manual Report Submission"]'),
      ('prov-gemini', 'Google / Gemini', 'Gemini', 'dept-gemini', 'API_SUPPORTED', 'GEMINI_API_KEY', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH,API_CONFIGURABLE,COUNCIL_CHAT', '["Server Credential Probe", "Council Synthesis", "Multi-Turn Chat", "Generate Dispatch Brief"]'),
      ('prov-meta', 'Meta AI', 'Meta AI', 'dept-meta', 'MANUAL_WORKFLOW', 'META_AI_ENDPOINT', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH', '["Generate Dispatch Brief", "Manual Report Submission"]'),
      ('prov-perplexity', 'Perplexity', 'Perplexity', 'dept-perplexity', 'API_SUPPORTED', 'PERPLEXITY_API_KEY', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH,API_CONFIGURABLE', '["Server Credential Check", "Generate Dispatch Brief", "Manual Report Submission"]'),
      ('prov-muse', 'Muse AI', 'Muse AI', 'dept-muse', 'CUSTOM_ENDPOINT', 'MUSE_AI_ENDPOINT', 'NOT CONNECTED', 'UNCONFIGURED', 'MANUAL_DISPATCH,CUSTOM_WEBHOOK', '["Generate Dispatch Brief", "Manual Report Submission", "Custom Endpoint Probe"]');

    INSERT OR IGNORE INTO system_settings (setting_key, setting_value, updated_by) VALUES
      ('council_name', 'PATRIOT-NEXUS', 'SYSTEM'),
      ('council_subtitle', 'Eight-Model AI Engineering and Research Council', 'SYSTEM'),
      ('primary_program', '420 Robotics', 'SYSTEM'),
      ('director_callsign', 'G-0', 'SYSTEM'),
      ('enforce_self_approval_block', 'true', 'SYSTEM'),
      ('require_auth_for_all_records', 'true', 'SYSTEM');
  `);
}

export function nextSequenceRef(db: DatabaseSync, seqName: string, prefix: string, suffix = ''): string {
  db.prepare(
    `INSERT INTO sequences (seq_name, current_value) VALUES (?, 0) ON CONFLICT(seq_name) DO NOTHING`
  ).run(seqName);

  const updated = db.prepare(
    `UPDATE sequences SET current_value = current_value + 1 WHERE seq_name = ? RETURNING current_value`
  ).get(seqName) as { current_value: number };

  const padded = String(updated.current_value).padStart(3, '0');
  return suffix ? `${prefix}-${padded}-${suffix}` : `${prefix}-${padded}`;
}

export function logActivity(
  db: DatabaseSync,
  user: Pick<AuthUser, 'id' | 'display_name' | 'role'> | null,
  actionType: string,
  targetType: string,
  targetId: string,
  summary: string
): void {
  db.prepare(`
    INSERT INTO activity_logs (id, actor_user_id, actor_label, action_type, target_type, target_id, summary)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(
    generateId('act'),
    user ? user.id : null,
    user ? `${user.display_name} (${user.role})` : 'SYSTEM',
    actionType,
    targetType,
    targetId,
    summary
  );
}

export function seedSampleRecords(db: DatabaseSync, g0UserId: string): void {
  const existing = db.prepare(`SELECT COUNT(*) AS c FROM projects`).get() as { c: number };
  if (existing && existing.c > 0) return;

  const projId = 'PN-PROJ-420-SAMPLE';
  db.prepare(`
    INSERT INTO projects (
      id, name, objective, description, status, priority, assigned_departments,
      required_deliverables, dependencies, risks, director_approval_status, is_sample, created_by
    ) VALUES (?, ?, ?, ?, 'ACTIVE', 'CRITICAL', ?, ?, ?, ?, 'APPROVED_BY_G0', 1, ?)
  `).run(
    projId,
    '[SAMPLE DATA] 420 Robotics — Autonomous Chassis & Perception Baseline',
    'Establish a verified electro-mechanical, kinematic, software control, and perception baseline for the 420 Robotics platform.',
    'Demonstration baseline project clearly marked as sample data. Replace or archive once live engineering records begin.',
    JSON.stringify(['dept-gpt6', 'dept-claude', 'dept-copilot', 'dept-gemini', 'dept-meta', 'dept-muse']),
    '1) Actuator torque & thermal budget; 2) Kinematic control model; 3) ROS2/firmware interface spec; 4) Independent QA audit.',
    'Motor controller datasheet verification (Perplexity) feeds Gemini math model and Claude mechanical CAD.',
    'Unverified payload mass assumptions or sensor latency spikes under low-light conditions.',
    g0UserId
  );

  db.prepare(`
    INSERT INTO project_history (id, project_id, actor_id, action, details)
    VALUES (?, ?, ?, 'CREATED_SAMPLE', 'Initial [SAMPLE DATA] project baseline initialized during G-0 bootstrap.')
  `).run(generateId('ph'), projId, g0UserId);

  const task1Ref = nextSequenceRef(db, 'PN-TASK', 'PN-TASK');
  const task2Ref = nextSequenceRef(db, 'PN-TASK', 'PN-TASK');
  const batchId = generateId('batch');

  db.prepare(`
    INSERT INTO assignments (
      id, task_ref, project_id, objective, instructions, assigned_department_id, batch_group_id,
      required_output, status, is_sample, created_by
    ) VALUES (?, ?, ?, ?, ?, 'dept-claude', ?, ?, 'Assigned', 1, ?)
  `).run(
    generateId('task'),
    task1Ref,
    projId,
    '[SAMPLE DATA] Drivetrain Torque & Structural Safety Factor Analysis',
    'Evaluate peak stall torque, gearbox thermal margin, and 6061-T6 chassis mount safety factor under 2.5G impact load.',
    batchId,
    'Structured PN-REPORT separating empirical datasheet evidence from mass assumptions.',
    g0UserId
  );

  db.prepare(`
    INSERT INTO assignments (
      id, task_ref, project_id, objective, instructions, assigned_department_id, batch_group_id,
      required_output, status, is_sample, created_by
    ) VALUES (?, ?, ?, ?, ?, 'dept-gemini', ?, ?, 'Assigned', 1, ?)
  `).run(
    generateId('task'),
    task2Ref,
    projId,
    '[SAMPLE DATA] Independent Dynamic Control & Slip Stability Model',
    'Formulate state-space stability equations and numerical error bounds for the 420 Robotics drivetrain.',
    batchId,
    'Structured PN-REPORT with explicit equations, boundary conditions, and convergence criteria.',
    g0UserId
  );

  const charterRef = nextSequenceRef(db, 'PN-CHARTER', 'PN-CHARTER');
  db.prepare(`
    INSERT INTO decisions (
      id, record_ref, category, subject, author_identity, author_user_id, project_id, content, is_sample
    ) VALUES (?, ?, 'PN-CHARTER', ?, 'G-0 (Director)', ?, ?, ?, 1)
  `).run(
    generateId('dec'),
    charterRef,
    '[SAMPLE DATA] Patriot-Nexus Council Governance Charter',
    g0UserId,
    projId,
    'G-0 retains final authority over objectives, assignments, approvals, architecture, and deployment. No AI model may approve its own work or override another model.'
  );
}
