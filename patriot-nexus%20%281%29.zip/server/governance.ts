import crypto from 'node:crypto';

export type UserRole = 'G0_DIRECTOR' | 'DEPT_MODEL' | 'REVIEWER' | 'READ_ONLY';

export interface AuthUser {
  id: string;
  username: string;
  display_name: string;
  role: UserRole;
  department_id: string | null;
  can_submit: number;
  can_review: number;
  can_approve: number;
  is_active: number;
}

export interface TargetReportForReview {
  submitted_by_user_id: string;
  department_id: string;
}

export interface DocumentAccessTarget {
  access_level: 'COUNCIL_INTERNAL' | 'DIRECTOR_ONLY' | 'DEPARTMENT_RESTRICTED';
  department_id: string | null;
}

export function generateId(prefix: string): string {
  return `${prefix}-${crypto.randomBytes(6).toString('hex')}`;
}

export function hashPassword(password: string, existingSaltHex?: string): { hash: string; salt: string } {
  const salt = existingSaltHex || crypto.randomBytes(16).toString('hex');
  const derived = crypto.pbkdf2Sync(password, Buffer.from(salt, 'hex'), 100000, 32, 'sha256');
  return { hash: derived.toString('hex'), salt };
}

export function verifyPassword(password: string, expectedHash: string, saltHex: string): boolean {
  const { hash } = hashPassword(password, saltHex);
  return timingSafeEqualHex(hash, expectedHash);
}

export function timingSafeEqualHex(a: string, b: string): boolean {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length || a.length === 0) {
    return false;
  }
  return crypto.timingSafeEqual(Buffer.from(a, 'utf8'), Buffer.from(b, 'utf8'));
}

export function sha256Hex(value: string): string {
  return crypto.createHash('sha256').update(value, 'utf8').digest('hex');
}

export function createSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const cookies: Record<string, string> = {};
  if (!cookieHeader) return cookies;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx > 0) {
      const k = part.slice(0, idx).trim();
      const v = part.slice(idx + 1).trim();
      try {
        cookies[k] = decodeURIComponent(v);
      } catch {
        cookies[k] = v;
      }
    }
  }
  return cookies;
}

export function extractBearerToken(authHeader: string | undefined): string | null {
  if (!authHeader) return null;
  const match = /^\s*Bearer\s+([A-Za-z0-9._~+/=-]+)\s*$/i.exec(authHeader);
  return match ? match[1] : null;
}

export function buildSessionCookie(token: string, isHttps: boolean, clear = false): string {
  const crossSiteAttrs = isHttps ? '; SameSite=None; Secure; Partitioned' : '; SameSite=Lax';
  if (clear) {
    return `pn_session=; Path=/; HttpOnly${crossSiteAttrs}; Max-Age=0`;
  }
  return `pn_session=${encodeURIComponent(token)}; Path=/; HttpOnly${crossSiteAttrs}; Max-Age=43200`;
}

export function isDirector(user: AuthUser | null | undefined): boolean {
  return Boolean(user && user.role === 'G0_DIRECTOR' && user.can_approve === 1 && user.is_active === 1);
}

export function canCreateAssignments(user: AuthUser | null | undefined): boolean {
  if (!user || user.is_active !== 1) return false;
  if (isDirector(user)) return true;
  return user.role === 'DEPT_MODEL' && user.department_id === 'dept-gpt6' && user.can_submit === 1;
}

export function canSubmitReport(user: AuthUser | null | undefined, departmentId: string): boolean {
  if (!user || user.is_active !== 1) return false;
  if (isDirector(user)) return true;
  return user.role === 'DEPT_MODEL' && user.can_submit === 1 && user.department_id === departmentId;
}

export function canSubmitReview(user: AuthUser | null | undefined, targetReport: TargetReportForReview | null | undefined): boolean {
  if (!user || !targetReport || user.is_active !== 1) return false;
  // Operating rule: No model or user may review or approve its own submitted work
  if (user.id === targetReport.submitted_by_user_id) return false;
  if (user.department_id && user.department_id === targetReport.department_id) return false;
  if (isDirector(user)) return true;
  return (user.role === 'DEPT_MODEL' || user.role === 'REVIEWER') && user.can_review === 1;
}

export function canViewDocument(user: AuthUser | null | undefined, doc: DocumentAccessTarget): boolean {
  if (!user || user.is_active !== 1) return false;
  if (isDirector(user)) return true;
  if (doc.access_level === 'DIRECTOR_ONLY') return false;
  if (doc.access_level === 'DEPARTMENT_RESTRICTED') {
    return Boolean(user.department_id && user.department_id === doc.department_id);
  }
  return true;
}

export const ACTIVE_TASK_STATUSES = [
  'Pending',
  'Assigned',
  'In Progress',
  'Submitted',
  'Under Review',
  'Revision Required',
] as const;

export function isActiveAssignmentStatus(status: string): boolean {
  return (ACTIVE_TASK_STATUSES as readonly string[]).includes(status);
}

export function isDirectorOnlyTaskStatus(status: string): boolean {
  return ['Approved by G-0', 'Rejected', 'Archived', 'Assigned'].includes(status);
}

export interface DepartmentAssignmentAggregate {
  active_assignment_count: number;
  in_progress_count: number;
  revision_required_count: number;
}

export function aggregateDepartmentAssignments(
  assignments: Array<{ assigned_department_id: string; status: string }>
): Record<string, DepartmentAssignmentAggregate> {
  const counts: Record<string, DepartmentAssignmentAggregate> = {};
  for (const task of assignments) {
    if (!counts[task.assigned_department_id]) {
      counts[task.assigned_department_id] = {
        active_assignment_count: 0,
        in_progress_count: 0,
        revision_required_count: 0,
      };
    }
    if (isActiveAssignmentStatus(task.status)) {
      counts[task.assigned_department_id].active_assignment_count += 1;
      if (task.status === 'In Progress') {
        counts[task.assigned_department_id].in_progress_count += 1;
      } else if (task.status === 'Revision Required') {
        counts[task.assigned_department_id].revision_required_count += 1;
      }
    }
  }
  return counts;
}

export function buildDispatchPacket(params: {
  task: { task_ref: string; objective: string; instructions: string; required_output: string };
  project: { id: string; name: string; priority: string; director_approval_status: string; objective: string };
  department: { name: string; assigned_model: string };
  documents: Array<{ id: string; title: string; filename: string }>;
}): string {
  const { task, project, department, documents } = params;
  return [
    'PATRIOT-NEXUS AUTHORIZED COUNCIL DISPATCH BRIEF',
    `Task Reference: ${task.task_ref}`,
    `Project: ${project.id} — ${project.name}`,
    `Priority: ${project.priority} | Director Approval: ${project.director_approval_status}`,
    `Assigned Department: ${department.name} (${department.assigned_model})`,
    'Governance Rule: G-0 retains final authority. You cannot approve your own work or alter approved objectives.',
    '',
    'PROJECT OBJECTIVE',
    project.objective,
    '',
    'TASK OBJECTIVE',
    task.objective,
    '',
    'INSTRUCTIONS',
    task.instructions,
    '',
    'REQUIRED OUTPUT',
    task.required_output,
    '',
    'AUTHORIZED SUPPORTING DOCUMENTS',
    documents.length
      ? documents.map((d) => `- ${d.id}: ${d.title} (${d.filename})`).join('\n')
      : 'None attached.',
    '',
    'REQUIRED STRUCTURED REPORT FIELDS',
    'Model / Application:',
    'Department:',
    `Task Reference: ${task.task_ref}`,
    'Objective:',
    'Findings:',
    'Evidence (cite verifiable data/calculations):',
    'Assumptions (explicitly separated from evidence):',
    'Limitations:',
    'Risks:',
    'Recommendations:',
    'Unresolved Questions:'
  ].join('\n');
}

export interface SearchableDepartment {
  id: string;
  code: string;
  name: string;
  assigned_model: string;
  application_name: string;
  responsibilities: string;
  limitations: string;
  status: string;
}

export interface SearchableProject {
  id: string;
  name: string;
  objective: string;
  description: string;
  status: string;
  priority: string;
  required_deliverables: string;
  dependencies: string;
  risks: string;
}

export interface SearchableDocument {
  id: string;
  title: string;
  doc_type: string;
  description: string;
  project_id: string | null;
  department_id: string | null;
  filename: string;
  version_number: number;
  access_level: 'COUNCIL_INTERNAL' | 'DIRECTOR_ONLY' | 'DEPARTMENT_RESTRICTED';
}

function matchesAllTerms(haystackParts: Array<string | null | undefined>, terms: string[]): boolean {
  if (!terms.length) return false;
  const combined = haystackParts
    .filter(Boolean)
    .join(' ')
    .toLowerCase();
  return terms.every((term) => combined.includes(term));
}

export function searchCouncilEntities(params: {
  query: string;
  user: AuthUser | null | undefined;
  departments: SearchableDepartment[];
  projects: SearchableProject[];
  documents: SearchableDocument[];
  limitPerGroup?: number;
}): {
  query: string;
  departments: SearchableDepartment[];
  projects: SearchableProject[];
  documents: SearchableDocument[];
  total: number;
} {
  const cleanQuery = String(params.query || '').trim();
  const limit = params.limitPerGroup ?? 8;
  if (!cleanQuery || !params.user) {
    return { query: cleanQuery, departments: [], projects: [], documents: [], total: 0 };
  }

  const terms = cleanQuery.toLowerCase().split(/\s+/).filter(Boolean);

  const departments = params.departments
    .filter((d) =>
      matchesAllTerms(
        [d.code, d.name, d.assigned_model, d.application_name, d.responsibilities, d.limitations, d.status],
        terms
      )
    )
    .slice(0, limit);

  const projects = params.projects
    .filter((p) =>
      matchesAllTerms(
        [p.id, p.name, p.objective, p.description, p.required_deliverables, p.dependencies, p.risks, p.status, p.priority],
        terms
      )
    )
    .slice(0, limit);

  const documents = params.documents
    .filter((doc) => canViewDocument(params.user, doc))
    .filter((doc) => matchesAllTerms([doc.title, doc.doc_type, doc.description, doc.filename], terms))
    .slice(0, limit);

  return {
    query: cleanQuery,
    departments,
    projects,
    documents,
    total: departments.length + projects.length + documents.length,
  };
}
