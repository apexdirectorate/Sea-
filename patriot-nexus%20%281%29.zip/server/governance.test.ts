import test from 'node:test';
import assert from 'node:assert/strict';
import {
  aggregateDepartmentAssignments,
  buildDispatchPacket,
  buildSessionCookie,
  canCreateAssignments,
  canSubmitReport,
  canSubmitReview,
  canViewDocument,
  extractBearerToken,
  hashPassword,
  isActiveAssignmentStatus,
  isDirector,
  isDirectorOnlyTaskStatus,
  parseCookies,
  searchCouncilEntities,
  sha256Hex,
  verifyPassword,
  type AuthUser,
} from './governance.ts';
import { getDb, nextSequenceRef, seedSampleRecords } from './db.ts';

const g0User: AuthUser = {
  id: 'u-g0',
  username: 'g0',
  display_name: 'Director G-0',
  role: 'G0_DIRECTOR',
  department_id: null,
  can_submit: 1,
  can_review: 1,
  can_approve: 1,
  is_active: 1,
};

const claudeUser: AuthUser = {
  id: 'u-claude',
  username: 'claude-mech',
  display_name: 'Claude Mechanical',
  role: 'DEPT_MODEL',
  department_id: 'dept-claude',
  can_submit: 1,
  can_review: 1,
  can_approve: 0,
  is_active: 1,
};

const gpt6User: AuthUser = {
  id: 'u-gpt6',
  username: 'gpt6-arch',
  display_name: 'GPT-6 Architect',
  role: 'DEPT_MODEL',
  department_id: 'dept-gpt6',
  can_submit: 1,
  can_review: 1,
  can_approve: 0,
  is_active: 1,
};

const museUser: AuthUser = {
  id: 'u-muse',
  username: 'muse-qa',
  display_name: 'Muse AI QA',
  role: 'REVIEWER',
  department_id: 'dept-muse',
  can_submit: 0,
  can_review: 1,
  can_approve: 0,
  is_active: 1,
};

test('PBKDF2 password hashing and verification', () => {
  const { hash, salt } = hashPassword('StrongCouncilPass#2026');
  assert.equal(verifyPassword('StrongCouncilPass#2026', hash, salt), true);
  assert.equal(verifyPassword('WrongPassword', hash, salt), false);
});

test('Cookie parser, Bearer extraction, cross-site iframe cookie attributes, and SHA-256 hashing', () => {
  const parsed = parseCookies('foo=bar; pn_session=abc%3D123; theme=dark');
  assert.equal(parsed.pn_session, 'abc=123');
  assert.equal(sha256Hex('token-1').length, 64);

  assert.equal(extractBearerToken('Bearer my_tok.123'), 'my_tok.123');
  assert.equal(extractBearerToken('Basic abc'), null);
  assert.equal(extractBearerToken(undefined), null);

  const httpsCookie = buildSessionCookie('tok123', true, false);
  assert.match(httpsCookie, /SameSite=None/);
  assert.match(httpsCookie, /Secure/);
  assert.match(httpsCookie, /Partitioned/);
  assert.match(httpsCookie, /HttpOnly/);

  const localCookie = buildSessionCookie('tok123', false, false);
  assert.match(localCookie, /SameSite=Lax/);
  assert.doesNotMatch(localCookie, /Secure/);
});

test('Role-based authority & no-self-review/approval rules', () => {
  assert.equal(isDirector(g0User), true);
  assert.equal(isDirector(gpt6User), false);
  assert.equal(canCreateAssignments(g0User), true);
  assert.equal(canCreateAssignments(gpt6User), true);
  assert.equal(canCreateAssignments(claudeUser), false);

  // Department model can submit only for own department
  assert.equal(canSubmitReport(claudeUser, 'dept-claude'), true);
  assert.equal(canSubmitReport(claudeUser, 'dept-gemini'), false);

  // Self-review & same-department review must be blocked
  const claudeReport = { submitted_by_user_id: 'u-claude', department_id: 'dept-claude' };
  assert.equal(canSubmitReview(claudeUser, claudeReport), false);
  assert.equal(canSubmitReview(museUser, claudeReport), true);
  assert.equal(canSubmitReview(g0User, claudeReport), true);

  const g0Report = { submitted_by_user_id: 'u-g0', department_id: 'dept-gpt6' };
  assert.equal(canSubmitReview(g0User, g0Report), false);

  // Director-only statuses & doc access
  assert.equal(isDirectorOnlyTaskStatus('Approved by G-0'), true);
  assert.equal(isDirectorOnlyTaskStatus('In Progress'), false);
  assert.equal(canViewDocument(claudeUser, { access_level: 'DIRECTOR_ONLY', department_id: null }), false);
  assert.equal(canViewDocument(claudeUser, { access_level: 'DEPARTMENT_RESTRICTED', department_id: 'dept-claude' }), true);
  assert.equal(canViewDocument(claudeUser, { access_level: 'DEPARTMENT_RESTRICTED', department_id: 'dept-gemini' }), false);
  assert.equal(canViewDocument(g0User, { access_level: 'DIRECTOR_ONLY', department_id: null }), true);
});

test('Dispatch packet includes governance rule and task ref', () => {
  const brief = buildDispatchPacket({
    task: {
      task_ref: 'PN-TASK-001',
      objective: 'Verify actuator torque',
      instructions: 'Calculate stall margin',
      required_output: 'Structured report',
    },
    project: {
      id: 'PN-PROJ-420',
      name: '420 Robotics',
      priority: 'CRITICAL',
      director_approval_status: 'APPROVED_BY_G0',
      objective: 'Chassis baseline',
    },
    department: {
      name: 'Mechanical & Robotics Engineering',
      assigned_model: 'Claude',
    },
    documents: [{ id: 'doc-1', title: 'Motor Spec', filename: 'motor.pdf' }],
  });
  assert.match(brief, /PN-TASK-001/);
  assert.match(brief, /G-0 retains final authority/);
  assert.match(brief, /motor\.pdf/);
});

test('SQLite schema enforces append-only triggers on reports and decisions', () => {
  const db = getDb(':memory:');
  const { hash, salt } = hashPassword('TestDirectorPass123!');
  db.prepare(`
    INSERT INTO users (id, username, display_name, role, can_submit, can_review, can_approve, password_hash, password_salt)
    VALUES ('u-g0', 'g0', 'Director G-0', 'G0_DIRECTOR', 1, 1, 1, ?, ?)
  `).run(hash, salt);

  seedSampleRecords(db, 'u-g0');

  const projects = db.prepare('SELECT id FROM projects').all() as Array<{ id: string }>;
  assert.equal(projects.length, 1);

  const tasks = db.prepare('SELECT id FROM assignments').all() as Array<{ id: string }>;
  assert.equal(tasks.length, 2);

  // Verify decision immutability trigger rejects silent edits and deletes
  const dec = db.prepare('SELECT id FROM decisions LIMIT 1').get() as { id: string };
  assert.throws(() => {
    db.prepare(`UPDATE decisions SET content = 'Tampered' WHERE id = ?`).run(dec.id);
  }, /IMMUTABLE_LEDGER/);
  assert.throws(() => {
    db.prepare(`DELETE FROM decisions WHERE id = ?`).run(dec.id);
  }, /IMMUTABLE_LEDGER/);

  // Verify report immutability trigger
  const repRef = nextSequenceRef(db, 'PN-REPORT', 'PN-REPORT', 'CLAUDE');
  db.prepare(`
    INSERT INTO reports (
      id, report_ref, project_id, task_id, department_id, submitted_by_user_id,
      model_application, objective, findings, evidence, assumptions, limitations,
      risks, recommendations, unresolved_questions
    ) VALUES (?, ?, ?, ?, 'dept-claude', 'u-g0', 'Claude', 'Obj', 'Orig findings', 'Evid', 'Assump', 'Lim', 'Risk', 'Rec', 'Q')
  `).run('rep-1', repRef, projects[0].id, tasks[0].id);

  assert.throws(() => {
    db.prepare(`UPDATE reports SET findings = 'Silently overwritten' WHERE id = 'rep-1'`).run();
  }, /IMMUTABLE_RECORD/);
  assert.throws(() => {
    db.prepare(`DELETE FROM reports WHERE id = 'rep-1'`).run();
  }, /IMMUTABLE_RECORD/);

  db.close();
});

test('Active assignment classification and department workload aggregation', () => {
  for (const activeStatus of ['Pending', 'Assigned', 'In Progress', 'Submitted', 'Under Review', 'Revision Required']) {
    assert.equal(isActiveAssignmentStatus(activeStatus), true);
  }
  for (const terminalStatus of ['Approved by G-0', 'Rejected', 'Archived']) {
    assert.equal(isActiveAssignmentStatus(terminalStatus), false);
  }

  const agg = aggregateDepartmentAssignments([
    { assigned_department_id: 'dept-claude', status: 'In Progress' },
    { assigned_department_id: 'dept-claude', status: 'Pending' },
    { assigned_department_id: 'dept-claude', status: 'Approved by G-0' },
    { assigned_department_id: 'dept-gemini', status: 'Revision Required' },
    { assigned_department_id: 'dept-grok', status: 'Archived' },
  ]);

  assert.deepEqual(agg['dept-claude'], {
    active_assignment_count: 2,
    in_progress_count: 1,
    revision_required_count: 0,
  });
  assert.deepEqual(agg['dept-gemini'], {
    active_assignment_count: 1,
    in_progress_count: 0,
    revision_required_count: 1,
  });
  assert.deepEqual(agg['dept-grok'], {
    active_assignment_count: 0,
    in_progress_count: 0,
    revision_required_count: 0,
  });
});

test('searchCouncilEntities filters departments, projects, and enforces document RBAC', () => {
  const departments = [
    {
      id: 'dept-claude',
      code: 'CLAUDE',
      name: 'Mechanical & Robotics Engineering',
      assigned_model: 'Claude',
      application_name: 'Anthropic / Claude',
      responsibilities: 'Actuator torque and chassis structures',
      limitations: 'Needs bench verification',
      status: 'PROVISIONAL',
    },
    {
      id: 'dept-gemini',
      code: 'GEMINI',
      name: 'Simulation, Mathematics & Modeling',
      assigned_model: 'Gemini',
      application_name: 'Google / Gemini',
      responsibilities: 'Kinematic control modeling',
      limitations: 'Needs solver calibration',
      status: 'PROVISIONAL',
    },
  ];
  const projects = [
    {
      id: 'PN-PROJ-420',
      name: '420 Robotics Torque Chassis',
      objective: 'Verify actuator torque margin',
      description: 'Chassis baseline',
      status: 'ACTIVE',
      priority: 'CRITICAL',
      required_deliverables: 'Torque budget',
      dependencies: 'Motor spec',
      risks: 'Thermal load',
    },
  ];
  const documents = [
    {
      id: 'doc-public',
      title: 'Actuator Torque Spec Sheet',
      doc_type: 'TECH_SPEC',
      description: 'Shared spec',
      project_id: 'PN-PROJ-420',
      department_id: 'dept-claude',
      filename: 'torque-spec.pdf',
      version_number: 1,
      access_level: 'COUNCIL_INTERNAL' as const,
    },
    {
      id: 'doc-secret',
      title: 'Director Torque Budget Override',
      doc_type: 'DECISION_REF',
      description: 'Director only',
      project_id: 'PN-PROJ-420',
      department_id: null,
      filename: 'g0-torque.pdf',
      version_number: 1,
      access_level: 'DIRECTOR_ONLY' as const,
    },
  ];

  // Non-director sees matching department, project, and COUNCIL_INTERNAL doc, but NOT DIRECTOR_ONLY doc
  const deptResult = searchCouncilEntities({
    query: 'torque',
    user: claudeUser,
    departments,
    projects,
    documents,
  });
  assert.equal(deptResult.departments.length, 1);
  assert.equal(deptResult.departments[0].id, 'dept-claude');
  assert.equal(deptResult.projects.length, 1);
  assert.equal(deptResult.documents.length, 1);
  assert.equal(deptResult.documents[0].id, 'doc-public');
  assert.equal(deptResult.total, 3);

  // Director G-0 sees both matching documents
  const g0Result = searchCouncilEntities({
    query: 'torque',
    user: g0User,
    departments,
    projects,
    documents,
  });
  assert.equal(g0Result.documents.length, 2);
  assert.equal(g0Result.total, 4);
});


