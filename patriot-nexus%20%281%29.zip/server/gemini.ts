import { GoogleGenAI, ThinkingLevel } from '@google/genai';

export type CouncilGeminiModel = 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
export type CouncilThinkingMode = 'LOW' | 'HIGH';

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured on the server. Add a valid key in Settings > Secrets.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function formatGeminiError(err: unknown): string {
  const msg = err instanceof Error ? err.message : String(err);
  if (msg.includes('403') || msg.includes('PERMISSION_DENIED') || msg.includes('API_KEY_INVALID')) {
    return 'Gemini API key is invalid or lacks permission. Verify GEMINI_API_KEY in Settings > Secrets.';
  }
  if (msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED')) {
    return 'Gemini API quota reached (429 RESOURCE_EXHAUSTED). Wait and retry or check quota in Settings > Secrets.';
  }
  return msg;
}

export async function runCouncilChatTurn(params: {
  history: Array<{ role: 'user' | 'model'; content: string }>;
  message: string;
  departmentScope: string;
  model: CouncilGeminiModel;
  thinkingMode: CouncilThinkingMode;
  workspaceContext: string;
}): Promise<{ reply: string; modelUsed: string; thinkingUsed: string }> {
  const ai = getGeminiClient();
  const model = params.model === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';

  const roleDirective =
    params.departmentScope === 'gemini-math'
      ? 'You are the Gemini Simulation, Mathematics & Modeling Department inside PATRIOT-NEXUS (420 Robotics). Provide rigorous equations, error bounds, boundary conditions, and explicitly distinguish verified evidence from assumptions.'
      : params.departmentScope === 'synthesis'
      ? 'You are assisting GPT-6 (Chief Architect) and Director G-0 in synthesizing Council reports, detecting contradictions, missing evidence, and unverified assumptions across the eight AI departments. You never override Director G-0.'
      : 'You are the PATRIOT-NEXUS Gemini Engineering Assistant supporting Director G-0 on 420 Robotics. Be concise, technical, and clearly separate verifiable evidence from assumptions.';

  const systemInstruction = `${roleDirective}\n\nAuthorized Council Workspace Context:\n${params.workspaceContext}`;

  const config: Record<string, unknown> = {
    systemInstruction,
  };

  if (model === 'gemini-4-hydrogen') {
    config.thinkingConfig = {
      thinkingLevel: params.thinkingMode === 'LOW' ? ThinkingLevel.LOW : ThinkingLevel.HIGH,
    };
  }

  try {
    const chat = ai.chats.create({
      model,
      config,
      history: params.history.map((m) => ({
        role: m.role,
        parts: [{ text: m.content }],
      })),
    });

    const response = await chat.sendMessage({ message: params.message });
    const reply = response.text?.trim();
    if (!reply) {
      throw new Error('Gemini returned an empty response.');
    }
    return {
      reply,
      modelUsed: model,
      thinkingUsed: model === 'gemini-4-hydrogen' ? params.thinkingMode : 'MINIMAL',
    };
  } catch (err) {
    throw new Error(formatGeminiError(err));
  }
}

export async function runGeminiReportAnalysis(params: {
  reportRef: string;
  objective: string;
  findings: string;
  evidence: string;
  assumptions: string;
  limitations: string;
  risks: string;
}): Promise<string> {
  const ai = getGeminiClient();

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: [
        `Perform an independent technical verification pre-screen for PATRIOT-NEXUS report ${params.reportRef}.`,
        `Objective: ${params.objective}`,
        `Findings: ${params.findings}`,
        `Evidence: ${params.evidence}`,
        `Assumptions: ${params.assumptions}`,
        `Limitations: ${params.limitations}`,
        `Risks: ${params.risks}`,
        '',
        'Output concise bullet points covering: (1) Evidence vs. Assumption separation check, (2) Mathematical or physical contradictions, (3) Missing test verification steps, (4) Recommended follow-up checks for Director G-0.'
      ].join('\n'),
      config: {
        systemInstruction: 'You are an independent technical reviewer inside PATRIOT-NEXUS. Never approve work automatically; identify gaps, unverified claims, and test requirements objectively.',
        thinkingConfig: {
          thinkingLevel: ThinkingLevel.HIGH,
        },
      },
    });

    return response.text?.trim() || 'No analysis returned.';
  } catch (err) {
    throw new Error(formatGeminiError(err));
  }
}
